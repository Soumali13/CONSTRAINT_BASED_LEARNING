#! /bin/bash
# Script to replicate the CNN_CC_O results.

SCRIPT_DIR=../SBRS_7.1_soumali/scripts/process_results
BIN=../SBRS_7.1_soumali/Train/sbr_train
if [ -f $BIN ]; then
    echo "$BIN exists."
else
    pushd ../SBRS_7.1_soumali/Train
    make clean
    make all
    popd
fi

$BIN --training_data_file=data_train.txt --training_examples_file=train_examples.txt --test_examples_file=test_examples.txt --predicates_file=predicates.txt --rules_file=rules_weak_luka.txt --max_iterations=50 --lambda_regularization_values=1 --lambda_constraint_values=1 --lambda_labeled_values=1 --learning_rate=0.01 --lambda_predicate_dependent_files=predicates_lambda_all.txt --output_dir=./CNN_CC_O/outputs --input_dir=./CNN_CC_O/inputs  --learning_type=RGD --transductive --run_collective_classification_after_train --map_function_constraints_affect_supervised_entries --squashing_function_type=LINEAR_SATURATED  --predicate_dependent_regularizers=true && \
cat ./CNN_CC_O/outputs/cc/ll1-lr1-lc1/results/test_results.dat | $SCRIPT_DIR/test.pl --considered_classes=apple,aquarium_fish,baby,bear,beaver,bed,bee,beetle,bicycle,bottle,bowl,boy,bridge,bus,butterfly,camel,can,castle,caterpillar,cattle,chair,chimpanzee,clock,cloud,cockroach,couch,crab,crocodile,cup,dinosaur,dolphin,elephant,flatfish,forest,fox,girl,hamster,house,kangaroo,keyboard,lamp,lawn_mower,leopard,lion,lizard,lobster,man,maple_tree,motorcycle,mountain,mouse,mushroom,oak_tree,orange,orchid,otter,palm_tree,pear,pickup_truck,pine_tree,plain,plate,poppy,porcupine,possum,rabbit,raccoon,ray,road,rocket,rose,sea,seal,shark,shrew,skunk,skyscraper,snail,snake,spider,squirrel,streetcar,sunflower,sweet_pepper,table,tank,telephone,television,tiger,tractor,train,trout,tulip,turtle,wardrobe,whale,willow_tree,wolf,woman,worm
