#! /bin/bash

for i in $(seq 10 10); do
echo "Processing fold${i}.data"
cd fold${i}.data
mkdir -p output
/home/diligmic/src/SBRS_5.1/TrainBetaPartners/sbr_train \
--training_data_file=train.${i}.data \
--training_examples_file=train.${i}.examples \
--predicates_file=predicates \
--rules_file=train.${i}.rules \
--max_iterations=300 \
--use_constraints=false --iteration_start_constraints=1 \
--lambda_regularization_values=0.01 --lambda_constraint_values=1 \
--min_learning_rate_values=1 --learning_rate=0.1 \
--min_gradient_module=1e-20 --min_total_error=1e-07 \
--transductive_mode=true \
--nn_num_units=35 --nn_num_units_by_id=PARTNERS:70 \
--max_learning_rate=100 --min_learning_rate=0.0001 \
--random_initialization_weights=true \
--nn_pre_built_inputs=false \
--bias=0 \
--function_type=NEURAL_NETWORK \
--learning_type=RGD \
--labeled_lossfunction=2 --labeled_p1=0 \
--output_dir=output --input_dir=. > \
./output/OUTPUT
cd ..
done > OUTPUT
