#! /usr/bin/perl -w

if (@ARGV != 4) {
  die "Usage: $0 datafile cc_examplesfile cc_test_examplesfile n_splits";
}

my $n = $ARGV[3];
if ($n <= 1) {
  die "n must be at least 2";
}

my @odatafile;
my @oexamplesfile;
my @otestexamplesfile;
open DATA, "$ARGV[0]" || die "Can not open data file $ARGV[0]";
for (my $i = 0; $i < $n; ++$i) {
  local *OUTD;
  local *OUTE;
  local *OUTTE;
  open(OUTD, ">$ARGV[0].split$i") || die;
  open(OUTE, ">$ARGV[1].split$i") || die;
  open(OUTTE, ">$ARGV[2].split$i") || die;
  push (@odatafile, *OUTD); 
  push (@oexamplesfile, *OUTE); 
  push (@otestexamplesfile, *OUTTE); 
}

while (my $line = <DATA>) {
  $line =~ /^s([0-9]+)[a-z]/;
  if (defined $1) {
    my $split = ($1 % $n);
    print { $odatafile[$split] } "$line";
  }
}

open EXAMPLES, "$ARGV[1]" || die "Can not open examples file $ARGV[1]";
while (my $line = <EXAMPLES>) {
  $line =~ /\(s([0-9]+)[a-z]/;
  if (defined $1) {
    my $split = ($1 % $n);
    print { $oexamplesfile[$split] } "$line";
  }
}

open TEXAMPLES, "$ARGV[2]" || die "Can not open examples file $ARGV[2]";
while (my $line = <TEXAMPLES>) {
  $line =~ /\(s([0-9]+)[a-z]/;
  if (defined $1) {
    my $split = ($1 % $n);
    print { $otestexamplesfile[$split] } "$line";
  }
}

exit
