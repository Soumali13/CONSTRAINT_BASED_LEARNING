#! /usr/bin/perl -w

# 0 if using libSVM or SVMlight / 0.5 if using SBRS / 0.5 if using libSVM with probability estimate 
my $threshold = $ARGV[2]; 

######################################################################
#
# Riceve in ingresso un file results di SBRS e calcola le statistiche
# (Si ha la possibilità di indicare le funzioni da considerare)
#
######################################################################

#use strict;
use warnings;
require "./statistics.pl";

my $filename = $ARGV[0]; # file dei results (formato SBRS)
my $tags_list = $ARGV[1];  # list of tags to consider

my @tags;

if ($tags_list ne "") {
  @tags = split(/_/, $tags_list);
} else {
  die "missing list of tags\n"; 
}

# These are two vectors of vectors (matrices). Each row 
# is a pattern and each column correspond to a tag. 
my @targets_vec;
my @predictions_vec;

for (my $t=0; $t<=$#tags; $t++) {

        my @targets;
        my @predictions;

        # Questa versione filtra i pattern unsupervised
        my @ret = get_targets_and_predictions_by_id($filename, $tags[$t]);
        @targets = @{$ret[0]};
        @predictions = @{$ret[1]};

  	foreach my $val (@targets) {
    	  push (@{$targets_vec[$t]}, $val);
  	}

  	foreach my $val (@predictions) {
    	  push (@{$predictions_vec[$t]}, $val);
  	}

  	my @results = compute_statistics_by_class(\@targets, \@predictions, $threshold);

	print $tags[$t].": accuracy ".$results[0]." precision ".$results[1]." recall ".$results[2]." F1 ".$results[3]."\n";
}

my @results = compute_multiclass_statistics(\@targets_vec, \@predictions_vec, $threshold);

print"Macro: accuracy ".$results[0]." precision ".$results[1]." recall ".$results[2]." F1 ".$results[3]."\n";
print "Micro: accuracy ".$results[4]." precision ".$results[5]." recall ".$results[6]." F1 ".$results[7]."\n";
