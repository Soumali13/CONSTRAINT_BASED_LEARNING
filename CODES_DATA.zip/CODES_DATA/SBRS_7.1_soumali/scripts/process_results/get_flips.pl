#! /usr/bin/perl -w
# usage: $0 test_results_baseline.dat test_results_testside.dat

use Getopt::Long qw(GetOptions);
my $classes;
my $thr = 0.5;
my $argmax = 0;
my $show_unchanged = 0;
my $show_supervisions = 0;
GetOptions('considered_classes=s' => \$classes,
           'argmax' => sub { $argmax = 1; },
           'show_unchanged' => sub { $show_unchanged = 1; },
           'show_supervisions' => sub { $show_supervisions = 1; },
           'threshold=s' => \$thr);

# Get the entries of one classification list: class1:value1,class2:value2,...
sub GetEntries {
  my %table;
  my $str = shift;
  my @F = split(/,/, $str);
  for (my $i = 0; $i < @F; ++$i) {
    my @F1 = split(/:/, $F[$i]);
    if (@F1 != 2) {
      warn "Wrong entry $F[$i] in $str";
      next;
    }                             
    $table{$F1[0]} = $F1[1];
  }

  return %table;
}

# Read the considered classes.
my $useConsideredClasses = 0;
my %ConsideredClasses;
if ($classes) {
  my @ConsideredClassesArray = split(/,/, $classes);
  foreach (@ConsideredClassesArray) {
    $ConsideredClasses{$_} = 1;
  }
  $useConsideredClasses = 1;
}

# Scan the files.
# Open the input files
if (@ARGV < 2) {
  die "usage $0 test_results1.dat test_results2.dat";
}
my $f1 = $ARGV[0];
my $f2 = $ARGV[1];
open (F1, $f1) || die "Can not open: $f1";
open (F2, $f2) || die "Can not open: $f2";

while (defined F1 && defined F2 && (my $line1 = <F1>) && (my $line2 = <F2>)) {
  chop $line1;  chop $line2;
  my @T1 = split(/\t/, $line1);
  my @T2 = split(/\t/, $line2);
  if (@T1 != 3 || @T2 != 3) {
    warn "Wrong line: $line1 -- $line2";
    next;
  }
  if ($T1[0] ne $T2[0]) {
    warn "Different names $T1[0] != $T2[0]";
    next
  }

  my %E  = GetEntries($T1[1]);
  my %E2 = GetEntries($T2[1]);  # not used just check for equality to E
  if ((keys %E) != (keys %E2)) {  # check the values as well.
    warn "Different number of examples $T1[1] != $T2[1] ", scalar(keys %E), " ", scalar(keys %E2);
  }

  my %C1 = GetEntries($T1[2]);
  my %C2 = GetEntries($T2[2]);
  if ((keys %C1) != (keys %C2)) {
    warn "Different number of classes $T1[2] != $T2[2]";
    next;
  }

  my $out = "$T1[0]\t";
  if ($show_supervisions == 1) { $out .= "$T1[1]\t"; }

  my $first = 1;
  my $empty = 1;

  if ($argmax == 1) {
    my $max_val1 = -1000000;
    my $max_class1;
    my $max_val2 = -1000000;
    my $max_class2;
    foreach my $c1 (keys %C1) {
      if ($useConsideredClasses == 1 &&
          !defined $considered_classes{$c1}) { next; }  # skip this class
      if ($max_val1 < $C1{$c1}) {
        $max_val1 = $C1{$c1};
        $max_class1 = $c1;
      }
    }
    foreach my $c2 (keys %C2) {
      if ($useConsideredClasses == 1 &&
          !defined $considered_classes{$c2}) { next; }  # skip this class
      if ($max_val2 < $C2{$c2}) {
        $max_val2 = $C2{$c2};
        $max_class2 = $c2;
      }
    }
    if ($max_class1 ne $max_class2) {
      $out .= "$max_class1:0,$max_class2:1";
      $empty = 0;
      if (defined $E{$max_class1} && defined $E{$max_class2}) {
        if ($E{$max_class1} < $thr && $E{$max_class2} >= $thr) {
          $out .= "(CORRECT)";
        } else {
          $out .= "(WRONG)";
        }
      }
    }
  } else {
    foreach my $c (keys %C1) {
      if (!defined $C2{$c}) {
        warn "Different classes: $c missing in $T2[2]";
        next;
      }
      if ($useConsideredClasses == 1 &&
          !defined $considered_classes{$c}) { next; }  # skip this class

      my $v1 = $C1{$c};
      my $v2 = $C2{$c};
      if ($v1 < $thr && $v2 >= $thr) {
        if ($first == 1) {
          $first = 0;
        } else {
          $out .= ",";
        }
        $out .= "$c:1";
        $empty = 0;
	if (defined $E{$c}) {
          if ($E{$c} >= $thr) { $out .= "(CORRECT)"; }
          else { $out .= "(WRONG)"; }
        }
      }
      if ($v1 >= $thr && $v2 < $thr) {
        if ($first == 1) {
          $first = 0;
        } else {
          $out .= ",";
        }
        $out .= "$c:0";
        $empty = 0;
	if (defined $E{$c}) {
          if ($E{$c} < $thr) { $out .= "(CORRECT)"; }
          else { $out .="(WRONG)"; }
        }
      }
    }
  }
  if ($show_unchanged == 1 || $empty == 0) {
    print "$out\n";
  }
}

