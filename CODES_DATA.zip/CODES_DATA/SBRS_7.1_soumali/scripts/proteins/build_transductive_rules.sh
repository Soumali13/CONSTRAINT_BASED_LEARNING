#! /bin/bash

PMARGIN=0.0
NMARGIN=0.04
THR_MIN=0
THR_MAX=1
OFILE=rules_transductive
DIR=$HOME/src/BioinformaticsExperiments/PFP_v2/experimentbiological_process_cellular_component_3_100

for f in 0 1 2 3 4 5 6 7 8 9; do
  echo "Processing $DIR/folds/$f/train_examples_OC"
  echo "Output to ${DIR}/folds/${f}/$OFILE" 
  cat $DIR/folds/$f/train_examples_OC | tr '()=' ' ' | \
  awk -v pm=$PMARGIN -v nm=$NMARGIN -v tmin=$THR_MIN -v tmax=$THR_MAX  '{\
  if ($NF==0) N[$1]++; else P[$1]++;}\
  END{\
    for(i in N) {\
      pp=P[i]/(N[i]+P[i]); pn=1.0 - pp; pp=pp-pm; pn=pn-nm; if (pn<0) pn=0; \
      if (pp>=tmin && pp<=tmax) {\
        # print "forall x [("i"(x) OR NOT "i"(x))];LEARN;L1;MINIMUM_TNORM;10;2"; \
        if (pp>0.01) print "exists_"pp" x [("i"(x))];LEARN;L1;LUKASIEWICZ_TNORM;10;2"; \
        if (pn>0.01) print "exists_"pn" x [(NOT "i"(x))];LEARN;L1;LUKASIEWICZ_TNORM;10;2"; \
      }\
    }\
  }' | tee ${DIR}/folds/${f}/$OFILE
done
# done folds
