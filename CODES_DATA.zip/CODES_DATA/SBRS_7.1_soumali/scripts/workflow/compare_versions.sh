#! /bin/bash

args=$#           # Number of args passed.

if [[ $args != 2 ]]; then
    echo usage: $0 DIR1 DIR2
    echo "Execute from external directory."
    echo "Example SBRS_7.0/scripts/workflow/compare_versions.sh SBRS_7.0_stable SBRS_7.0"
    exit
fi

# DIR1=SBRS_7.0
# DIR2=SBRS_7.0_stable
DIR1=$1
DIR2=$2
for F in $(find $DIR1 -name "*" | grep -e "\.h$" -e "\.cc$"  -e "\.sh"); do
    F1=$(echo $F | sed -e "s/${DIR1}/${DIR2}/")
    if [[ $(cmp $F $F1) ]]; then
	echo tkdiff $F $F1
    fi
done
