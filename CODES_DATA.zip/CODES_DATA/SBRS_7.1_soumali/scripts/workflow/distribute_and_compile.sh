# /bin/bash

BUILD_PACKAGE_ONLY=${1:-0}
COPY_ONLY=0
REMOTE_DIR=src/SBRS_7.1.1
REMOTE_MACHINES="michelangelo@10.1.0.88 diligenti@10.1.0.85 diligenti@10.1.0.26"
CP_TO_GDRIVE=0
TARGET=${2:-"Train"}
V=7.1

echo Building target $TARGET
set -x

if [[ $BUILD_PACKAGE_ONLY != 1 ]]; then
  ssh-add
fi

cd $HOME/src/eclipse
DATE=$(date +%Y%m%d)

# Build package
tar cvfz SBRS_${V}_${DATE}.tar.gz SBRS_$V
if [[ $BUILD_PACKAGE_ONLY == 1 ]]; then
    exit 0
fi

# GoogleDrive integration (MacOnly)
if [[ $CP_TO_GDRIVE == 1 ]]; then
  cp -f SBRS_${V}_${DATE}.tar.gz  $HOME/Google\ Drive/Shared/PhD\ work\ and\ Documents/Code\ and\ Utilities/
fi

for m in $REMOTE_MACHINES; do
  scp SBRS_${V}_${DATE}.tar.gz ${m}:src/.

  if [[ $COPY_ONLY == 0 ]]; then
    ssh ${m} \
      "mkdir tmp; cd tmp && rm -rf SBRS_$V && tar xvfz ~/src/SBRS_${V}_${DATE}.tar.gz && cd SBRS_${V}/$TARGET && make clean && make all && cd && rm -rf $REMOTE_DIR && mv tmp/SBRS_${V} $REMOTE_DIR && ls -l $REMOTE_DIR/${TARGET}/sbr_train" &
  fi
done
