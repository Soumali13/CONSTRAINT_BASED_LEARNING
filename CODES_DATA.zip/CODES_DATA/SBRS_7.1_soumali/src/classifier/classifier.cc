#if __ACTIVATE_OPENMP_CLASSIFIER__ > 0
#include <omp.h>
#endif

#include "classifier/classifier.h"

#include "classifier/classifier_out.h"
#include "classifier/functions/learn_function/learn_function.h"
#include "classifier/functions/given_function.h"
#include "classifier/functions/learn_function/map_function.h"
#include "classifier/functions/learn_function/neural_networks/neural_network_function.h"
#include "classifier/functions/function.h"
#include "classifier/functions/function_factory.h"
#include "classifier/functions/learn_function/kernel_machine/kernel/kernel_factory.h"
#include "data/dataset.h"
#include "data/examples.h"
#include "data/predicates.h"
#include "train/options.h"
#include "utils/file_utils.h"
#include "utils/gflags/gflags/gflags.h"
#include "utils/stl_utils.h"


using namespace std;


DEFINE_string(shared_function_predicates, "",
              "Column separated list of comma separated groups of predicates sharing the same underlying function. "
              "Example: 'aaa,bbb:ccc,ddd,eee'");

namespace Regularization
{
/**
 * Constructor:
 **/
BaseClassifier::BaseClassifier(const Predicates& predicates_) :
        per_domain_functions(predicates_.GetPerDomainPredicates()),
        predicates(predicates_) {
}

BaseClassifier::BaseClassifier(const BaseClassifier& classifier) :
        per_domain_functions(classifier.predicates.GetPerDomainPredicates()),
        predicates(classifier.predicates) {
    // Virtual calls do not work in constructors, so we can not call Copy.

    // Copy shared functions first.
    for (unsigned int i = 0; i < classifier.sharedFunctionContainer.size(); ++i) {
        const std::vector<Function*> functions  = classifier.sharedFunctionContainer[i];
        for (unsigned int j = 0; j < functions.size(); ++j) {
            // Only NeuralNetworkFunction are supported.
            const NeuralNetworkFunction* nn = dynamic_cast<const NeuralNetworkFunction*>(functions[0]);
            CHECK_NE_NULL(nn);
        }
        // Fetch the underlying net for each group.
        const NeuralNetworkFunction* nn = dynamic_cast<const NeuralNetworkFunction*>(functions[0]);
        NeuralNetworkFunction::NN* net = new NeuralNetworkFunction::NN(
                *nn->GetNeuralNetwork());

        // Duplicate the network and recreate the function group.
        vector<Function*> sharedFunctionContainerElement;
        sharedFunctionContainerElement.reserve(functions.size());
        for (unsigned int j = 0; j < functions.size(); ++j) {
            const NeuralNetworkFunction* nn = dynamic_cast<const NeuralNetworkFunction*>(functions[j]);
            NeuralNetworkFunction* nn_copy = new NeuralNetworkFunction(*nn);
            nn_copy->SetSharedNeuralNetwork(net);
            this->Add(nn_copy);
            sharedFunctionSet.insert(nn_copy->GetId());
            sharedFunctionContainerElement.push_back(nn_copy);
        }
        sharedFunctionContainer.push_back(sharedFunctionContainerElement);
    }

    // Copy the normal functions predicate by predicate.
    const FunctionContainer& functions = classifier.GetFunctions();
    for (FunctionContainer::const_iterator iter = functions.begin();
         iter != functions.end(); ++iter) {
        const Function* function = iter->second;
        // Shared functions are separately copied.
        if (sharedFunctionSet.find(function->GetId()) == sharedFunctionSet.end()) {
            this->Add(function->Clone());
        }
    }
}

BaseClassifier::~BaseClassifier() {
  this->Clear();
}

void BaseClassifier::Copy(const BaseClassifier* classifier) {
    this->Clear();

    per_domain_functions = classifier->predicates.GetPerDomainPredicates();
    predicates = classifier->predicates;

    // Copy shared functions first.
    for (unsigned int i = 0; i < classifier->sharedFunctionContainer.size(); ++i) {
        std::vector<Function*> functions  = classifier->sharedFunctionContainer[i];
        for (unsigned int j = 0; j < functions.size(); ++j) {
            // Only NeuralNetworkFunction are supported.
            NeuralNetworkFunction* nn = dynamic_cast<NeuralNetworkFunction*>(functions[0]);
            CHECK_NE_NULL(nn);
        }
        // Fetch the underlying net for each group.
        NeuralNetworkFunction* nn = dynamic_cast<NeuralNetworkFunction*>(functions[0]);
        NeuralNetworkFunction::NN* net = new NeuralNetworkFunction::NN(
                *nn->GetNeuralNetwork());

        // Duplicate the network and recreate the function group.
        vector<Function*> sharedFunctionContainerElement;
        sharedFunctionContainerElement.reserve(functions.size());
        for (unsigned int j = 0; j < functions.size(); ++j) {
            NeuralNetworkFunction* nn = dynamic_cast<NeuralNetworkFunction*>(functions[j]);
            NeuralNetworkFunction* nn_copy = new NeuralNetworkFunction(*nn);
            nn_copy->SetSharedNeuralNetwork(net);
            this->Add(nn_copy);
            sharedFunctionSet.insert(nn_copy->GetId());
            sharedFunctionContainerElement.push_back(nn_copy);
        }
        sharedFunctionContainer.push_back(sharedFunctionContainerElement);
    }

    // Copy the normal functions predicate by predicate.
    const FunctionContainer& functions = classifier->GetFunctions();
    for (FunctionContainer::const_iterator iter = functions.begin();
         iter != functions.end(); ++iter) {
        const Function* function = iter->second;
        // Shared functions are separately copied.
        if (sharedFunctionSet.find(function->GetId()) == sharedFunctionSet.end()) {
            this->Add(function->Clone());
        }
    }

    // Subclass specific code.
    this->InternalCopy(classifier);
}

/*
 * Builds a new classifier to be trained. Train options are needed to set up the classifier.
 */
Classifier::Classifier(
        const Predicates& predicates_,
        const Dataset& dataset_,
        const Examples& examples_,
        const TrainOptions& options_) :
        BaseClassifier(predicates_) {
    const Predicates::PredicatesMap& predicates_map = predicates_.GetPredicatesMap();
    vector<vector<Function::ID> > shared_functions_by_predicates;
    StringUtils::SplitToVectorOfVectorsByType(
            FLAGS_shared_function_predicates, &shared_functions_by_predicates, ":", ",", true);

    set<Function::ID> shared_functions_set;
    // Check that the shared functions are consistent.
    for (unsigned int i = 0; i < shared_functions_by_predicates.size(); ++i) {
        // Each group needs at least 2 predicates.
        CHECK_GT(static_cast<int>(shared_functions_by_predicates[i].size()), 1);

        const Function::ID& predicate_name = shared_functions_by_predicates[i][0];
        shared_functions_set.insert(predicate_name);
        const Predicate* predicate = predicates_.Get(predicate_name);
        CHECK_NE_NULL_WITH_MESSAGE(predicate, "Unknown predicate " + predicate_name);
        const string& domain_str = predicate->GetDomainString();

        vector<const Predicate*> predicate_vector(shared_functions_by_predicates[i].size());
        predicate_vector[0] = predicate;
        for (unsigned int j = 1; j < shared_functions_by_predicates[i].size(); ++j) {
            const Function::ID& predicate_name1 = shared_functions_by_predicates[i][j];
            shared_functions_set.insert(predicate_name1);
            const Predicate* predicate1 = predicates_.Get(predicate_name1);
            CHECK_NE_NULL_WITH_MESSAGE(predicate1, "Unknown predicate " + predicate_name1);
            const string& domain_str1 = predicate1->GetDomainString();
            CHECK_EQ_WITH_MESSAGE(domain_str, domain_str1,
                    "Predicates sharing the same function should have the same domain: " +
                    predicate_name + "->" + domain_str + " vs " + predicate_name1 + "->" + domain_str1);
            predicate_vector[j] = predicate1;
        }

        const Dataset* dataset = dataset_.GetDomainDataset(domain_str);
        vector<Function*> functions = FunctionFactory::BuildSharedFunctions(
                predicate_vector, &examples_, dataset, options_);
        sharedFunctionContainer.push_back(functions);
        for (unsigned int i = 0; i < functions.size(); ++i) {
            this->Add(functions[i]);
            sharedFunctionSet.insert(functions[i]->GetId());
        }
    }

    // Set Functions Container
    for (Predicates::PredicatesMap::const_iterator it = predicates_map.begin();
         it != predicates_map.end(); ++it) {
        const Predicate& predicate = it->second;
        if (shared_functions_set.find(predicate.GetName()) != shared_functions_set.end()) {
            continue;  // this function has already been built as shared
        }
        const Dataset* dataset = dataset_.GetDomainDataset(predicate.GetDomainString());

        VMESSAGE(2, "Building classifier function " << predicate.GetName());
        Function* function = FunctionFactory::BuildFunction(
                predicate, &examples_, dataset, options_);

        // Add the function to the classifier
        this->Add(function);
        VMESSAGE(2, "Done building classifier function " << predicate.GetName());
    }
}

Classifier::Classifier(const Classifier& classifier) :
        BaseClassifier(classifier) {
}

void Classifier::InternalCopy(const BaseClassifier* classifier) { }

Classifier::~Classifier() { }

BaseClassifier* Classifier::Clone() const {
    BaseClassifier* classifier = new Classifier(*this);
    return classifier;
}

/*
 * Builds a new classifier already trained. All the needed info is stored in the file.
 */
Classifier::Classifier(
        const string& filename,         // for all learn functions
        const Predicates& predicates_,  // needed for GIVEN functions
        const Dataset& dataset_,        // needed for GIVEN functions
        const Examples& examples_,      // needed for GIVEN functions
        const TrainOptions& options_) :
        BaseClassifier(predicates_) {
    CHECK(this->Load(filename, options_));

    // Set Functions Container
    const Predicates::PredicatesMap& predicates_map = predicates_.GetPredicatesMap();
    for (Predicates::PredicatesMap::const_iterator it = predicates_map.begin();
         it != predicates_map.end(); ++it) {
        const Predicate& predicate = it->second;
        // Given predicates are not saved in the input classifier,
        // so we need to add them now.
        if (predicate.GetPredicateType() == Function::MAP_GIVEN &&
            !this->HasFunction(predicate.GetName())) {
            const Dataset* dataset = dataset_.GetDomainDataset(predicate.GetDomainString());

            Function* function = FunctionFactory::BuildFunction(
                    predicate, &examples_, dataset, options_);

            // Add the function to the classifier
            this->Add(function);
            VMESSAGE(1, "Added the MAP_GIVEN function " << function->GetId());
        }
    }
}

/**
 * Adds a function, the function should be set to properly
 **/
void BaseClassifier::Add(Function* function) {
    if (predicates.Get(function->GetId()) == NULL) {
        FAULT("Function not declared in the predicate manifest: " << function->GetId());
    }

    if (functionContainer.find(function->GetId()) != functionContainer.end()) {
        FAULT("Function already inserted: " << function->GetId());
    }

    functionContainer[function->GetId()] = function;

    CHECK_NE_NULL_WITH_MESSAGE(predicates.Get(function->GetId()),
            StringUtils::StrCat("Unknown function ID ", function->GetId(),
                                " Predicates ", predicates.ToString()));

    switch(function->GetType()) {
    case Function::MAP_GIVEN:
    {
        GivenFunction* gfunction = dynamic_cast<GivenFunction*>(function);
        CHECK_NE_NULL_WITH_MESSAGE(
                        gfunction,
                        "Can not convert function " + function->GetId() + " to GivenFunction");
        givenFunctionContainer[function->GetId()] = gfunction;
        break;
    }
    case Function::MAP_LEARN:
    {
        MapFunction* mfunction = dynamic_cast<MapFunction*>(function);
        CHECK_NE_NULL_WITH_MESSAGE(
                mfunction,
                "Can not convert function " + function->GetId() + " to MapFunction");

        mapFunctionContainer[function->GetId()] = mfunction;
        // Attention, no break here. A MAP_LEARN is also a LEARN function and should be
        // added to the learnFunctionContainer.
    }
    case Function::LEARN:
    {
        LearnFunction* lfunction = dynamic_cast<LearnFunction*>(function);
        CHECK_NE_NULL_WITH_MESSAGE(
                lfunction,
                "Can not convert function " + function->GetId() + " to LearnFunction");

        learnFunctionContainer[function->GetId()] = lfunction;
        learnFunctionVectorContainer.push_back(lfunction);

        const std::string& domain = predicates.Get(function->GetId())->GetDomainString();
        domainToLearnFunctionContainer[domain][function->GetId()] = lfunction;

        break;
    }
    default:
        FAULT("Unexpected predicate type");
        break;
    }
}

/*********************************************************
 * Classification
 *********************************************************/

/*
 * Return the map of the classification results of the classifier using a dataset
 */
void BaseClassifier::Classify(const Dataset& dataset, ResultSet* results) const {
    time_t startClassifyTime;
    time(&startClassifyTime);

    Index classified_patterns = 0;
    DomainToLearnContainer::const_iterator domain_learn_iter = domainToLearnFunctionContainer.begin();
    for (; domain_learn_iter != domainToLearnFunctionContainer.end(); ++domain_learn_iter) {
        const string& domain = domain_learn_iter->first;
        const Dataset* per_domain_dataset = dataset.GetDomainDataset(domain);
        if (per_domain_dataset == NULL) {
            continue;
        }
        const Index per_domain_dataset_size = per_domain_dataset->Size();
        const unsigned int results_offset = results->Size();
        results->Prealloc(results_offset + per_domain_dataset_size);
#if __ACTIVATE_OPENMP_CLASSIFIER__ > 1
#pragma omp parallel default(none) shared(classified_patterns,results,per_domain_dataset) if (!omp_in_parallel())
#endif
        {
#if __ACTIVATE_OPENMP_CLASSIFIER__ > 1
#pragma omp for reduction(+:classified_patterns) schedule(dynamic,5)
#endif
            for (Index i = 0; i < per_domain_dataset_size; ++i) {
                const Pattern* pattern = per_domain_dataset->Get(i);
                this->ClassifyPattern(*pattern, results->GetMutable(results_offset + i));
                ++classified_patterns;
            }
        }  // end parallel section
    }

    VMESSAGE(1, "Classification completed: " <<
            classified_patterns << " patterns. Time: " <<
            time(NULL) - startClassifyTime << " s");
}

/**
 * Classify the pattern
 **/
void BaseClassifier::ClassifyPattern(const Pattern& pattern, ClassifierOut* result) const {
    result->SetPattern(&pattern);
    DomainToLearnContainer::const_iterator domain_learn_iter =
            domainToLearnFunctionContainer.find(pattern.GetDomain());
    if (domain_learn_iter == domainToLearnFunctionContainer.end()) {
        FAULT("Unknown requested domain " << pattern.GetDomain() << " in pattern " << pattern.ToString());
    }

    // for each function
    for (LearnContainer::const_iterator learn_iter = domain_learn_iter->second.begin();
         learn_iter != domain_learn_iter->second.end(); ++learn_iter) {
        const Function* function = learn_iter->second;
        const Function::ID& function_name = function->GetId();
        // score of the i-th function on the pattern
        result->Set(function_name, function->Eval(pattern));
    }
}

/*****************************************************
 * I/O
 *****************************************************/

/**
 * Save
 **/
bool BaseClassifier::SaveToFile(const string& filename) const {
    ofstream ofs(filename.c_str());

    if (!ofs.good()) {
        WARN("Can not open the file " << filename);
        return false;
    }

    return this->SaveToStream(ofs);
}

/**
 * Save to a stream
 **/
bool BaseClassifier::SaveToStream(ostream& os) const
{
    bool ret = true;
    os << learnFunctionContainer.size() << endl;  // " " << givenFunctionContainer.size() << endl;
    for (LearnContainer::const_iterator iter = learnFunctionContainer.begin();
         iter != learnFunctionContainer.end(); ++iter) {
        if (!FunctionFactory::SaveToStream(iter->second, os)) {
            WARN("Can not save function " << iter->second->GetId() << " to stream");
            ret = false;
        }
        os << endl;
    }

    return ret;
}

/**
 * Save to a directory
 **/
bool BaseClassifier::SaveToDir(const string& dirname) const {
    if (!FileUtils::MakePath(dirname)) {
        WARN("Can not create the directory where to save the classifier: " << dirname);
        return false;
    }
    ofstream of(dirname + "/defs.txt");
    if (!of.good()) {
        WARN("Can not save the classifier to directory " << dirname);
        return false;
    }
    for (LearnContainer::const_iterator iter = learnFunctionContainer.begin();
         iter != learnFunctionContainer.end(); ++iter) {
        const LearnFunction* function = iter->second;
        of << function->GetId() << " " <<
              FunctionFactory::NameFromFunction(function) << std::endl;
    }
    of.close();

    bool ret = true;
    for (LearnContainer::const_iterator iter = learnFunctionContainer.begin();
         iter != learnFunctionContainer.end(); ++iter) {
        const LearnFunction* function = iter->second;
        const std::string& filename = dirname + "/" + function->GetId() + ".dat";
        if (!function->SaveToFile(filename)) {
            WARN("Can not save function " << function->GetId() <<
                 " to file " << filename);
            ret = false;
        }
    }

    return ret;
}
/**
 * Print the functions info to stdout
 **/
void BaseClassifier::Print() const
{
    for (LearnContainer::const_iterator iter = learnFunctionContainer.begin();
            iter != learnFunctionContainer.end(); ++iter)
    {
        cout << "Function " << iter->first << endl;
        FunctionFactory::Print(iter->second);
    }
    for (GivenContainer::const_iterator iter = givenFunctionContainer.begin();
            iter != givenFunctionContainer.end(); ++iter)
    {
        cout << "Function " << iter->first << endl;
        FunctionFactory::Print(iter->second);
    }
}

void BaseClassifier::Clear() {
    for (unsigned int i = 0; i < sharedFunctionContainer.size(); ++i) {
        // Only the first function is considered as the others will share the same underlying network.
        NeuralNetworkFunction* nnf = dynamic_cast<NeuralNetworkFunction*>(sharedFunctionContainer[i][0]);
        if (nnf != NULL) {
            NeuralNetworkFunction::NN* nn = nnf->ReleaseNeuralNetwork();
            if (nn != NULL) {
                delete nn;
            }
        }
    }
    sharedFunctionContainer.clear();
    sharedFunctionSet.clear();
    DeallocMapOfPointers(&learnFunctionContainer);
    DeallocMapOfPointers(&givenFunctionContainer);
    learnFunctionContainer.clear();
    learnFunctionVectorContainer.clear();
    givenFunctionContainer.clear();
    mapFunctionContainer.clear();
    functionContainer.clear();
}

void BaseClassifier::EndTrain() {
#if __ACTIVATE_OPENMP_CLASSIFIER__ > 0
#pragma omp parallel default(none) if (!omp_in_parallel())
#endif
    {
#if __ACTIVATE_OPENMP_CLASSIFIER__ > 0
#pragma omp for
#endif
        for (unsigned int i = 0; i < learnFunctionVectorContainer.size(); ++i) {
            learnFunctionVectorContainer[i]->EndTrain();
        }
    }  // end parallel section
}

void BaseClassifier::EndTrainIteration() {
#if __ACTIVATE_OPENMP_CLASSIFIER__ > 0
#pragma omp parallel default(none) if (!omp_in_parallel())
#endif
    {
#if __ACTIVATE_OPENMP_CLASSIFIER__ > 0
#pragma omp for
#endif
        for (unsigned int i = 0; i < learnFunctionVectorContainer.size(); ++i) {
            learnFunctionVectorContainer[i]->EndTrainIteration();
        }
    }  // end parallel section
}

void BaseClassifier::StartTrainIteration() {
#if __ACTIVATE_OPENMP_CLASSIFIER__ > 0
#pragma omp parallel default(none) if (!omp_in_parallel())
#endif
    {
#if __ACTIVATE_OPENMP_CLASSIFIER__ > 0
#pragma omp for
#endif
        for (unsigned int i = 0; i < learnFunctionVectorContainer.size(); ++i) {
            learnFunctionVectorContainer[i]->StartTrainIteration();
        }
    }  // end parallel section
}

void BaseClassifier::PrepareForCrossvalidation() {
#if __ACTIVATE_OPENMP_CLASSIFIER__ > 0
#pragma omp parallel default(none) if (!omp_in_parallel())
#endif
    {
#if __ACTIVATE_OPENMP_CLASSIFIER__ > 0
#pragma omp for
#endif
        for (unsigned int i = 0; i < learnFunctionVectorContainer.size(); ++i) {
            learnFunctionVectorContainer[i]->PrepareForCrossvalidation();
        }
    }  // end parallel section
}

void BaseClassifier::EndCrossvalidation() {
#if __ACTIVATE_OPENMP_CLASSIFIER__ > 0
#pragma omp parallel default(none) if (!omp_in_parallel())
#endif
    {
#if __ACTIVATE_OPENMP_CLASSIFIER__ > 0
#pragma omp for
#endif
        for (unsigned int i = 0; i < learnFunctionVectorContainer.size(); ++i) {
            learnFunctionVectorContainer[i]->EndCrossvalidation();
        }
    }  // end parallel section
}

/*****************************************************
 * I/O
 *****************************************************/

/**
 * Load
 **/

bool Classifier::Load(const string& filename, const TrainOptions& options) {
    if (FileUtils::IsPathDir(filename)) {
        return this->LoadFromDir(filename, options);
    } else {
        ifstream ifs(filename.c_str());
        if (!ifs.good()) {
            WARN("Can not open the file " << filename);
            return false;
        }
        return this->LoadFromStream(ifs, options);
    }
}

/**
 * Load from a stream
 * Depends on the input format of such type of file
 **/
bool Classifier::LoadFromStream(istream& is, const TrainOptions& options) {
    this->Clear();

    Index num_functions = 0;
    CHECK(static_cast<bool>(is >> num_functions));
    CHECK_GT(num_functions, static_cast<Index>(0));
    for (Index i = 0; i < num_functions; ++i)  {
        Function* function = FunctionFactory::LoadFromStream(is, options);
        CHECK_NE_NULL(function);
        this->Add(function);
        VMESSAGE(1, "Loaded classifier function for predicate " << function->GetId());
    }
    return true;
}

/**
 * Load from a directory with one file per predicate to be loaded.
 **/
bool Classifier::LoadFromDir(const string& dirname, const TrainOptions& options) {
    this->Clear();
    ifstream is(dirname + "/defs.txt");
    if (!is.good()) {
        WARN("Can not load classifier from dir " << dirname);
        return false;
    }

    map<string, string> predicate2type;
    string predicate;
    string type;

    while ((is >> predicate >> type)) {
        predicate2type[predicate] = type;
    }
    for(map<string, string>::const_iterator iter = predicate2type.begin();
        iter != predicate2type.end(); ++iter) {
        const FunctionFactory::FUNCTION_TYPE ftype =
                FunctionFactory::FunctionTypeFromName(iter->second);
        const string& filename = dirname + "/" + iter->first + ".dat";
        Function* function = FunctionFactory::LoadFromFile(
                filename, ftype, options);
        CHECK_NE_NULL(function);
        this->Add(function);
        VMESSAGE(1, "Loaded classifier function for predicate " <<
                 function->GetId() << " from file " << filename);
    }
    return true;
}
}  //end namespace Regularization
