#ifndef COLLECTIVE_CLASSIFIER_H
#define COLLECTIVE_CLASSIFIER_H

#include "classifier/classifier.h"


namespace Regularization
{
class Dataset;
class Examples;
class FOLKnowledgeBase;
class Predicates;

/*
 * Class storing a vector of functions. Each functions corresponds to a predicate.
 */
class CollectiveClassifier : public BaseClassifier
{
    public:

        /**
         * Constructor
         **/
        CollectiveClassifier(const BaseClassifier* old_classifier_,
                             const Predicates& predicates_,
                             const FOLKnowledgeBase& folKnowledgeBase_,
                             const Dataset& dataset_,
                             const Examples* train_examples_);  // training known examples, maybe NULL

        CollectiveClassifier(const CollectiveClassifier& classifier);

        virtual BaseClassifier* Clone() const;

        /**
         * Destructor
         **/
        virtual ~CollectiveClassifier();

        virtual void Clear();

    protected:
        virtual void InitValues(const BaseClassifier* classifier);
        virtual void InternalCopy(const BaseClassifier* classifier);

        // Own externally
        const FOLKnowledgeBase& folKnowledgeBase;
        const Dataset& dataset;
        const Examples* train_examples;  // may not be available, own externally.
};  // end CollectiveClassifier
}  // end namespace Regularization
#endif /* COLLECTIVE_CLASSIFIER_H */
