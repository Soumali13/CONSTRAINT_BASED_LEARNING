#ifndef CLASSIFIER_OUT_H
#define CLASSIFIER_OUT_H

#include <iosfwd>
#include <map>
#include <set>
#include <string>
#include <vector>

#include "functions/function.h"  // for Function::ID


namespace Regularization {
class Pattern;
class Examples;

/**********************************************************************
 * The output of the classifier. It stores the winner predicate, and the
 * score for each predicate, and the classification confidence.
 **********************************************************************/
class ClassifierOut
{
    public:
        /**
         * The key of the map is the function name, while the value is the correspondent
         * score/error/loss
         **/
        typedef std::map<const Function::ID, Value> FunctionsValues;

        /*******************************************************************
         * Constructors
         *******************************************************************/
        ClassifierOut() : pattern(NULL) {
        	this->Clear();
        }
        ClassifierOut(const ClassifierOut& out) = default;
        ClassifierOut(ClassifierOut&& out) = default;
        ClassifierOut& operator=(const ClassifierOut& out)  = default;

        inline const Pattern* GetPattern() const { return pattern; }
        inline void SetPattern(const Pattern* pattern_) {
            pattern = pattern_;
            this->Clear();
        }

        /******************************************************************
         * Check
         ******************************************************************/
        /**
         * check if a field higher than val exists
         **/
        bool HasHigher(const Value val) const;

        /**
         * check if a field lower than val exists
         **/
        bool HasLower(const Value val) const;

        /**
         * check if a field equal to val exists
         **/
        bool HasEqual(const Value val) const;

        /******************************************************************
         * Accessors
         ******************************************************************/
        /**
         * Get the id of the winner predicate
         **/
        inline Function::ID GetWinnerPredicate() const
        {
            return this->winner_predicate.first;
        }

        /**
         * Get the winner predicate score
         **/
        inline Value GetWinnerPredicateScore() const
        {
            return this->winner_predicate.second;
        }

        /**
         * Get the max value
         **/
        inline Value GetMaxScore() const
        {
            return this->max_score.second;
        }

        /**
         * Get the min value
         **/
        inline Value GetMinScore() const
        {
            return this->min_score.second;
        }

        /**
         * Get the i-th value
         **/
        Value GetScore(const Function::ID& id) const;

        /**
         * Get the scores map
         **/
        inline const FunctionsValues GetScores() const
        {
            return this->scores;
        }

        /*******************************************************************
         * Get infos
         *******************************************************************/

        /**
         * Get sum of all fields
         **/
        Value GetSum() const;

        /**
         * Get sum of absolute values of all fields
         * (useful before normalizing when some fields are negative)
         **/
        Value GetAbsSum() const;

        /**
         * Get the average of the fields
         **/
        Value GetAverage() const;

        /**
         * Get the entropy of the fields
         **/
        Value GetEntropy() const;

        /*******************************************************************
         * Mutators
         *******************************************************************/
        /*
         * Set the score for a predicate
         */
        void Set(const Function::ID& id, const Value score);

        /*******************************************************************
         * Clear the instance
         ******************************************************************/
        void Clear();

        /************************************************************
         * I/O
         ************************************************************/
        std::string ToString() const;
        void Print() const;
        void SaveToStream(std::ostream& io) const;
        void SaveScoresToStream(std::ostream& io) const;

        /*******************************************************************
         * Utility to manage with the scores
         *******************************************************************/
        /**
         * Add v to each score doing resync if resync==true
         **/
        void Add(const Value v, const bool resync = true);

        /**
         * Add a classifier output
         **/
        void Add(const ClassifierOut& classifier_out, const bool resync = true);

        /**
         * Scale the score by s
         **/
        void Scale(const Value s);

        /**
         * Limit the scores to v
         **/
        void Limit(const Value v);

        /*
         * Get a copy of the instance but restricted to some of the wanted classes.
         */
        ClassifierOut GetCopyRestrictedToClasses(const std::set<Function::ID>& wanted_classes) const;

    protected:
        /**
         * recompute the winner predicate (called by sync)
         **/
        void ComputeWinnerPredicate();

        /**
         * recompute the extreme values (called by sync)
         **/
        void ComputeExtremeValues();

        /**
          * Set or change the number of predicates, all previously stored
          * information is cleared. Use resize when is wanted to keep
          * previous info.
          **/
         void SetNumberOfClasses(const unsigned int n);

         /*******************************************************************
          * Resync the internal data after changes, always call this function
          * after an external change.
          *******************************************************************/
         inline void Sync() {
             this->ComputeWinnerPredicate();
             this->ComputeExtremeValues();
         }

        /**
         * Values
         **/
        FunctionsValues scores;

        /**
         * predicate with highest score
         **/
        std::pair<Function::ID, Value> max_score;

        /**
         * predicate with lowest score
         **/
        std::pair<Function::ID, Value> min_score;

        /**
         * Winner predicate and its score
         * Could be use a different politic from the highest score method
         **/
        std::pair<Function::ID, Value> winner_predicate;

        /*
         * Reference to the pattern and examples (not owned by this).
         */
        const Pattern* pattern;
}; // end ClassifierOut

class ResultSet {
public:
    ResultSet() = default;
    ResultSet(const ResultSet& s) = default;
    ResultSet& operator=(const ResultSet& s) = default;
    ResultSet(ResultSet&& s) = default;
    inline ClassifierOut& operator[](const unsigned int i) { return results_[i]; }
    inline const ClassifierOut& operator[](const unsigned int i) const { return results_[i]; }

    inline const ClassifierOut& Get(const unsigned int i) const { return results_[i]; }
    inline ClassifierOut* const GetMutable(const int i) { return &(results_[i]); }
    inline unsigned int Size() const { return results_.size(); }

    inline void Prealloc(const unsigned int size) {
        if (results_.size() != size) {
            results_.resize(size);
        }
    }
    inline void Add(const ClassifierOut& result) {
        results_.push_back(result);
    }
    ResultSet GetCopyRestrictedToClasses(const std::set<Function::ID>& wanted_classes) const;

    bool SaveToFile(const Examples* examples, const std::string& results_file) const;

    // Compare two result sets and dump the flips with respect to the threshold to the file.
    static void DumpFlips(
            const ResultSet& r1, const ResultSet& r2, const Value threshold, const std::string filename);

private:
    std::vector<ClassifierOut> results_;
};  // end ResultSet

} // end namespace Regularization
#endif /* CLASSIFIER_OUT_H */
