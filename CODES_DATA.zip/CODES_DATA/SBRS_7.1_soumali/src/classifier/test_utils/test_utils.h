#ifndef TEST_UTILS_H
#define TEST_UTILS_H

#include <iostream>
#include <map>
#include <set>
#include <string>

#include "classifier/confusion_table.h"
#include "constraints/dataset_constraint.h"
#include "train/trainer.h"


namespace Regularization {

class Classifier;
class CollectiveClassifier;
class Dataset;
class Examples;
class LossFunction;
class ResultSet;
class TrainOptions;

class TestUtils {
  public:
    // map metric -> result.
    typedef std::map<std::string, Value> Stats;

    // the type of test
    typedef enum
    {
        ARGMAX,
        MULTILABEL
    } TestType;

    /*
     * Computes the detailed results and a summary with a confusion matrix for the dataset
     * using the passed in classifier.
     */
    static bool RunTest(
            const BaseClassifier& classifier,
            const Dataset& dataset,
            const TestType& test_type,
            const std::set<Function::ID>& wanted_classes,
            const std::string& results_file,
            const std::string& summary_file,
            const std::string& roc_curve_file,
            const std::string& pr_curve_file,
            const bool get_micro_results,
            const Examples* examples,
            Stats* stats);

    /*
     * Given the detailed results computes a summary with a confusion
     * matrix for the dataset.
     */
    static bool RunTest(
            const ResultSet& results,
            const TestType& test_type,
            const std::string& results_file,
            const std::string& summary_file,
            const std::string& roc_curve_file,
            const std::string& pr_curve_file,
            const bool get_micro_results,
            const Examples* examples,
            Stats* stats);

    /*
     * Handy wrapper around RunTest that also takes care of preparing the directory for
     * the output and prints the summary of the results to the logs.
     * Used when a classifier is available.
     */
    static void PrintTest(
            const BaseClassifier& classifier,
            const Dataset& dataset,
            const std::string& results_file,
            const std::string& summary_file,
            const std::string& roc_curve_file,
            const std::string& pr_curve_file,
            const TrainOptions& options,
            const std::string& model_name,
            const TestType testType,
            const std::set<Function::ID>& wanted_classes,
            const Examples* examples,
            std::string* output,  // appended here
            Stats* output_stats);

    /*
     * Handy wrapper around RunTest that also takes care of preparing
     * the directory for the output and prints the summary of the results to the logs.
     * Used when the results of a classifier are already available and do not need to
     * be recomputed, for example in collective classification.
     */
    static void PrintTest(
            const std::string& results_file,
            const std::string& summary_file,
            const std::string& roc_curve_file,
            const std::string& pr_curve_file,
            const ResultSet& results,
            const TrainOptions& options,
            const std::string& model_name,
            const TestType testType,
            const Examples* examples,
            std::string* output,  // appended here
            Stats* output_stats);

    /**
     * Computes the constraints values over the dataset.
     * The output of the constraints is used as output value.
     * This function allows to compare how the constraints are effective in
     * learning versus if applied off line.
     */
    typedef Stats ConstraintsValue;
    static bool VerifyConstraints(const Trainer::ConstraintsSet& constraint_set,
            ConstraintsValue* constraints_value);

    // Select the type of test to perform
    static TestType TestTypeFromString(const std::string& test_type);

    // Run a quick test and compute confusion table for validation
    static bool RunValidation(
            const BaseClassifier& classifier,
            const Dataset& dataset,
            const TestType& test_type,
            const std::set<Function::ID>& wanted_classes,
            const bool get_micro_results,
            const std::string& roc_curve_file,
            const Examples* examples,
            Stats* stats);

};  // end TestUtils

}  // end namespace Regularization
#endif /* TEST_UTILS_H */
