#include "classifier/test_utils/test_utils.h"

#include "classifier/classifier.h"
#include "classifier/classifier_out.h"
#include "classifier/collective_classifier.h"
#include "data/pattern.h"
#include "data/examples.h"
#include "utils/file_utils.h"
#include "utils/gflags/gflags/gflags.h"
#include "utils/gtl_utils.h"
#include "utils/string_utils.h"

#include <deque>

DEFINE_double(classification_threshold, 0.5, "Threshold value for the classification test");

namespace Regularization {

/*
 * Handy wrapper around RunTest that also takes care of preparing the directory for
 * the output and prints the summary of the results to the logs.
 * Used when a classifier is available.
 */
void TestUtils::PrintTest(
        const BaseClassifier& classifier,
        const Dataset& dataset,
        const std::string& results_file,
        const std::string& summary_file,
        const std::string& roc_curve_file,
        const std::string& pr_curve_file,
        const TrainOptions& options, const std::string& model_name,
        const TestUtils::TestType testType,
        const std::set<Function::ID>& wanted_classes,
        const Examples* examples,
        std::string* output,
        TestUtils::Stats* output_stats) {
    RunTest(classifier, dataset, testType, wanted_classes,
            results_file, summary_file,
            roc_curve_file, pr_curve_file,
            options.UseMicroStatistics(), examples, output_stats);
    const std::string results_str =
            StringUtils::MapToString(*output_stats, "\n", " ", "\n");
    *output += StringUtils::StrCat(model_name, " ", results_file, "\n", results_str);
    MESSAGE("Results " << results_str);
    MESSAGE("Results saved in " << results_file);
}

/*
 * Handy wrapper around RunTest that also takes care of preparing
 * the directory for the output and prints the summary of the results to the logs.
 * Used when the results of a classifier are already available and do not need to
 * be recomputed, for example in collective classification.
 */
void TestUtils::PrintTest(
        const std::string& results_file,
        const std::string& summary_file,
        const std::string& roc_curve_file,
        const std::string& pr_curve_file,
        const ResultSet& results,
        const TrainOptions& options,
        const std::string& model_name,
        const TestUtils::TestType testType,
        const Examples* examples,
        std::string* output,
        TestUtils::Stats* output_stats) {
    RunTest(results, testType,
            results_file, summary_file,
            roc_curve_file, pr_curve_file,
            options.UseMicroStatistics(), examples, output_stats);
    const std::string results_str =
            StringUtils::MapToString(*output_stats, "\n", " ", "\n");
    *output += StringUtils::StrCat(model_name, " ", results_file, "\n", results_str);
    MESSAGE("Results " << results_str);
    MESSAGE("Results saved in " << results_file);
}

/*
 * Computes the vector of confusion matrix for the dataset using the passed in
 * classifier. Each confusion matrix corresponds to different value of the
 * classification threshold (static)
 */
bool TestUtils::RunTest(
        const BaseClassifier& classifier,
        const Dataset& dataset,
        const TestType& test_type,
        const std::set<Function::ID>& wanted_classes,
        const std::string& results_file,
        const std::string& summary_file,
        const std::string& roc_curve_file,
        const std::string& pr_curve_file,
        const bool get_micro_results,
        const Examples* examples,
        TestUtils::Stats* stats) {
    CHECK_NE_NULL(stats);

    // Classify
    ResultSet results;
    classifier.Classify(dataset, &results);
    if (!wanted_classes.empty()) {
        results = results.GetCopyRestrictedToClasses(wanted_classes);
    }

    return TestUtils::RunTest(results, test_type, results_file,
                              summary_file, roc_curve_file, pr_curve_file,
                              get_micro_results, examples, stats);
}

bool TestUtils::RunTest(
        const ResultSet& results,
        // dataset is in classifier, just pass the new example set (not seen in training)
        const TestType& test_type,
        const std::string& results_file,
        const std::string& summary_file,
        const std::string& roc_curve_file,
        const std::string& pr_curve_file,
        const bool get_micro_results,
        const Examples* examples,
        TestUtils::Stats* stats) {
    CHECK_NE_NULL(stats);
    CHECK_NE_NULL(examples);

    const std::string dirname = FileUtils::DirName(results_file);
    FileUtils::MakePathOrDie(dirname);

    if (!results.SaveToFile(examples, results_file)) {
        return false;
    }

    // save the summary file
    std::ofstream summary_file_stream(summary_file.c_str());
    ScopedPtr<ClassificationStats> res(NULL);
    if (test_type == ARGMAX)
        res.Reset(new ArgmaxClassificationStats(results, examples, FLAGS_classification_threshold));
    else if (test_type == MULTILABEL)
        res.Reset(new ClassificationStats(results, examples, FLAGS_classification_threshold));
    else
        FAULT("Unknown classification type");

    res->Add(results);
    // Print
    res->Save(summary_file_stream);
    // save the results file
    VMESSAGE(1, "Results saved in " << results_file);

    // get results for cross validation
    *stats = (get_micro_results ? res->GetMicroResults() : res->GetMacroResults());

    // close output file
    summary_file_stream.close();

    if (!roc_curve_file.empty()) {
        ClassificationStats::ROC roc;
        res->GetROC(100, &roc);
        VMESSAGE(1, "Roc curve saved in " << roc_curve_file);
        StringUtils::ToFile(StringUtils::ContainerToString(roc, "\n"), roc_curve_file);
    }

    if (!pr_curve_file.empty()) {
        ClassificationStats::ROC roc;
        res->GetPRCurve(100, &roc);
        VMESSAGE(1, "PR curve saved in " << pr_curve_file);
        StringUtils::ToFile(StringUtils::ContainerToString(roc, "\n"), pr_curve_file);
    }

    return true;
}

/*
 * Computes the degree of satisfaction of the constraints on the dataset
 */
bool TestUtils::VerifyConstraints(const Trainer::ConstraintsSet& constraint_set,
                                  ConstraintsValue* constraint_values) {
    if (constraint_set.empty())
        return false;
    Value sum = static_cast<Value>(0);

    for (Trainer::ConstraintsSet::const_iterator it = constraint_set.begin();
         it != constraint_set.end(); ++it) {
        const Value val = it->second->Eval(static_cast<Value>(1), NULL);
        sum += val;

        // Save the constraint value if requested.
        if (constraint_values != NULL) {
            (*constraint_values)[it->first] = val;
        }
    }

    return true;
}


// Select the type of test to perform (static)
TestUtils::TestType TestUtils::TestTypeFromString(const std::string& test_type)
{
    if (test_type == "ARGMAX") {
        MESSAGE("Test type ARGMAX");
        return ARGMAX;
    } else if (test_type == "MULTILABEL") {
        MESSAGE("Test type MULTILABEL");
        return MULTILABEL;
    } else {
        FAULT("Unknown test type: " << test_type);
    }

    return MULTILABEL;
}

bool TestUtils::RunValidation(
        const BaseClassifier& classifier,
        const Dataset& dataset,
        const TestType& test_type,
        const std::set<Function::ID>& wanted_classes,
        const bool get_micro_results,
        const std::string& roc_curve_file,
        const Examples* examples,
        TestUtils::Stats* stats) {
    CHECK_NE_NULL(stats);
    // Classify
    ResultSet results;
    classifier.Classify(dataset, &results);
    if (!wanted_classes.empty()) {
        results = results.GetCopyRestrictedToClasses(wanted_classes);
    }

    ScopedPtr<ClassificationStats> res(NULL);
    if (test_type == ARGMAX)
        res.Reset(new ArgmaxClassificationStats(results, examples, FLAGS_classification_threshold));
    else if (test_type == MULTILABEL)
        res.Reset(new ClassificationStats(results, examples, FLAGS_classification_threshold));
    else
        FAULT("Unknown classification type");

    res->Add(results);

    // get results for cross validation
    if (get_micro_results) {
        *stats = res->GetMicroResults();
    } else {
        *stats = res->GetMacroResults();
    }

    if (!roc_curve_file.empty()) {
        ClassificationStats::ROC roc;
        res->GetROC(100, &roc);
        StringUtils::ToFile(StringUtils::ContainerToString(roc, "\n"), roc_curve_file);
    }
    return true;
}

} // end namespace Regularization
