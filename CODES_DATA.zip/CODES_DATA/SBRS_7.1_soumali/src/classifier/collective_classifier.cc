#include "classifier/collective_classifier.h"
#include "classifier/functions/function_factory.h"
#include "constraints/constraints_factory.h"
#include "classifier/classifier_out.h"
#include "data/dataset.h"
#include "data/examples.h"
#include "data/pattern.h"
#include "data/FOL_knowledge_base.h"
#include "data/FOL_formula.h"
#include "data/predicates.h"
#include "train/trainer.h"


using namespace std;

namespace Regularization
{
// Standard constructor.
CollectiveClassifier::CollectiveClassifier(
        const BaseClassifier* old_classifier,
        const Predicates& predicates_,
        const FOLKnowledgeBase& folKnowledgeBase_,
        const Dataset& dataset_,
        const Examples* train_examples_) :
        BaseClassifier(predicates_),
        folKnowledgeBase(folKnowledgeBase_),
        dataset(dataset_),
        train_examples(train_examples_) {
    VMESSAGE(1, "Creating a collective classifier with" <<
             (old_classifier == NULL ? " no" : "") << " prior classifier.");

    const Predicates::PredicatesMap& predicates_map = predicates_.GetPredicatesMap();
    for (Predicates::PredicatesMap::const_iterator it = predicates_map.begin();
         it != predicates_map.end(); ++it) {
        const Predicate& predicate = it->second;
        const Dataset* domain_dataset = dataset_.GetDomainDataset(
                predicate.GetDomainString());
        CHECK_NE_NULL(domain_dataset);

        Function* function = NULL;
        if (predicate.GetPredicateType() == Function::MAP_GIVEN) {
            function = FunctionFactory::BuildGivenFunction(predicate, train_examples);
        } else {
            // No examples are passed when building a collective classifier.
            // Examples will be dealt later by InitFromExamples() called from Init()
            function = FunctionFactory::BuildMapFunction(predicate, *domain_dataset, NULL);
        }

        if (function != NULL) {
            // Add the function to the classifier
            this->Add(function);
        }
    }

    // Initialize the functionValuesMap of the functions with
    // the results from a previous classifier or the priors.
    VMESSAGE(1, "Init values from previous classifier or priors");
    this->InitValues(old_classifier);
}

CollectiveClassifier::CollectiveClassifier(const CollectiveClassifier& classifier) :
    BaseClassifier(classifier),
    folKnowledgeBase(classifier.folKnowledgeBase),
    dataset(classifier.dataset),
    train_examples(classifier.train_examples) {
}

BaseClassifier* CollectiveClassifier::Clone() const {
    BaseClassifier* classifier = new CollectiveClassifier(*this);
    return classifier;
}

void CollectiveClassifier::InternalCopy(const BaseClassifier* classifier) {
    // Can copy only from a CollectiveClassifier.
    const CollectiveClassifier* cc = dynamic_cast<const CollectiveClassifier*>(classifier);
    CHECK_NE_NULL(cc);

    // These can not be moved and must be consistent across the copied data.
    CHECK_EQ(&folKnowledgeBase, &cc->folKnowledgeBase);
    CHECK_EQ(&dataset, &cc->dataset);
    CHECK_EQ(train_examples, cc->train_examples);
}

CollectiveClassifier::~CollectiveClassifier() { }

void CollectiveClassifier::Clear() {
    BaseClassifier::Clear();
}

/**********************************************
 * INIT FUNCTIONS OF CLASSIFIER
 **********************************************/

// Values can be initialized from a pre-learned function or a prior.
// If examples are available, they will provide the prior value instead for the covered patterns.
void CollectiveClassifier::InitValues(const BaseClassifier* classifier) {
    for (Classifier::MapContainer::iterator it = mapFunctionContainer.begin();
         it != mapFunctionContainer.end(); ++it) {
        const Function::ID& id = it->first;
        MapFunction* init_function = it->second;
        const LearnFunction* lfunction = (classifier != NULL ?
                dynamic_cast<const LearnFunction*>(&(classifier->GetFunctionByIDOrDie(id))) :
                NULL);
        CHECK_NE_NULL(predicates.Get(id));
        CHECK(init_function->Init(
                lfunction, train_examples, predicates.Get(id)->GetDefaultValue()));
    }
}

} //end namespace Regularization
