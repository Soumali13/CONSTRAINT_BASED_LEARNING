#ifndef CONFUSION_TABLE_H
#define CONFUSION_TABLE_H

#include <deque>  // for ROC
#include <map>
#include "classifier/classifier.h"

namespace Regularization
{

/*
 * Interface class
 */
class ClassificationStats {
public:
    ClassificationStats(const ResultSet& results, const Examples* examples_, const Value threshold_);
    virtual ~ClassificationStats() { }

    /**
     * Add a result to the table
     **/
    virtual void Add(const ClassifierOut& result);
    virtual void Add(const ResultSet& results);

    /**************************************************
     * performance parameters per predicate
     *************************************************/
    // accuracy
    Value GetAccuracy(const Function::ID& id) const;
    // recall per predicate
    Value GetRecall(const Function::ID& id) const;
    // precision per predicate
    Value GetPrecision(const Function::ID& id) const;
    // F1 per predicate
    Value GetF1(const Function::ID& id) const;
    // specificity per predicate
    Value GetSpecificity(const Function::ID& id) const;
    // AUC of the ROC curve per predicate.
    Value GetROCAUC(const Function::ID& id) const;
    // AUC of the PR curve per predicate.
    Value GetPRAUC(const Function::ID& id) const;

    /**************************************************
     * Macro and micro accuracy evaluations, if the vector passed in is not NULL
     * it also returns the performance value broken down by predicate.
     *************************************************/
    virtual Value GetMacroAccuracy(std::map<std::string, Value>* predicate_by_predicate = NULL) const;
    // macro recall
    virtual Value GetMacroRecall(std::map<std::string, Value>* predicate_by_predicate = NULL) const;
    // macro precision
    virtual Value GetMacroPrecision(std::map<std::string, Value>* predicate_by_predicate = NULL) const;
    // Macro F1
    virtual Value GetMacroF1(std::map<std::string, Value>* predicate_by_predicate = NULL) const;
    // Macro specificity
    virtual Value GetMacroSpecificity(std::map<std::string, Value>* predicate_by_predicate = NULL) const;
    // AUC as far as I know this can only be done at the macro level.
    virtual Value GetPRAUC(std::map<std::string, Value>* predicate_by_predicate = NULL) const;
    virtual Value GetROCAUC(std::map<std::string, Value>* predicate_by_predicate = NULL) const;
    // micro accuracy
    virtual Value GetMicroAccuracy() const;
    // micro recall
    virtual Value GetMicroRecall() const;
    // micro precision
    virtual Value GetMicroPrecision() const;
    // micro F1
    virtual Value GetMicroF1() const;
    // micro specificity
    virtual Value GetMicroSpecificity() const;
    // global micro statistics
    virtual std::map<std::string, Value> GetMicroResults() const;
    // global macro statistics
    virtual std::map<std::string, Value> GetMacroResults() const;

    typedef std::deque<std::pair<Value, Value> > ROC;
    virtual void GetPRCurve(const int max_samples, ROC* roc) const;
    virtual void GetPRCurveForFunction(
            const Function::ID& id, const int max_samples, ROC* roc) const;
    virtual void GetROC(const int max_samples, ROC* roc) const;
    virtual void GetROCForFunction(
            const Function::ID& id, const int max_samples, ROC* roc) const;

    /***********************************************************
     * I/O
     ***********************************************************/
    virtual void Save(std::ostream& out) const;
    virtual bool SaveToFile(std::string& filename) const;
    virtual void Print() const;

    typedef std::multimap<Value, Value> Score2Target;
    struct PredicateStatistics {
        long TP;
        long TN;
        long FP;
        long FN;
        long sumPositiveTargets;
        long sumNegativeTargets;
        // scores and associated targets, kept sorted.
        // This allows to easily compute AUC.
        Score2Target score2target;
        std::string id;

        PredicateStatistics() {
            Init();
        }

        PredicateStatistics(const Function::ID& id_) : id(id_) {
            Init();
        }
        void Init() {
            TP = 0;
            TN = 0;
            FP = 0;
            FN = 0;
            sumPositiveTargets = 0;
            sumNegativeTargets = 0;
        }
    };  // end PredicateStatistics

protected:
    Value threshold;

    /* The map of the statistics for each predicate. The key is the name of the predicate
     * predicate while the value is the correspondent statistics
     */
    typedef std::map<std::string, PredicateStatistics> PredicatesStatistics;
    PredicatesStatistics predicatesStatistics;

    // Overall PredicateStatistics, predicate levels are in predicatesStatistics.
    PredicateStatistics globalStatistics;

    const Examples* examples;
};  // end ClassificationStats

class ArgmaxClassificationStats : public ClassificationStats {
public:
    ArgmaxClassificationStats(
            const ResultSet& results, const Examples* examples_, const Value threshold_);
    virtual ~ArgmaxClassificationStats() { }

protected:
    /*
     * The map represent the confusion table. The key of the map is the name of the
     * actual function, while the value is the map of the predicted value. The key
     * of the inner map is the name of the predicted function while the value is
     * the predicted value.
     * For instance
     * -----------------------------------------------
       ----------------------      Predicted
       -----------------------------------------------
       --        -- f1   -- | f1:   | f2:   |
       -- Actual -------------------------------------
       --        -- f2   -- | f1:   | f2:   |
       -----------------------------------------------
     */
    typedef std::map<std::string, long> TableRow;
    typedef std::map<std::string, TableRow > Table;
    Table argmax_confusion_table;

    virtual void Add(const ClassifierOut& result);
    virtual void Save(std::ostream& out) const;
};

} // end namespace Regularization
#endif /* CONFUSION_TABLE_H */
