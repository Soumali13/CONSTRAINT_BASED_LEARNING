#include "classifier/classifier_out.h"

#include <cmath>
#include <iomanip>
#include <iostream>
#include <limits>
#include <set>

#include "data/examples.h"
#include "data/pattern.h"
#include "utils/file_utils.h"
#include "utils/string_utils.h"
#include "utils/stl_utils.h"


using namespace std;

namespace Regularization {

/*******************************************************************
 * Clear the instance
 ******************************************************************/
void ClassifierOut::Clear() {
    this->winner_predicate.first = "";
    this->winner_predicate.second = static_cast<Value>(0);
    this->max_score.second = static_cast<Value> (std::numeric_limits<int>::min());
    this->min_score.second = static_cast<Value> (std::numeric_limits<int>::max());

    if (this->scores.size() > 0) {
        this->scores.clear();
    }
}
/**
 * Compute the winner predicate
 * In this case the winner predicate is the predicate with highest score
 **/
void ClassifierOut::ComputeWinnerPredicate()
{
    if (this->scores.empty()) {
        return;
    }
    this->winner_predicate.first = this->scores.begin()->first;
    this->winner_predicate.second = this->scores.begin()->second;

    for (FunctionsValues::const_iterator iter = this->scores.begin();
         iter != this->scores.end(); ++iter) {
        if (this->scores[iter->first] > this->winner_predicate.second) {
            this->winner_predicate.first = iter->first;
            this->winner_predicate.second = iter->second;
        }
    }
}

/*
 * Get a copy of the instance but restricted to some of the wanted classes.
 */
ClassifierOut ClassifierOut::GetCopyRestrictedToClasses(
        const std::set<Function::ID>& wanted_classes) const {
    ClassifierOut out;
    out.SetPattern(this->GetPattern());
    for (FunctionsValues::const_iterator iter = this->scores.begin();
         iter != this->scores.end(); ++iter) {
        if (std::Has(wanted_classes, iter->first)) {
            out.Set(iter->first, iter->second);
        }
    }
    out.Sync();
    return out;
}

ResultSet ResultSet::GetCopyRestrictedToClasses(
        const std::set<Function::ID>& wanted_classes) const {
    ResultSet results = *this;
    results.Prealloc(results_.size());
    for (unsigned int i = 0; i < results_.size(); ++i) {
        *(results.GetMutable(i)) = results_[i].GetCopyRestrictedToClasses(wanted_classes);
    }
    return results;
}

/**
 * Compute the extreme values
 **/
void ClassifierOut::ComputeExtremeValues()
{
    if (this->scores.empty()) {
        return;
    }
    this->max_score.first = this->scores.begin()->first;
    this->min_score.first = this->scores.begin()->first;
    this->max_score.second = this->scores.begin()->second;
    this->min_score.second = this->scores.begin()->second;

    for (FunctionsValues::const_iterator iter = this->scores.begin(); iter != this->scores.end(); ++iter)
    {
        if (this->scores[iter->first] > this->max_score.second)
        {
            this->max_score.first = iter->first;
            this->max_score.second = iter->second;
        }

        if (this->scores[iter->first] < this->min_score.second)
        {
            this->min_score.first = iter->first;
            this->min_score.second = iter->second;
        }
    }
}

/**
 * Get the i-th score
 **/
Value ClassifierOut::GetScore(const Function::ID& id) const {
    FunctionsValues::const_iterator iter = this->scores.find(id);
    if(iter == this->scores.end()) {
        FAULT("Trying to access element " << id << " which has no score ");
    }
    return iter->second;
}

/**
 * Get score sum
 **/
Value ClassifierOut::GetSum() const
{
    Value sum = static_cast<Value>(0);

    for (FunctionsValues::const_iterator iter = this->scores.begin(); iter != this->scores.end(); ++iter)
    {
        sum += iter->second;
    }

    return sum;
}

/**
 * Get score abs sum
 **/
Value ClassifierOut::GetAbsSum() const
{
    Value sum = static_cast<Value>(0);

    for (FunctionsValues::const_iterator iter = this->scores.begin(); iter != this->scores.end(); ++iter)
    {
        sum += std::abs(static_cast<Value> (iter->second));
    }

    return sum;
}

/**
 * Get the score average
 **/
Value ClassifierOut::GetAverage() const
{
    if (this->scores.empty())
        return static_cast<Value>(0.0);

    return this->GetSum() / static_cast<Value> (this->scores.size());
}

/**
 * Get the output entropy (assumes to get as input a vector of probabilities)
 **/
Value ClassifierOut::GetEntropy() const
{
    if (this->scores.empty())
        return static_cast<Value>(0.0);

    if (this->HasHigher(1.0) || this->HasLower(0.0) || fabs(this->GetSum() - 1.0) > 0.00001)
    {
        WARN("Map of scores is not containing probabilities, can not compute entropy");
        return static_cast<Value>(0.0);
    }

    Value entropy = static_cast<Value>(0.0);

    for (FunctionsValues::const_iterator iter = this->scores.begin();
            iter != this->scores.end(); ++iter)
    {
        Value val = iter->second;
        entropy += val * std::log(val);
    }

    return entropy;
}

/**
 * Return true if a score is higher than score
 **/
bool ClassifierOut::HasHigher(const Value score) const
{
    for (FunctionsValues::const_iterator iter = this->scores.begin(); iter != this->scores.end(); ++iter)
    {
        if (iter->second > score)
            return true;
    }

    return false;
}

/**
 * Return true if a score is lower than score
 **/
bool ClassifierOut::HasLower(const Value score) const
{
    for (FunctionsValues::const_iterator iter = this->scores.begin(); iter != this->scores.end(); ++iter)
    {
        if (iter->second < score)
            return true;
    }

    return false;
}

/**
 * Return true if a score is equal to score
 **/
bool ClassifierOut::HasEqual(const Value score) const
{
    for (FunctionsValues::const_iterator iter = this->scores.begin(); iter != this->scores.end(); ++iter)
    {
        if (iter->second == score)
            return true;
    }

    return false;
}

/**
 * Set the score value for a specified predicate
 **/
void ClassifierOut::Set(const Function::ID& id, const Value score)
{
    this->scores[id] = score;

    if (score > this->max_score.second)
    {
        this->max_score.first = id;
        this->max_score.second = score;
        this->winner_predicate.first = id;
        this->winner_predicate.second = score;
    }

    else if (score < this->min_score.second)
    {
        this->min_score.first = id;
        this->min_score.second = score;
    }
}

/**
 * I/O
 **/
std::string ClassifierOut::ToString() const
{
    CHECK_NE_NULL(pattern);
    ostringstream os;
    os << pattern->GetName() <<"\t";
    this->SaveScoresToStream(os);
    return os.str();
}

void ClassifierOut::Print() const
{
    CHECK_NE_NULL(pattern);
    cout << pattern->GetName() <<"\t";
    this->SaveScoresToStream(cout);
}

void ClassifierOut::SaveToStream(std::ostream& io) const
{
    CHECK_NE_NULL(pattern);
	io << pattern->GetName() <<"\t";
	this->SaveScoresToStream(io);
}

/**
 * I/O
 **/
void ClassifierOut::SaveScoresToStream(std::ostream& io) const
{
    if (this->scores.size() > 0)
    {
        unsigned int cnt = 0;
        for (FunctionsValues::const_iterator iter = this->scores.begin();
                iter != this->scores.end(); ++iter)
       {
            io << iter->first << ":" << setiosflags(ios::fixed) << iter->second << resetiosflags(ios::fixed);
            if (cnt < this->scores.size() - 1)
                io<< ",";
            ++cnt;
       }
    }
    else
    {
        io << "NO SCORES";
    }

    io << endl;
}
/*******************************************************************
 * Utility to manage with the scores
 *******************************************************************/

/**
 * Add v to each score
 **/
void ClassifierOut::Add(const Value v, bool resync)
{
    for (FunctionsValues::const_iterator iter = this->scores.begin(); iter != this->scores.end(); ++iter)
    {
        this->Set(iter->first, this->GetScore(iter->first) + v);
    }

    if (resync)
    {
        this->Sync();
    }
}

/**
 * Add a classifier output
 **/
void ClassifierOut::Add(const ClassifierOut& classifier_out, const bool resync)
{
    FunctionsValues new_scores = classifier_out.GetScores();

    for (FunctionsValues::const_iterator iter = new_scores.begin(); iter != new_scores.end(); ++iter)
    {
        if (this->scores.find(iter->first) != this->scores.end())
        {
            this->Set(iter->first, this->GetScore(iter->first) + iter->second);
        }

        else
            this->scores[iter->first] = iter->second;
    }

    if (resync)
    {
        this->Sync();
    }
}

/**
 * Scale scores by factor s
 **/
void ClassifierOut::Scale(const Value s)
{
    for (FunctionsValues::iterator iter = this->scores.begin(); iter != this->scores.end(); ++iter)
    {
        iter->second *= s;
    }

    this->Sync();
}

/**
 * Limit the scores to v
 **/
void ClassifierOut::Limit(const Value v) {
    for (FunctionsValues::iterator iter = this->scores.begin(); iter != this->scores.end(); ++iter) {
        if (iter->second > v) {
            iter->second = v;
        }
    }

    this->Sync();
}

bool ResultSet::SaveToFile(const Examples* examples, const std::string& results_file) const {
    const std::string dirname = FileUtils::DirName(results_file);
    FileUtils::MakePathOrDie(dirname);

    // Prepare the output
    std::ofstream of(results_file.c_str());
    if (!of.good()) {
        WARN("Can not save to file: " << results_file);
        return false;
    }

    // Print
    for (unsigned int i = 0; i < this->Size(); ++i) {
        const ClassifierOut& result = this->Get(i);
        const Pattern* pattern = result.GetPattern();
        CHECK_NE_NULL(pattern);
        of << pattern->GetName() <<"\t";
        if (examples) {
            const Examples::PerPatternExamples* pexamples =
                    examples->GetExamplesForPattern(pattern->GetName());
            if (pexamples != NULL) {
                unsigned int cnt = 0;
                for (Examples::PerPatternExamples::const_iterator it = pexamples->begin();
                        it != pexamples->end(); it++) {
                    of << (*it)->id << ":" << (*it)->value;
                    if (cnt < pexamples->size() - 1)
                        of << ",";
                    ++cnt;
                }
            }
            of <<"\t";
        }
        result.SaveScoresToStream(of);
    }
    of.close();
    return true;
}

// Compare two result sets and dump the flips with respect to the threshold to the file.
// TODO(michi): check that it works.
/* static */
void ResultSet::DumpFlips(
        const ResultSet& r1, const ResultSet& r2, const Value threshold, const std::string filename) {
    CHECK_EQ(r1.Size(), r2.Size());

    ResultSet output;
    for (unsigned int i = 0; i < r1.Size(); ++i) {
        ClassifierOut diff;

        const ClassifierOut& o1 = r1.Get(i);
        const Pattern* p1 = o1.GetPattern();
        CHECK_NE_NULL(p1);
        diff.SetPattern(p1);

        const ClassifierOut& o2 = r2.Get(i);
        const Pattern* p2 = o2.GetPattern();
        CHECK_NE_NULL(p2);
        CHECK_EQ(p1->GetName(), p2->GetName());
        const ClassifierOut::FunctionsValues& scores1 = o1.GetScores();
        const ClassifierOut::FunctionsValues& scores2 = o2.GetScores();
        for (ClassifierOut::FunctionsValues::const_iterator iter1 = scores1.begin();
             iter1 != scores1.end();
             ++iter1) {
            ClassifierOut::FunctionsValues::const_iterator iter2 = scores2.find(iter1->first);
            CHECK(iter2 != scores2.end());
            if ((iter1->second < threshold && iter2->second >= threshold) ||
                (iter1->second >= threshold && iter2->second < threshold)) {
                diff.Set(iter2->first, (iter2->second >= threshold ? 1 : 0));
            }
        }

        output.Add(diff);
    }
    CHECK(output.SaveToFile(NULL, filename));
}

/*******************************************************************
 * Merging two outputs
 *******************************************************************/

/**
 * Merge the list of classifier_outs into the classifier out (static)
 */

/*
ClassifierOut* ClassifierOut::Merge(const Classifier::ResultsSet& classifier_out_list)
{
    const Pattern& pattern = ;
    ClassifierOut* classifier_out = new ClassifierOut(pattern);

    // fill the classifier_out
    for (unsigned int i = 0; i < classifier_out_list.size(); ++i)
    {
        classifier_out->Add(*(classifier_out_list[i]), false);
    }
    classifier_out->Sync();

    return classifier_out;
}

ResultSet::ResultSet(const ResultSet& s) {
    Prealloc(s.Size());
    for (unsigned int i = 0; i < s.Size(); ++i)
        results_[i] = s.results_[i];
}

ResultSet& ResultSet::operator=(const ResultSet& s) {
    if (&s == this)  return *this;  // no self assignment.
    Prealloc(s.Size());
    for (unsigned int i = 0; i < s.Size(); ++i)
        results_[i] = s.results_[i];
    return *this;
}

ResultSet::ResultSet(ResultSet&& s) : results_{std::move(s.results_)} {} */

} // end namespace Regularization
