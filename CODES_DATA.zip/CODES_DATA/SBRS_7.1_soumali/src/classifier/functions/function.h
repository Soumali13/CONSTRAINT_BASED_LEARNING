/*
 * File:   function.h
 * Author: Tore
 *
 * Created on 24 gennaio 2011, 10.07
 */
#ifndef FUNCTION_H
#define FUNCTION_H

#include <string>
#include "data/basic_data_types.h"


namespace Regularization {
class Pattern;

/*
 * Function definitions. This abstract class provides the generic interface for a
 * function. It should not be instantiated directly but through one of its derived
 * classes
 */
class Function {
public:
    // Function ID
    typedef std::string ID;

    typedef enum
    {
        LEARN = 0, MAP_GIVEN = 1, MAP_LEARN = 2, INVALID = 3
    } TYPE;

    static TYPE TypeFromStringOrDie(const std::string& str);
    static std::string TypeToString(const TYPE pt);

    // Arity of the function
    typedef Index Arity;

    /********************************
     * Constructors.
     ********************************/
    Function(const ID& id_, const TYPE type_, const Arity arity_, const std::string& domain_);
    Function(const Function& function);

    /*
     * Destructor
     */
    virtual ~Function() {
    }

    /*
     * Get the ID of the function
     */
    inline const ID& GetId() const {
        return id;
    }

    /*
     * Get the type of predicate
     */
    inline TYPE GetType() const
    {
        return type;
    }

    /**
     * Get arity of the function
     **/
    inline Index GetArity() const
    {
        return arity;
    }

    /**
     * Get domain of the function
     **/
    inline const std::string& GetDomain() const
    {
        return domain;
    }

    // Size of the function
    virtual Index Size() const = 0;

    /**************************************************************
     * Eval
     **************************************************************/

    // Eval the function on the pattern of the test set
    // only kernel machine can evaluate a pattern not in training
    virtual Value Eval(const Pattern& pattern) const = 0;

    /***********************************************************
        // Clean up the function.
     ***********************************************************/
    virtual void Clear();

    /*************************************************************************************
     * I/O (FOR ALL TYPE OF FUNCTIONS)
     ***************************************************************************************/
    virtual bool LoadFromFile(const std::string& filename);
    virtual bool LoadFromStream(std::istream& is);
    virtual bool SaveToFile(const std::string& filename) const;
    virtual bool SaveToStream(std::ostream& is) const;
    virtual std::string ToString() const;
    virtual void Print() const;
    virtual Function* Clone() const = 0;

protected:
    ID id;
    TYPE type;
    Arity arity;
    // Domain of the function.
    std::string domain;

    // Implemented by subclasses to deal to low level I/O.
    virtual bool InternalLoadFromStream(std::istream& is) = 0;
    virtual bool InternalSaveToStream(std::ostream& os) const = 0;
    virtual void InternalClear() = 0;
}; // end Function
}

#endif // FUNCTION_H
