#include "classifier/functions/given_function.h"

#include "data/pattern.h"
#include "data/examples.h"
#include "utils/general.h"
#include "utils/string_utils.h"


using namespace std;

namespace Regularization
{

GivenFunction::GivenFunction(
        const Function::ID& id_, const Function::TYPE predicate_type_,
        const Function::Arity arity_, const std::string& domain_,
        const Value default_value_, const Examples* examples_) :
        Function(id_, predicate_type_, arity_, domain_),
        default_value(default_value_) {
    if (examples_ == NULL || examples_->Size() == 0) {
        return;
    }
    const Examples::PerFunctionExamples* examplesPredicate = examples_->GetExamplesForPredicate(id_);
    if (examplesPredicate == NULL) {
        return;  // no examples available.
    }
    // for each example in the multimap
    for (Examples::PerFunctionExamples::const_iterator it = examplesPredicate->begin();
         it != examplesPredicate->end(); ++it) {
        const Examples::Example* example = *it;
        functionValueMap[example->pattern] = example->value;
    }
}

/**
 * Copy constructor:
 */
GivenFunction::GivenFunction(const GivenFunction& givenFunction) :
            Function(givenFunction.GetId(), givenFunction.GetType(),
                     givenFunction.GetArity(), givenFunction.GetDomain()) {
    const FunctionValueMap& gmap = givenFunction.GetMap();
    for (FunctionValueMap::const_iterator iter = gmap.begin(); iter != gmap.end(); ++iter) {
        functionValueMap[iter->first] = iter->second;
    }
}

Function* GivenFunction::Clone() const {
    return new GivenFunction(*this);
}

Value GivenFunction::Eval(const Pattern& pattern) const {
    CHECK_EQ_WITH_MESSAGE(pattern.GetDomain(), this->domain,
            "Can not eval pattern from wrong domain " + pattern.GetDomain() + " " + this->domain);
    const string patternName = pattern.GetName();
    FunctionValueMap::const_iterator iter = functionValueMap.find(patternName);
    return (iter != functionValueMap.end() ? iter->second : default_value);
}

void GivenFunction::InternalClear() {
    functionValueMap.clear();
}

/**
 * Save To stream
 **/
bool GivenFunction::InternalSaveToStream(ostream& os) const
{
    const int size = functionValueMap.size();
    os <<id <<";";
    if (this->type == Function::MAP_GIVEN)
        os <<"GIVEN";
    else  // can it happen?
        os <<"LEARN";
    if (size > 0)
        os <<";";
    int cnt = 0;
    for (FunctionValueMap::const_iterator iter = functionValueMap.begin();
         iter != functionValueMap.end(); iter++, cnt++)
    {
        os << iter->first << ":" << iter->second;
        if (cnt < size -1)
            os << ",";
    }
    os << endl;
    return true;
}

bool GivenFunction::InternalLoadFromStream(istream& is)
{
    string string_values;
    CHECK(static_cast<bool>(is >> string_values));
    map<string, Value> values_map;
    StringUtils::SplitToMapByType(
            string_values, &values_map, ",", ":", static_cast<Value>(0), false);

    CHECK_EQ(values_map.size(), functionValueMap.size());
    for (map<string,Value>::const_iterator it = values_map.begin();
         it != values_map.end(); ++it) {
        functionValueMap[it->first] = values_map[it->first];
    }
    return true;
}

} // end Regularization
