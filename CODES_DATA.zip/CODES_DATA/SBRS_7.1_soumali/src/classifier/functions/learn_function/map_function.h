/*
 * File:   map_function.h
 * Author: Tore
 *
 * Created on 24 gennaio 2011, 12.07
 */

#ifndef MAP_FUNCTION_H
#define MAP_FUNCTION_H

#include <set>
#include <vector>
#include "classifier/functions/function.h"
#include "classifier/functions/learn_function/cached_learn_function.h"
#include "data/examples.h"

namespace Regularization
{

class Predicate;

class MapFunction : public LearnFunction {
public:
    /************************************************************
     * Constructors/Destructors.
     ************************************************************/

    /**
     * Build a map function
     */
    MapFunction(const Function::ID id_, const Function::TYPE predicate_type_,
            const Function::Arity arity, const std::string& domain_,
            const Value bias_,
            const Dataset* dataset_,  // if available used to set up the frozen indexes.
            const Examples* examples);

    /**
     * Copy constructor
     */
    MapFunction(const MapFunction& mapFunction_);

    /**
     * Destructors.
     */
    virtual ~MapFunction() {
    }

    Function* Clone() const;

    /***********************************************************
     * Set the values for map functions
     ***********************************************************/
    // Used to set the values for elements for which training data is available
    // during collective classification.
    virtual void SetValue(const std::string& patternName, const Value val);

    /**************************************************************
     * Error / Derivative Error
     **************************************************************/
    virtual bool AccumulateGradientInternal(
            const Pattern& pattern, const Value weight, Math::Vector<Value>* derivative) const;

    // Eval the regularization error using the pre-computed internal dataset and
    // the internal GramMatrix
    virtual Value EvalRegularizationError() const;

    // Evaluate the derivative of regularization error part of the cost function.
    virtual void GetRegularizationErrorGradient(
            Math::Vector<Value>* derivative_regularization_part) const;

    /**************************************************************
     * Initialization.
     **************************************************************/
    // Initialize the values of the map function from the function used as prior,
    // the function can be NULL if not known a priori.
    // Example values override prior values from the function as they are correct and known a priori,
    // they can be NULL if not available.
    // Bias is used when no function or examples can be used for a datapoint.
    virtual bool Init(
            const LearnFunction* lfunction, const Examples* examples,
            const Value default_value);

protected:
    // Initialize the values of the map function from the function passed as input.
    virtual bool InitFromFunction(const LearnFunction& function_);
    virtual bool InitFromPrior(const Value default_value);

    // Initialize the values of the map function from the (train) examples.
    // Usually called after InitFromFunction if train examples are available
    // and do not require to generalize from a learned function.
    // Public because called by CCs to reset values of the function on the training points.
    virtual bool InitFromExamples(const Examples& examples);

    // Eval the function on the pattern of the test set
    // only kernel machine can evaluate a pattern not in training
    virtual Value EvalInternal(const Pattern& pattern) const;

    /************************************************************
     * I/O
     ************************************************************/
    virtual bool InternalSaveToStream(std::ostream& os) const;
    virtual bool InternalLoadFromStream(std::istream& is);
    virtual void InternalClear();

    /************************************************************
     * Data members.
     ************************************************************/
    // The initial values of the function against which regularization is performed.
    Math::Vector<Value> function_initial_values;

    const Dataset* dataset;
    const Examples* examples;

    // default_value
    Value bias;
}; // end MapFunction

} // end namespace Regularization
#endif /* MAP_FUNCTION_H */
