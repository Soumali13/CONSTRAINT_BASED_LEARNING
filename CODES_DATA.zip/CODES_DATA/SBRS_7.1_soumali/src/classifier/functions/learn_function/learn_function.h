/*
 * File:   dataset_based_function.h
 * Author: Tore
 *
 * Created on 3 marzo 2011, 17.07
 */

#ifndef LEARN_FUNCTION_H
#define LEARN_FUNCTION_H

#include "classifier/functions/function.h"
#include "classifier/functions/learn_function/squashing.h"
#include <string>
#include "data/examples.h"
#include "utils/gtl_utils.h"  // for ScopedPtr
#include "utils/math/math_vector.h"


namespace Regularization {
class LossFunction;

class LearnFunction : public Function {
public:
    /********************************
     * Constructors.
     ********************************/
    LearnFunction(const Function::ID& id_,
            const Function::TYPE predicate_type_,
            const Function::Arity arity_,
            const std::string& domain_,
            const Value balance_weight_);
    LearnFunction(const LearnFunction& function);

    /********************************
     * Destructor.
     ********************************/
    virtual ~LearnFunction();

    /*
     *  Eval the function and applies a squashing function on it if requested.
     */
    virtual Value Eval(const Pattern& pattern) const;

    /***********************************************************
     * Accessors
     ***********************************************************/
    /*
     *  Returns the number of parameters of the function
     */
    virtual Index Size() const
    {
        return static_cast<Index>(weights.Size());
    }

    /*
     * Get the weights of the learn function.
     */
    virtual const Math::Vector<Value>& Get() const {
        return weights;
    }

    /***********************************************************
     * Update the weights.
     ***********************************************************/
    virtual void Update(const Math::Vector<Value>& derivative);
    virtual void Update(const Index i, const Value delta);
    virtual void Set(const Math::Vector<Value>& weights_);

    /**************************************************************
     * Error / Derivative Error
     **************************************************************/
    // Eval the labeled error of the function.
    virtual Value EvalLabeledError(
            const Dataset* dataset_,
            const Examples* examples_,
            const LossFunction& labeled_loss_function) const;

    // Eval the regularization error using the pre-computed internal dataset and
    // the internal GramMatrix
    virtual Value EvalRegularizationError() const = 0;

    // This is an optimization to avoid resetting the derivative vector as required
    // by GetGradient. This method computes the gradient df(pattern)/dw and
    // accumulates it in derivative, multiplied by weight.
    virtual bool AccumulateGradient(const Pattern& pattern,
            const Value weight,
            Math::Vector<Value>* derivative) const;
    virtual bool AccumulateGradientInternal(const Pattern& pattern,
            const Value weight,
            Math::Vector<Value>* derivative) const = 0;

    // Evaluate the derivative of labeled error part of the cost function.
    // For speed, derivative_labeled_part should not be reset but the derivative is simply added in place.
    virtual void GetLabeledErrorGradient(
            const Dataset* dataset_,
            const Examples::PerFunctionExamples* examples_,
            const LossFunction& labeled_loss_function,
            Math::Vector<Value>* derivative_labeled_part) const;

    // Evaluate the derivative of regularization error part of the cost function.
    virtual void GetRegularizationErrorGradient(
            Math::Vector<Value>* derivative_regularization_part) const = 0;

    ////////////////////////////////////////////////////////
    // Event based calls. The empty defaults should be OK for most functions.

    // Called at the end of training.
    virtual void EndTrain() { }
    // Called before starting each train iteration.
    virtual void StartTrainIteration() { }
    virtual void EndTrainIteration() { }
    // In case some special operations must be performed before and after running
    // crossvalidation. For example used for NeuralNetworks to rescale the weights
    // when using dropout.
    virtual void PrepareForCrossvalidation() { }
    virtual void EndCrossvalidation() { }
    ////////////////////////////////////////////////////////

protected:
    // Computed by subclasses.
    virtual Value EvalInternal(const Pattern& pattern) const = 0;

    Math::Vector<Value> weights;
    // Weight to give to the positive examples during training.
    // Can be used to re-balance the example weights when the classes are unbalanced.
    Value balance_weight;

    // Learn functions must be limited to some specific range to be used with
    // some loss functions or constraints. The following fields provide support for
    // forcing the function outputs to have some range.

    virtual void SetSquashingFunction();
    ScopedPtr<SquashingFunction> squashing_function;
};
} // end namespace Regularization
#endif // LEARN_FUNCTION_H
