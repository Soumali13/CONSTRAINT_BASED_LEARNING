/*
 * File:   cached_learn_function.h
 * Author: michi
 *
 * Created on 3 marzo 2011, 17.07
 */

#ifndef CACHED_LEARN_FUNCTION_H
#define CACHED_LEARN_FUNCTION_H

#include "classifier/functions/learn_function/learn_function.h"
#include "utils/math/math_vector.h"
#if __NO_STD_C11__ > 0
#include <tr1/unordered_map>
#else
#include <unordered_map>
#endif

namespace Regularization {
class Examples;
class Pattern;

// A learn function whose values are cached by pattern name.
// This is potentially much faster as the eval for a pattern is called only once
// per pattern until the weights are changed.
class CachedLearnFunction : public LearnFunction
{
public:
    /********************************
     * Constructors.
     ********************************/
    CachedLearnFunction(const Function::ID& id_,
                        const Function::TYPE predicate_type_,
                        const Function::Arity arity_,
                        const std::string& domain_,
                        const Value balance_weight_=1.0,
                        const bool enable_cache_=true);

    CachedLearnFunction(const CachedLearnFunction& function);

    /********************************
     * Destructor.
     ********************************/
    virtual ~CachedLearnFunction() { }

    virtual void Update(const Math::Vector<Value>& derivative);
    virtual void Update(const Index i, const Value delta);
    virtual void Set(const Math::Vector<Value>& vec_);
    inline void EnableCache() {
        cache_enabled = true;
    }
    inline void DisableCache() {
        cache_enabled = false;
        functionValues.clear();
    }

protected:
    /**
     * Lookup in the cache and then eventually eval the pattern.
     */
    virtual Value EvalInternal(const Pattern& pattern) const;
    // Actual evaluation of the function done by the subclasses.
    virtual Value RunEval(const Pattern& pattern) const = 0;

#if __NO_STD_C11__ > 0
    typedef std::tr1::unordered_map<std::string, Value> FunctionValues;
#else
    typedef std::unordered_map<std::string, Value> FunctionValues;
#endif
    FunctionValues functionValues;
    bool cache_enabled;
};

} // end namespace Regularization
#endif // DATASET_BASED_FUNCTION_H
