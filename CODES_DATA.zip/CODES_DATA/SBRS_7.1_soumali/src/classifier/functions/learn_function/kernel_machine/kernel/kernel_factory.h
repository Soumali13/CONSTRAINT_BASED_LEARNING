/*
 * kernel_factory.h
 *
 *  Created on: 10/feb/2010
 *      Author: leonardo
 */
#ifndef KERNEL_FACTORY_H
#define KERNEL_FACTORY_H

#include <iostream>
#include <string>

#include "classifier/functions/function.h"


namespace Regularization {
class TrainOptions;
class Kernel;

class KernelFactory
{
public:
    static Kernel* BuildKernel(const Function::ID& id, const TrainOptions& options);
    static Kernel* LoadFromStream(std::istream& is);
    static bool SaveToStream(const Kernel* kernel, std::ostream& os);
}; // end KernelFactory

} // end namespace Regularization
#endif /* KERNEL_FACTORY_H */
