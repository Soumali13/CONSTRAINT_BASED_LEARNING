/*
 * kernel_factory.cc
 *
 *  Created on: 10/feb/2010
 *      Author: leonardo
 */

#include <iostream>
#include <vector>

#include "classifier/functions/learn_function/kernel_machine/kernel/kernel_factory.h"
#include "classifier/functions/learn_function/kernel_machine/kernel/gaussian_kernel.h"
#include "classifier/functions/learn_function/kernel_machine/kernel/linear_kernel.h"
#include "classifier/functions/learn_function/kernel_machine/kernel/polynomial_kernel.h"
#include "classifier/functions/learn_function/kernel_machine/kernel/tanh_kernel.h"

#include "utils/general.h"
#include "utils/string_utils.h"
#include "train/options.h"


using namespace std;

namespace Regularization
{
namespace {
/*
 * Get the parameters for the kernel from string
 */
string KernelParametersToString(const string& id, const TrainOptions& options)
{
    vector<vector<string> > vectors;
    StringUtils::SplitToVectorOfVectorsByType(options.GetKernelParameters(), &vectors, "-", "=");

    for (unsigned int i = 0; i < vectors.size(); ++i)
    {
        CHECK_EQ(static_cast<int>(vectors[i].size()), 2);

        if (vectors[i][0] == id)
        {
            return vectors[i][1];
        }
    }

    //WARN("Error: use default Kernel Parameters for function " << id << endl);
    // if not found return a string with default parameters
    stringstream stream;
    stream << options.GetDefaultSigmaGaussianKernel() << "," << options.GetACoefficentKernel()
            << "," << options.GetBCoefficentKernel() << "," << options.GetPCoefficientKernel();
    return stream.str();
}
}  // end namespace

/*
 *  Builds a kernel starting from Flag of kernelType
 */
Kernel* KernelFactory::BuildKernel(const Function::ID& id, const TrainOptions& options)
{
    const string& kernel_type = options.GetKernelType();
	const string kernelParameters = KernelParametersToString(id, options);
    if (kernel_type == "GAUSSIAN")
    {
    	vector<Value> parameters;
        StringUtils::SplitToVectorByType(kernelParameters, &parameters, ",", false);
        return new GaussianKernel(parameters[0]);
    }
    else if (kernel_type == "LINEAR")
    {
        return new LinearKernel (options.GetACoefficentKernel(),
        						 options.GetBCoefficentKernel());
    }
    else if (kernel_type == "POLYNOMIAL")
    {
        return new PolynomialKernel (options.GetACoefficentKernel(),
									 options.GetBCoefficentKernel(),
									 options.GetPCoefficientKernel());
    }
    else if (kernel_type == "TANH")
    {
        return new TanhKernel (options.GetACoefficentKernel(), options.GetBCoefficentKernel());
    }
    else
    {
        FAULT ("Undefined kernel type " << kernel_type);
    }

    // not used: only for avoid complier warning
    return new GaussianKernel(options.GetDefaultSigmaGaussianKernel());
}

/* static */
Kernel* KernelFactory::LoadFromStream(istream& is) {
    string name;
    CHECK(static_cast<bool>(is >> name));
    Kernel* kernel = NULL;
    if (name == "LINEAR")
        kernel = new LinearKernel(1, 0);
    else if (name == "GAUSSIAN")
        kernel = new GaussianKernel(1);
    else if (name == "POLYNOMIAL")
        kernel = new PolynomialKernel(1, 1, 2);
    else if (name == "TAHN")
        kernel = new TanhKernel(1, 0);
    else
        FAULT("Unknown kernel " << name);
    kernel->LoadFromStream(is);
    return kernel;
}

/* static */
bool KernelFactory::SaveToStream(const Kernel* kernel, ostream& os) {
    CHECK(static_cast<bool>(os << kernel->Name() << " "));
    return kernel->SaveToStream(os);
}

}  // end Regularization
