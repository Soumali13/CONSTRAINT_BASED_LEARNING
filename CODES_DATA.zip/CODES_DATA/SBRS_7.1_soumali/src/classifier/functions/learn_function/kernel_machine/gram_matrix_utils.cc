/*
 * gram_matrix_utils.cc
 *
 *  Created on: Oct 15, 2015
 *      Author: michi
 */

#include "classifier/functions/learn_function/kernel_machine/gram_matrix_utils.h"

#include <string>
#include <sstream>
#include <vector>

#include "classifier/functions/learn_function/learn_function.h"
#include "classifier/functions/learn_function/kernel_machine/gram_matrix.h"
#include "classifier/functions/learn_function/kernel_machine/gram_matrix_manager.h"
#include "data/dataset.h"
#include "data/pattern.h"
#include "train/options.h"
#include "utils/general.h"  // for CHECKs
#include "utils/math/math_utils.h"    // for Math::Rand
#include "utils/stl_utils.h"    // for std::Find


using namespace std;

namespace Regularization {
/* static */
void EmpiricalKernelMap::Build(
        const double default_portion, const string& domain_to_portion_str,
        const TrainOptions& options, Dataset* dataset) {
    map<string, double> map_domain_to_portion;
    StringUtils::SplitToMapByType(
            domain_to_portion_str, &map_domain_to_portion, ",", ":", -1.0, true);

    GramMatrixManager gm_manager;
    vector<string> domains;
    dataset->GetDomains(&domains);
    for (unsigned int i = 0; i < domains.size(); ++i) {
        const double portion = std::Find(map_domain_to_portion, domains[i], default_portion);
        const GramMatrix* gram_matrix = gm_manager.Get(
                domains[i], options.GetGramMatricesFilesMap());
        if (gram_matrix) {
            VMESSAGE(2, "Empirical kernel maps for domain " << domains[i]);
            BuildInternal(portion, *gram_matrix,
                          dataset->GetMutableDomainDataset(domains[i]));
        } else {
            WARN("No empirical kernel maps for domain " << domains[i]);
        }
    }
}

/* static */
void EmpiricalKernelMap::BuildInternal(
        const double portion, const GramMatrix& gram_matrix, Dataset* dataset) {
    CHECK_EQ(gram_matrix.GetRowSize(), dataset->Size());
    deque<Index> indexes;
    for (Index i = 0; i < gram_matrix.GetRowSize(); ++i) {
        if (Math::Rand(0.0, 1.0) < portion) {
            indexes.push_back(i);
        }
    }

    for (Index i = 0; i < dataset->Size(); ++i) {
        SparsePattern* spattern = dynamic_cast<SparsePattern*>(dataset->GetMutable(i));
        if (!spattern) {
            NarySparsePattern* const nspattern = dynamic_cast<NarySparsePattern* const>(dataset->GetMutable(i));
            if(!nspattern) {
                FAULT(StringUtils::StrCat("Pattern ", i, " is not a convertible to a SparsePattern"));
            }
            spattern = nspattern->GetMutable(0);
        }

        for (unsigned int j = 0; j < indexes.size(); ++j) {
#if __LOW_MEMORY_USAGE__ > 0
            spattern->Add(j, gram_matrix.Get(i, j));
#else
            ostringstream os;
            os << j;
            spattern->Add(os.str(), gram_matrix.Get(i, j));
#endif
        }
    }
}

}  // end Regularization
