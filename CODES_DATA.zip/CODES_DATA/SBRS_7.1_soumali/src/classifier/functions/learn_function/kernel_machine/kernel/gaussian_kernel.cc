/*
 * gaussian_kernel.cc
 *
 *  Created on: 10/feb/2010
 *      Author: leonardo
 */

#include <cmath>
#include <iostream>
#include <sstream>
#include "classifier/functions/learn_function/kernel_machine/kernel/gaussian_kernel.h"
#include "data/pattern.h"


namespace Regularization
{

/*
 * Applies the Gaussian kernel to the patterns x1 and x2
 */
Kernel::Value GaussianKernel::Eval(const Pattern* x1, const Pattern* x2) const
{
    const Value val = x1->EuclideanDist(x2);
    return static_cast<Value>(exp(-(val*val) / sigma2));
}

std::string GaussianKernel::ToString() const
{
    std::ostringstream os;
    os << "Gaussian Kernel, sigma " << sigma << std::endl;
    return os.str();
}

bool GaussianKernel::SaveToStream(std::ostream& os) const
{
	os << sigma  << " ";
	return true;
}


bool GaussianKernel::LoadFromStream(std::istream& is) {
    bool ret = static_cast<bool>(is >> sigma);
    sigma2 = sigma * sigma;
    return ret;
}

}  // end Regularization
