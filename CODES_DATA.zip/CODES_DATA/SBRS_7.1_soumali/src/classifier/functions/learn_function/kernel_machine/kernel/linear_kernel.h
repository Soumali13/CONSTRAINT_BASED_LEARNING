/*
 * linear_kernel.h
 *
 *  Created on: 10/feb/2010
 *      Author: leonardo
 */

#ifndef LINEAR_KERNEL_H
#define LINEAR_KERNEL_H

#include "classifier/functions/learn_function/kernel_machine/kernel/kernel.h"

namespace Regularization
{
// (a <x,x> + b)

class LinearKernel : public Kernel
{
    public:
        LinearKernel(Value a_, Value b_) : a(a_), b(b_)
        {
        }

        Value Eval(const Pattern* x1, const Pattern* x2) const;

        virtual Kernel* Clone() const
        {
            LinearKernel* kernel = new LinearKernel(a, b);
            return kernel;
        }

        virtual std::string Name() const { return "LINEAR"; }

        virtual std::string ToString() const;
        virtual bool SaveToStream(std::ostream& os) const;
        virtual bool LoadFromStream(std::istream& is);

    private:
        Value a;
        Value b;
}; // end LinearKernel

} // end namespace Regularization

#endif /* LINEAR_KERNEL_H */
