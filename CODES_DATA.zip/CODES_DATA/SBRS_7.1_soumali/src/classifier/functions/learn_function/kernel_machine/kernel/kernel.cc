#include <cmath>
#include <limits>

#include "classifier/functions/learn_function/kernel_machine/kernel/kernel.h"
#include "classifier/functions/learn_function/kernel_machine/gram_matrix.h"
#include "data/dataset.h"
#include "utils/general.h"

#include "utils/gflags/gflags/gflags.h"

#if __NO_STD_C11__ > 0
DEFINE_double(thresholdKernel, -std::numeric_limits<float>::max(),
              "Element of the Gram Matrix under this threshold are set to 0");
#else
DEFINE_double(thresholdKernel, std::numeric_limits<double>::lowest(),
              "Element of the Gram Matrix under this threshold are set to 0");
#endif

DEFINE_uint64(max_gram_matrix_size, 0,
        "Precompute the gram matrix up to this number of rows and columns. "
        "If set to zero no limit is applied. "
        "TODO(michi): check whether this works correctly!");
DECLARE_string(gram_matrix_type);

namespace Regularization
{

/*
 * Build the Gram Matrix for the patterns in the Dataset.
 * If the resulting value is lower than thr, it is set to 0.
 */
GramMatrix* Kernel::BuildGramMatrix(const Dataset& dataset) const {
    const Index dataset_size = dataset.Size();
    CHECK_GT(dataset_size, static_cast<Index>(0));

    GramMatrix* gram_matrix = NULL;
    const Pattern* pattern = dataset.Get(0);
    const Index functionArity = pattern->GetSize();

    // optimization: set the precomputed Gram Matrix and compute online
    // only the remaining rows of the matrix
    const Index precomputedGramMatrixThreshold = (FLAGS_max_gram_matrix_size > 0 ?
            std::pow(FLAGS_max_gram_matrix_size, 1.0 / functionArity) : 0);

    if (precomputedGramMatrixThreshold > 0 &&
        dataset_size > precomputedGramMatrixThreshold) {
        VMESSAGE(0, "No Precomputed Gram Matrix for dataset " << dataset.GetName() <<
                 " for elements above index " << precomputedGramMatrixThreshold <<
                 " of a total of " << dataset_size << " elements. " <<
                 "Your Kernel Machine may be slower than expected!");
    }

    // build sparse Gram matrix
    if (FLAGS_gram_matrix_type == "SPARSE") {
        Math::SparseMatrix<Index, Value>* matrix = NULL;
        for (Index row = 0; row < dataset_size; ++row) {
            // optimization: precompute only sub part of the Gram Matrix
            // the remaining elements of the matrix will be computed online
            if (precomputedGramMatrixThreshold > 0 &&
                row >= precomputedGramMatrixThreshold) {
                break;
            }
            // to avoid problem of floating point exception
            if (GetVerboseLevel() >= 0 && dataset_size > static_cast<Index>(10)) {
                if (row % (dataset_size / 10) == static_cast<Index>(0)) {
                    VPRINT(1, "\rBuilding Gram Matrix, processed " << 100 * (row + 1) / dataset_size << "/" << 100);
                } else if (row == dataset_size - 1) {
                    VPRINT(-1, "\rBuilding Gram Matrix, processed 100/100");
                }
            }

            const Pattern* row_pattern = dataset.Get(row);

            for (Index col = 0; col < dataset_size; ++col) {
                // optimization: precompute only sub part of the Gram Matrix
                // the remaining elements of the matrix will be computed online
                if (precomputedGramMatrixThreshold > 0 &&
                    col >= precomputedGramMatrixThreshold) {
                    break;
                }

                const Pattern* col_pattern = dataset.Get(col);
                const Value val = this->Eval(row_pattern, col_pattern);
                if (val >= FLAGS_thresholdKernel)
                    matrix->Set(row, col, val);
            }
        }

        gram_matrix = new SparseGramMatrix(dataset.GetName(), matrix);
    }  else if (FLAGS_gram_matrix_type == "DENSE") {
        Math::Matrix<Index, Value>* matrix = new Math::Matrix<Index, Value>(dataset_size, dataset_size);
        Index row, col;

        for (row = 0; row < dataset_size; ++row) {
            // optimization: precompute only sub part of the Gram Matrix
            // the remaining elements of the matrix will be computed online
            if (precomputedGramMatrixThreshold > 0 &&
                row >= precomputedGramMatrixThreshold) {
                break;
            }

            // to avoid problem of floating point exception
            if (GetVerboseLevel() >= 0 && dataset_size > static_cast<Index>(10)) {
                if (row % (dataset_size / 10) == static_cast<Index>(0)) {
                    VPRINT(1, "\rBuilding Gram Matrix, processed " << 100 * (row + 1) / dataset_size << "/" << 100);
                } else if (row == dataset_size - 1) {
                    VPRINT(-1, "\rBuilding Gram Matrix, processed 100/100");
                }
            }

            const Pattern* row_pattern = dataset.Get(row);

            for (col = 0; col < dataset_size; ++col) {
                // optimization: precompute only sub part of the Gram Matrix
                // the remaining elements of the matrix will be computed online
                if (precomputedGramMatrixThreshold > 0 &&
                    col >= precomputedGramMatrixThreshold) {
                    break;
                }

                const Pattern* col_pattern = dataset.Get(col);
                const Value val = this->Eval(row_pattern, col_pattern);
                if (val >= FLAGS_thresholdKernel)
                    matrix->Set(row, col, val);
            }
        }

        gram_matrix = new DenseGramMatrix(dataset.GetName(), matrix);
    }

    // build symmetric Gram matrix
    else if (FLAGS_gram_matrix_type == "SYMMETRIC")
    {
        Math::SymmetricMatrix<Index, Value>* matrix = new Math::SymmetricMatrix<Index, Value>(dataset_size);
        Index row, col;

        for (row = 0; row < dataset_size; ++row) {
            // optimization: precompute only sub part of the Gram Matrix
            // the remaining elements of the matrix will be computed online
            if (precomputedGramMatrixThreshold > 0 &&
                row >= precomputedGramMatrixThreshold) {
                break;
            }

            // to avoid problem of floating point exception
            if (GetVerboseLevel() >= 0 && dataset_size > static_cast<Index>(10)) {
                if (row % (dataset_size / 10) == static_cast<Index>(0)) {
                    VPRINT(-1, "\rBuilding Gram Matrix, processed " << 100 * (row + 1) / dataset_size << "/" << 100);
                } else if (row == dataset_size - 1) {
                    VPRINT(-1, "\rBuilding Gram Matrix, processed 100/100");
                }
            }

            const Pattern* row_pattern = dataset.Get(row);

            for (col = row; col < dataset_size; ++col) {
                // optimization: precompute only sub part of the Gram Matrix
                // the remaining elements of the matrix will be computed online
                if (precomputedGramMatrixThreshold > 0 &&
                    col >= precomputedGramMatrixThreshold) {
                    break;
                }

                const Pattern* col_pattern = dataset.Get(col);
                const Value val = this->Eval(row_pattern, col_pattern);
                if (val >= FLAGS_thresholdKernel)
                    matrix->Set(row, col, val);

            }
        }

        gram_matrix = new SymmetricGramMatrix(dataset.GetName(), matrix);
    }

    else
    {
        FAULT("Gram Matrix Type not correct!");
    }

    VPRINT(-1, "\n");

    if (precomputedGramMatrixThreshold > 0 &&
        precomputedGramMatrixThreshold < dataset_size) {
        VMESSAGE(1, "Gram Matrix is precomputed up to row/column: "
                << precomputedGramMatrixThreshold << "/" << dataset_size);
    }

    return gram_matrix;
}

} // end namespace Regularization
