#ifndef GAUSSIAN_KERNEL_H
#define GAUSSIAN_KERNEL_H

#include "classifier/functions/learn_function/kernel_machine/kernel/kernel.h"

namespace Regularization
{

class GaussianKernel : public Kernel
{
    public:

        GaussianKernel(Value sigma_) : sigma(sigma_), sigma2(sigma_ * sigma_)
        {
        }


        virtual ~GaussianKernel()
        {
        }

        virtual Kernel* Clone() const
        {
            GaussianKernel* kernel = new GaussianKernel(sigma);
            return kernel;
        }

        virtual std::string Name() const { return "GAUSSIAN"; }

        virtual std::string ToString() const;
        virtual bool SaveToStream(std::ostream& os) const;
        virtual bool LoadFromStream(std::istream& is);

        virtual Value Eval(const Pattern* x1, const Pattern* x2) const;

    private:
        Value sigma;
        Value sigma2;

}; // end GaussianKernel

} // end namespace Regularization

#endif /* GAUSSIAN_KERNEL_H */
