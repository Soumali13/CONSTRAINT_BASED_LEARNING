/*
 * polynomial_kernel.cc
 *
 *  Created on: 10/feb/2010
 *      Author: leonardo
 */

#include "classifier/functions/learn_function/kernel_machine/kernel/tanh_kernel.h"

#include <cmath>
#include <iostream>
#include <sstream>
#include <string>
#include "data/pattern.h"

namespace Regularization
{

/*
 * Applies the Tanh kernel to the patterns x1 and x2
 */
Kernel::Value TanhKernel::Eval(const Pattern* x1, const Pattern* x2) const
{
    const Value dot = x1->DotProduct(x2);
    const Value val = a * dot + b;
    return static_cast<Value>(std::tanh(val));
}

std::string TanhKernel::ToString() const
{
    std::ostringstream os;
    os << "Tanh Kernel, a " << a << ", b " << b << std::endl;
    return os.str();
}

bool TanhKernel::SaveToStream(std::ostream& os) const
{
    os << a << " " << b << " ";
    return true;
}


bool TanhKernel::LoadFromStream(std::istream& is) {
    return static_cast<bool>(is >> a >> b);
}

}  // end Regularization
