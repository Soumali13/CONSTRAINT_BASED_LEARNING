#ifndef KERNEL_H
#define KERNEL_H

#include <string>
#include "data/basic_data_types.h"

namespace Regularization
{
class GramMatrix;
class Pattern;
class Dataset;

class Kernel
{
    public:
        typedef Regularization::Value Value;

        Kernel()
        {
        }

        virtual ~Kernel()
        {
        }

        /**************************************************************
         * Virtual Function
         **************************************************************/

        /*
         * Build the Gram matrix: G_{i,j} = K(x_i,x_j)
         */
        virtual GramMatrix* BuildGramMatrix(const Dataset& dataset) const;

        /*
         * Eval the K(x1,x2)
         */
        virtual Value Eval(const Pattern* x1, const Pattern* x2) const = 0;
        virtual Kernel* Clone() const = 0;

        /******************************
         * I/O
         *****************************/
        virtual std::string Name() const = 0;
        virtual std::string ToString() const = 0;
        virtual bool SaveToStream(std::ostream& os) const = 0;
        virtual bool LoadFromStream(std::istream& is) = 0;
}; // end Kernel

} // end namespace Regularization
#endif /* KERNEL_H */
