#if __ACTIVATE_OPENMP_FUNCTIONS__ > 0
#include <omp.h>
#endif

#include "classifier/functions/learn_function/kernel_machine/kernel/kernel_factory.h"
#include "classifier/functions/learn_function/kernel_machine/kernel_machine_function.h"
#include "classifier/functions/learn_function/kernel_machine/gram_matrix_manager.h"
#include "data/examples.h"
#include "train/options.h"
#include "utils/gflags/gflags/gflags.h"
#include "utils/math/math_vector_operations.h"
#include "utils/math/math_matrix_operations.h"
#include "utils/string_utils.h"


DEFINE_bool(simplify_gram_matrix, true,
            "Optimization: simplify the Gram matrix during the computation of the gradient");

using namespace std;
using namespace Regularization;


KernelMachineFunction::KernelMachineFunction(const Function::ID id_,
        const Function::TYPE predicateType_,
        const Function::Arity arity_, const std::string& domain_,
        const Value balance_weight,
        const Value bias_,
        const Dataset* dataset_,
        const GramMatrix* gramMatrix_, const Kernel* kernel_) :
        CachedLearnFunction(id_, predicateType_, arity_, domain_, balance_weight),
        dataset(dataset_),
        gramMatrix(NULL), denseGramMatrix(NULL), symmetricGramMatrix(NULL), kernel(kernel_),
        bias(bias_), precomputedGramMatrixThreshold(0),
        owns_gram_matrix(false), owns_dataset(false) {
    if (dataset != NULL) {
        weights.Init(dataset->Size());
    }

    this->InitGramMatrixes(gramMatrix_);
}

/**
 * Copy constructor:
 */
KernelMachineFunction::KernelMachineFunction(const KernelMachineFunction& kernel_machine_function) :
    CachedLearnFunction(kernel_machine_function.GetId(),
                        kernel_machine_function.GetType(),
                        kernel_machine_function.GetArity(),
                        kernel_machine_function.GetDomain(),
                        kernel_machine_function.balance_weight),
    dataset(kernel_machine_function.dataset),
    gramMatrix(NULL), denseGramMatrix(NULL), symmetricGramMatrix(NULL),
    kernel(kernel_machine_function.GetKernel() ? kernel_machine_function.GetKernel()->Clone() : NULL),
    bias(kernel_machine_function.GetBias()),
    precomputedGramMatrixThreshold(0),
    owns_gram_matrix(false), owns_dataset(false) {
    weights.Copy(kernel_machine_function.Get());

    this->InitGramMatrixes(kernel_machine_function.gramMatrix);
}

Function* KernelMachineFunction::Clone() const {
    return new KernelMachineFunction(*this);
}

/**
 * Destructor
 */
KernelMachineFunction::~KernelMachineFunction()
{
    this->InternalClear();
}

/*
 * Set up the gram matrix if it is externally provided.
 */
void KernelMachineFunction::InitGramMatrixes(const GramMatrix* gramMatrix_) {
    if (owns_gram_matrix && gramMatrix != NULL) {
        delete gramMatrix;
    }

    gramMatrix = gramMatrix_;

    // optimization: set the precomputed Gram Matrix and compute online
    // only the remaining rows of the matrix
    if (gramMatrix != NULL) {
        precomputedGramMatrixThreshold = gramMatrix->GetRowSize();
        denseGramMatrix = dynamic_cast<const DenseGramMatrix*>(gramMatrix);
        symmetricGramMatrix = dynamic_cast<const SymmetricGramMatrix*>(gramMatrix);
    }
}
/**
 * Eval the function on the pattern of the test set
 */
Value KernelMachineFunction::RunEval(const Pattern& pattern) const {
    Value res = 0.0;
    // If the pattern is in the dataset we can speedup the computation avoid to recompute
    // the kernel values.
    bool found = false;
    const Index pattern_index = dataset->GetPatternIndex(pattern.GetName(), &found);

    const Index max_index_with_gram_matrix = (found ?
            Math::Min(precomputedGramMatrixThreshold, static_cast<Index>(weights.Size())) :
            0);
    if (max_index_with_gram_matrix < weights.Size()) {
        CHECK_NE_NULL(kernel);
    }

#if __ACTIVATE_OPENMP_FUNCTIONS__ > 0
    const int active_level = omp_get_active_level();
#pragma omp parallel default(none) shared(res) if (active_level < 1)
#endif
    {
#if __ACTIVATE_OPENMP_FUNCTIONS__ > 0
#pragma omp for schedule(static,512) reduction(+:res)
#endif
        for (Index i = 0; i < max_index_with_gram_matrix; ++i) {
            const Value weight = weights.Get(i);
            if (weight != static_cast<Value>(0.0)) {
                Value value = 0;
                if (symmetricGramMatrix != NULL)
                    value = weight * symmetricGramMatrix->GetFast(pattern_index, i);
                else if (denseGramMatrix != NULL)
                    value = weight * denseGramMatrix->GetFast(pattern_index, i);
                else  // just go for the virtual call.
                    value = weight * gramMatrix->Get(pattern_index, i);
                res += value;
            }
        }
    }  // end parallel section

#if __ACTIVATE_OPENMP_FUNCTIONS__ > 0
#pragma omp parallel default(none) shared(pattern,res) if (active_level < 1)
#endif
    {
#if __ACTIVATE_OPENMP_FUNCTIONS__ > 0
#pragma omp for schedule(static,512) reduction(+:res)
#endif
        for (Index i = max_index_with_gram_matrix; i < weights.Size(); ++i) {
            const Value weight = weights.Get(i);
            if (weight != static_cast<Value>(0.0))  {
                res += weight * kernel->Eval(&pattern, dataset->Get(i));
            }
        }
    }  // end parallel section

    return res + bias;
}

/**
 * Get the derivative of the function with respect to the weights on a training point.
 */
bool KernelMachineFunction::AccumulateGradientInternal(
        const Pattern& pattern,
        const Value weight,
        Math::Vector<Value>* derivative) const {
    const Index n_weights = weights.Size();
    CHECK_EQ(static_cast<Index>(derivative->Size()), n_weights);
    bool found = false;
    const Index pattern_index = dataset->GetPatternIndex(pattern.GetName(), &found);
    if (FLAGS_simplify_gram_matrix) {
        if (found) {
            // MESSAGE(this->GetId() << "(" << pattern.GetName() << ":" << pattern_index << ") += " << weight);
            derivative->Add(pattern_index, weight * 1.0);
        }
    } else {
#if __ACTIVATE_OPENMP_FUNCTIONS__ > 0
        const int active_level = omp_get_active_level();
#pragma omp parallel default(none) shared(derivative,found,pattern) if (active_level < 1)
#endif
        {
#if __ACTIVATE_OPENMP_FUNCTIONS__ > 0
#pragma omp for schedule(static,512)
#endif
            for (Index i = 0; i < n_weights; ++i) {
                // optimization: use the precomputed Gram Matrix and compute online
                // only the remaining element of the row of the matrix
                if (found && i < precomputedGramMatrixThreshold) {
                    Value res = 0;
                    if (denseGramMatrix != NULL)
                        res = weight * denseGramMatrix->GetFast(pattern_index, i);
                    else if (symmetricGramMatrix != NULL)
                        res = weight * symmetricGramMatrix->GetFast(pattern_index, i);
                    else
                        res = weight * gramMatrix->Get(pattern_index, i);
                    derivative->Add(i, res);
                } else {
                    // compute online the remaining element of the row of the matrix
                    // get the pattern
                    const Pattern* example = dataset->Get(i);
                    derivative->Add(i, weight * kernel->Eval(&pattern, example));
                }
            }
        }
    }  // end parallel section

    return true;
}

/*
 * Eval the regularization error using the pre-computed internal dataset.
 */
Value KernelMachineFunction::EvalRegularizationError() const {
    // w^t : actual weights values in the k^th function
    Value sum = 0;
#if __ACTIVATE_OPENMP_FUNCTIONS__ > 1
    const int active_level = omp_get_active_level();
#pragma omp parallel default(none) shared(sum)if (active_level < 1)
#endif
    {
#if __ACTIVATE_OPENMP_FUNCTIONS__ > 1
#pragma omp for schedule(static,512) reduction(+:sum)
#endif
        for (Math::VectorIndex i = 0; i < weights.Size(); ++i) {
            if (weights[i] != 0) {  // weights are 0 for most patterns.
                sum += weights[i] * (this->Eval(*dataset->Get(i)) - bias);
            }
        }
    }  // end parallel section

    // G should be positive defined, so w'Gw >= 0
    // CHECK_GE(sum, static_cast<Value>(0.0));
    return 0.5 * sum;
}

/**
 * Evaluate the derivative of regularization error part of the cost function.
 */
void KernelMachineFunction::GetRegularizationErrorGradient(
        Math::Vector<Value>* derivative_regularization_part) const {
    // Sanity checks.
    CHECK_EQ(derivative_regularization_part->Size(), weights.Size());

    if (FLAGS_simplify_gram_matrix) {
        // w^t : actual weights values in the k^th function
        derivative_regularization_part->Copy(weights);
        // derivative_regularization_part->Print();
    } else {
        // Gw = functionsValues - bias so don't recompute it
#if __ACTIVATE_OPENMP_FUNCTIONS__ > 1
        const int active_level = omp_get_active_level();
#pragma omp parallel default(none) shared(derivative_regularization_part) if (active_level < 1)
#endif
        {
#if __ACTIVATE_OPENMP_FUNCTIONS__ > 1
#pragma omp for schedule(static,512)
#endif
            for (Math::VectorIndex i = 0; i < weights.Size(); ++i) {
                const Value value = this->Eval(*dataset->Get(i));
                derivative_regularization_part->Set(i, value - bias);
            }
        }  // end parallel section
    }
}

/**
 *  Compute the support vectors
 **/
void KernelMachineFunction::GetSupportVectors(SupportVectors* support_vectors) const
{
    support_vectors->clear();

    // For each example in the training set
    for (Index i = 0; i < dataset->Size(); ++i) {
        if (weights[i] != static_cast<Value>(0)) {
            const Pattern& pattern = *dataset->Get(i);
            support_vectors->push_back(make_pair(pattern.GetName(), weights[i]));
        }
    }
}

void KernelMachineFunction::InternalClear() {
    if (owns_dataset) {
        if (dataset != NULL) {
            delete dataset;
            dataset = NULL;
            owns_dataset = false;
        }
     }

    if (kernel != NULL) {
        delete kernel;
        kernel = NULL;
    }

    if (owns_gram_matrix && gramMatrix != NULL) {
        delete gramMatrix;
        gramMatrix = NULL;
        owns_gram_matrix = false;
    }

    weights.Clear();
    bias = 0;
    support_vectors.clear();
}

/**
 * Save to stream
 **/
bool KernelMachineFunction::InternalSaveToStream(std::ostream& os) const {
    os << " " << bias << " ";
    os << balance_weight << " ";
    CHECK(KernelFactory::SaveToStream(this->kernel, os));
    CHECK(this->dataset->SaveToStream(os));
    os << " WEIGHTS";
    for (Index i=0; i < weights.Size(); ++i)
    {
        os << " " << weights[i];
    }
    return true;
}

/*
 * Load weights from a string
 */
bool KernelMachineFunction::InternalLoadFromStream(std::istream& is) {
    VMESSAGE(2, "Loading kernel machine function "<< this->GetId());
    this->InternalClear();

    if (!(is >> bias >> balance_weight)) {
        WARN("Can not read KernelMachine header");
        return false;
    }

    kernel = KernelFactory::LoadFromStream(is);
    if (kernel == NULL) {
        WARN("Can not read Kernel header");
        return false;
    }

    dataset = new Dataset();
    if(!const_cast<Dataset*>(dataset)->LoadFromStreamFast(is)) {
        WARN("Can not read  KernelMachine dataset");
        return false;
    }
    owns_dataset = true;
    owns_gram_matrix = false;

    weights.Init(dataset->Size());
    string tmp;
    if (!static_cast<bool>(is >> tmp) || tmp != "WEIGHTS") {
        WARN("Can not read weights header " << tmp);
        return false;
    }

    for (Index i = 0; i < dataset->Size(); ++i) {
        Value value = 0;
        if (!static_cast<bool>(is >> value)) {
            CHECK(static_cast<bool>(is >> tmp));
            WARN("Can not read  weight " << i << " from " << tmp);
            return false;
        }
        weights.Set(i, value);
    }

    return true;
}

