/*
 * polynomial_kernel.h
 *
 *  Created on: 10/feb/2010
 *      Author: leonardo
 */

#ifndef POLYNOMIAL_KERNEL_H
#define POLYNOMIAL_KERNEL_H

#include "classifier/functions/learn_function/kernel_machine/kernel/kernel.h"

namespace Regularization
{
// (a <x,x> + b)^p
class PolynomialKernel : public Kernel
{
    public:
        PolynomialKernel(Value a_, Value b_, Value p_) : a(a_), b(b_), p(p_) { }

        Value Eval(const Pattern* x1, const Pattern* x2) const;

        virtual Kernel* Clone() const
        {
            PolynomialKernel* kernel = new PolynomialKernel(a, b, p);
            return kernel;
        }
        virtual std::string Name() const { return "POLYNOMIAL"; }
        virtual std::string ToString() const;
        virtual bool SaveToStream(std::ostream& os) const;
        virtual bool LoadFromStream(std::istream& is);
    private:
        Value a;
        Value b;
        Value p;

}; // end PolyKernel

} // end namespace Regularization
#endif /* POLYNOMIAL_KERNEL_H */
