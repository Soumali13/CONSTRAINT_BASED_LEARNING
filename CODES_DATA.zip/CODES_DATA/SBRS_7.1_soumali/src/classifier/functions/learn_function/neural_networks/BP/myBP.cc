/*
 * Copyright (C) 2003-2013. Michelangelo Diligenti. All Rights Reserved.
 */

#include <cmath>
#include <fstream>
#include <sstream>

#include "classifier/functions/learn_function/neural_networks/BP/myBP.h"
#include "utils/general.h"
#include "utils/gtl_utils.h"


using namespace std;
using namespace BP;

const Value BasicNET::DEFAULT_BIAS = 1;
const Index BasicNET::DEFAULT_N_EPOCHS = 10;
const Value BasicNET::STOP_CONDITION = 1.2;
const Value BasicNET::MIN_ERROR = 1.0e-100;
const TrainMode BasicNET::DEFAULT_TRAIN_MODE = BATCH; // 0 batch, 1 pattern
const bool BasicNET::DEFAULT_USE_WEIGHT_SAVE = false;
const Value BasicNET::MAX_RANDOM_WEIGHT_AT_INITIALIZATION = 0.2;

const Value BP::Sigmoid::a = 1.0;
const Value BP::LecunHyperbolicTangent::a = 1.7159;
const Value BP::LecunHyperbolicTangent::b = 2.0 / 3.0;
const Value BP::LeakyRectifiedLinear::a = 0.01;

namespace {
inline BP::Value RandomValue(BP::Value Low = -0.5, BP::Value High = 0.5) {
    return (static_cast<BP::Value>(rand()) / RAND_MAX) * (High - Low) + Low;
}
}  // end unnamed namespace

// Factory method
/* static */
ActivationFunction* ActivationFunction::Build(const ActivationFunction::Type type) {
    switch (type) {
    case LINEAR:
        return new Linear();
    case SIGMOID:
        return new Sigmoid();
    case HYPERBOLIC_TANGENT:
        return new HyperbolicTangent();
    case LECUN_HYPERBOLIC_TANGENT:
        return new LecunHyperbolicTangent();
    case RECTIFIEDLINEAR:
        return new RectifiedLinear();
    case LEAKYRECTIFIEDLINEAR:
        return new LeakyRectifiedLinear();
    default:
        FAULT("Unknown ActivationFunctionType: " << type);
    }
    return NULL;
}

/* static */
ActivationFunction::Type ActivationFunction::TypeFromName(const std::string& name) {
    if (name == "LINEAR")
        return LINEAR;
    if (name == "SIGMOID")
        return SIGMOID;
    if (name == "HYPERBOLIC_TANGENT")
        return HYPERBOLIC_TANGENT;
    if (name == "LECUN_HYPERBOLIC_TANGENT")
        return LECUN_HYPERBOLIC_TANGENT;
    if (name == "RECTIFIEDLINEAR")
        return RECTIFIEDLINEAR;
    if (name == "LEAKYRECTIFIEDLINEAR")
        return LEAKYRECTIFIEDLINEAR;

    FAULT("Unknown ActivationFunctionType: " << name);
    return UNKNOWN;
}

// Factory method
/* static */
ActivationFunction* ActivationFunction::Build(const string& name) {
    return ActivationFunction::Build(TypeFromName(name));
}

Layer::Layer(const Index lowerNumUnits,
        const Index numUnits,
        const Index level,
        const bool allocDweight,
        const bool allocSaveWeight,
        const ActivationFunction::Type foutput_type,
        const Value dropout_thr_) :
        Units(numUnits),
        lowerUnits(lowerNumUnits),
        Output(NULL),
        Error(NULL),
        Weight(NULL),
        WeightUpdateAccumulator(NULL),
        WeightSave(NULL),
        dWeight(NULL),
        ofunction(ActivationFunction::Build(foutput_type)),
        dropout_thr(-1.0),
        dropouts(NULL) {
    if (numUnits > 0)
        Output = new Value[numUnits + 1];

    if (level == 0) {
        return;
    }

    if (numUnits <= 0 || lowerNumUnits <= 0) {
        FAULT("ERROR in setting up the Net");
    }
    Error = new Value[numUnits + 1];
    memset(Error, 0, sizeof(Value) * (numUnits + 1));
    Weight = new Value*[numUnits];
    WeightUpdateAccumulator = new Value*[numUnits];

    if (allocDweight)
        dWeight = new Value*[numUnits];

    this->ResetDropouts(dropout_thr_);

    for (Index i = 0; i < Units; ++i) {
        // Last entry is for the bias.
        Weight[i] = new Value[lowerNumUnits + 1];
        memset(Weight[i], 0, sizeof(Value) * (lowerNumUnits + 1));

        WeightUpdateAccumulator[i] = new Value[lowerNumUnits + 1];
        memset(WeightUpdateAccumulator[i], 0, sizeof(Value) * (lowerNumUnits + 1));

        if (dWeight) {
            dWeight[i] = new Value[lowerNumUnits + 1];
            memset(dWeight[i], 0, sizeof(Value) * (lowerNumUnits + 1));
        }
    }
    if (allocSaveWeight && AllocSaveWeights(lowerNumUnits, numUnits) < 0) {
        FAULT("ERROR in setting up the Net");
    }
}

void Layer::ResetDropouts(const Value dropout_thr_) {
    dropout_thr = dropout_thr_;
    if (dropouts != NULL && dropout_thr <= 0)  {
        delete[] dropouts;
        dropouts = NULL;
        return;
    }

    if (dropout_thr > 0)  {
        if (dropouts == NULL) {
            dropouts = new bool[Units];
        }
        for (Index i = 0; i < Units; ++i) {
            // Mark the output of a neuron as dropped.
            dropouts[i] = (RandomValue(0, 1) < dropout_thr);
        }
    }
}

int
Layer::AllocSaveWeights(const Index lowerNumUnits, const Index numUnits)
{
    if (numUnits <= 0 || lowerNumUnits <= 0)
        return -1;

    WeightSave = new Value * [numUnits];
    for (Index i = 0; i < Units; ++i) {
        WeightSave[i] = new Value[lowerNumUnits + 1];
        memset(WeightSave[i], 0, sizeof(Value) * (lowerNumUnits + 1));
    }

    return 1;
}

void
Layer::DeallocSaveWeights()
{
    if (WeightSave) {
        for (Index i = 0; i < Units; ++i)
            if(WeightSave[i])
                delete[] WeightSave[i];
        delete[] WeightSave;
    }
}

void
Layer::Print() const
{
    cout << "The Layer has " << Units << " units\n" << ofunction->GetTypeName();

    for (Index i = 0; i < Units; ++i)
    {
        // cout << "Weights:" << endl;
        for (Index j = 0; j <= lowerUnits; ++j)
            cout << Weight[i][j] << " ";
        cout << endl;
    }
}

Layer::~Layer()
{
    if (Units > 0 && Output)
        delete[] Output;
    if (Error)
        delete[] Error;
    if (Weight) {
        for (Index i = 0; i < Units; ++i)
            delete[] Weight[i];
        delete[] Weight;
    }
    if (WeightUpdateAccumulator)
    {
        for (Index i = 0; i < Units; ++i)
            delete[] WeightUpdateAccumulator[i];
        delete[] WeightUpdateAccumulator;
    }

    if (dWeight)
    {
        for (Index i = 0; i < Units; ++i)
            delete[] dWeight[i];
        delete[] dWeight;
    }

    if (ofunction)
        delete ofunction;

    if (dropouts) {
        delete[] dropouts;
    }

    DeallocSaveWeights();
}

BasicNET::BasicNET()
{
    Init();
}

BasicNET::BasicNET(Index nl,
        Index* theUnits,
        const ActivationFunction::Type ofunction_type)
{
    Init();
    NUM_LAYERS = nl;
    Units = new Index[NUM_LAYERS + 1];
    memcpy(Units, theUnits, (nl + 1) * sizeof(Index));

    Generate(ofunction_type);

    // initWeights(0.5);
    RandomWeights(346623);
}

BasicNET::BasicNET(Index nl,
        Index* theUnits,
        const vector<ActivationFunction::Type>& ofunction_types_)
{
    CHECK_EQ(static_cast<Index>(ofunction_types_.size()), nl);

    Init();
    NUM_LAYERS = nl;
    Units = new Index[NUM_LAYERS + 1];
    memcpy(Units, theUnits, (nl + 1) * sizeof(Index));

    Generate(ofunction_types_);

    // initWeights(0.5);
    RandomWeights(346623);
}

BasicNET::BasicNET(const BasicNET& N)
{
    Alpha = N.Alpha;
    Eta = N.Eta;
    bias = N.bias;
    EtaIncrement = N.EtaIncrement;
    EtaDecrement = N.EtaDecrement;
    train_mode = N.getTrainMode();
    weight_save_mode = N.weight_save_mode;
    dropout_thr = N.dropout_thr;
    input_dropout_thr = N.input_dropout_thr;

    NUM_LAYERS = N.getNumLayers();
    if (NUM_LAYERS <= 0)
        return;

    Units = new Index[NUM_LAYERS + 1];
    memcpy(Units, N.Units, (NUM_LAYERS + 1) * sizeof(Index));

    num_units = N.num_units;
    num_weights = N.num_weights;

    Generate(N.ofunction_types);

    for (Index l = 1; l <= NUM_LAYERS; ++l)
        for (Index i = 0; i < layer[l]->Units; ++i)
            memcpy(layer[l]->Weight[i],
                    N.layer[l]->Weight[i],
                    sizeof(Value) * (1 + layer[l - 1]->Units));
}

void 
BasicNET::Init()
{
    Alpha = 0.1;  // keep it low.
    Eta = 0.1;
    bias = DEFAULT_BIAS;
    EtaIncrement = 1.1;
    EtaDecrement = 0.5;
    train_mode = DEFAULT_TRAIN_MODE;
    weight_save_mode = DEFAULT_USE_WEIGHT_SAVE;
    dropout_thr = 0;
    input_dropout_thr = 0;

    NUM_LAYERS = 0;
    Units = NULL;
    layer = NULL;

    num_units = 0;
    num_weights = 0;
}


int BasicNET::setWeightSaveMode(const bool wsm) {
    if(weight_save_mode == wsm) return 0;

    weight_save_mode = wsm;

    if(weight_save_mode) {
        for (Index l = 1; l <= NUM_LAYERS; ++l)
            layer[l]->AllocSaveWeights(layer[l - 1]->Units, Units[l]);
    }
    else
        for (Index l = 1; l <= NUM_LAYERS; ++l)
            layer[l]->DeallocSaveWeights();

    return 1;
}

void BasicNET::setDropout(const Value input_dropout_thr_, const Value dropout_thr_) {
  dropout_thr = dropout_thr_;
  input_dropout_thr = input_dropout_thr_;
  // Inputs and outputs are not affected by dropout.
  layer[0]->ResetDropouts(input_dropout_thr_);
  for (Index l = 1; l < NUM_LAYERS; ++l)
      layer[l]->ResetDropouts(dropout_thr_);
}

void 
BasicNET::AdaptLearningRate(const Value oldError, const Value Error)
{

    if ((oldError - Error) > 0)
        Eta *= EtaIncrement;
    else if ((oldError - Error) < 0)
        Eta *= EtaDecrement;
    // else not changed
}

void
BasicNET::Print() const
{
    cout << "nLayers " << NUM_LAYERS << endl;
    cout << "nUnits " << num_units << endl;
    cout << "nWeights " << num_weights << endl;
    for (Index l = 0; l <= NUM_LAYERS; ++l)
        cout << "Units[" << l << "]: " << Units[l] << endl;

    for (Index l = 1; l <= NUM_LAYERS; ++l)
    {
        cout << "Layer " << l << endl;
        layer[l]->Print();
    }

    cout << "Learning parameters: \nAlpha " << Alpha << "\tEta " << Eta <<
            "\tBias " << bias << "\tEtaUptate " <<
            EtaIncrement << ":" << EtaDecrement << endl;

}

void
BasicNET::Dealloc()
{
    if (layer) {
        for (Index l = 0; l <= NUM_LAYERS; ++l)
        {
            if (layer[l])
                delete layer[l];
        }
        delete[] layer;
    }

    if (Units)
        delete[] Units;
}

BasicNET::~BasicNET()
{
    Dealloc();
}

Index BasicNET::Generate(const vector<ActivationFunction::Type>& ofunction_types_) {
    ofunction_types = ofunction_types_;
    if (NUM_LAYERS > 0) {
        layer = new Layer*[NUM_LAYERS + 1];

        const bool needDweight = (Alpha > 0);
        for (Index l = 0; l <= NUM_LAYERS; ++l) {
            // the activation function for layer 0 is not called, that's why we have -1
            // in the vector of the activation functions;
            layer[l] = new Layer((l > 0 ? layer[l - 1]->Units : -1),
                    Units[l], l,  needDweight, getWeightSaveMode(),
                    ofunction_types_[(l > 0 ? l - 1 : 0)], 0.0);
        }
    }

    this->ComputeNumUnits();
    this->ComputeNumWeights();
    this->ComputeWeightPositions();

    return num_weights;
}

Index BasicNET::Generate(const ActivationFunction::Type ofunction_type_) {
    vector<ActivationFunction::Type> ofunction_types_(NUM_LAYERS, ofunction_type_);
    return this->Generate(ofunction_types_);
}

void
BasicNET::RandomWeights(unsigned long seed, const Value max_value)
{
    if (seed == 0)
        seed = time(NULL);
    srand(seed);

    for (Index l = 1; l <= NUM_LAYERS; ++l) {
        for (Index i = 0; i < layer[l]->Units; ++i) {
            for (Index j = 0; j <= layer[l - 1]->Units; ++j) {
                layer[l]->Weight[i][j] = RandomValue(-max_value, max_value);
            }
        }
    }
}

void
BasicNET::LecunRandomWeights(unsigned long seed)
{
    if (seed == 0)
        seed = time(NULL);
    srand(seed);

    for (Index l = 1; l <= NUM_LAYERS; ++l) {
        for (Index i = 0; i < layer[l]->Units; ++i) {
            const Value value = 6.0 / sqrt(layer[l-1]->Units);
            for (Index j = 0; j <= layer[l - 1]->Units; ++j) {
                layer[l]->Weight[i][j] = RandomValue(-value, value);
            }
        }
    }
}
void
BasicNET::InitWeights(const Value constW) {
    if (NUM_LAYERS <= 0)  return;

    for (Index l = 1; l <= NUM_LAYERS; ++l) {
        for (Index i = 0; i < layer[l]->Units; ++i)
            for (Index j = 0; j <= layer[l - 1]->Units; ++j)
                layer[l]->Weight[i][j] = constW;
    }
}

void 
BasicNET::PrintLog(Index actualEpoch, Value cost) const {
    PRINTLN("Epoch " << actualEpoch << " error:" << cost << "  Eta: " << Eta);
}

bool BasicNET::SaveToFile(const string& filename) const {
    if (NUM_LAYERS <= 0)
        return false;

    ofstream fp(filename.c_str());
    if (!fp.good())
        return false;

    return this->SaveToStream(fp);
}

bool BasicNET::BinarySaveToFile(const string& filename) const {
    if (NUM_LAYERS <= 0)
        return false;

    ofstream fp(filename.c_str(), ios::binary);
    if (!fp.good())
        return false;

    return this->BinarySaveToStream(fp);
}

bool BasicNET::BinarySaveToStream(ostream& os) const {
    if (!os.good())
        return false;
    os.write((char*) & Alpha, sizeof(Value));
    os.write((char*) & Eta, sizeof(Value));
    os.write((char*) & bias, sizeof(Value));

    os.write((char*) & NUM_LAYERS, sizeof(Index));
    os.write((char*) Units, sizeof(Index) * (NUM_LAYERS + 1));

    for (Index l = 1; l <= NUM_LAYERS; ++l) {
        int ft_as_int = static_cast<int>(layer[l]->ofunction->GetType());
        os.write((char*) & ft_as_int, sizeof(int));
    }
    for (Index l = 1; l <= NUM_LAYERS; ++l) {
        for (Index i = 0; i < layer[l]->Units; ++i) {
            os.write((char*) (layer[l]->Weight[i]),
                    sizeof(Value) * (1 + layer[l - 1]->Units));
        }
    }
    return true;
}

bool BasicNET::SaveToStream(ostream& os) const {
    if (!os.good())
        return false;

    os << Alpha << " " << Eta << " " << bias
            << " " << NUM_LAYERS << " ";
    for (Index l = 0; l <= NUM_LAYERS; ++l) {
        os << Units[l] << " ";
    }
    for (Index l = 1; l <= NUM_LAYERS; ++l) {
        os << layer[l]->ofunction->GetTypeName() << " ";
    }
    for (Index l = 1; l <= NUM_LAYERS; ++l) {
        for (Index i = 0; i < layer[l]->Units; ++i) {
            for (Index j = 0; j <= layer[l - 1]->Units; ++j) {
                os << layer[l]->Weight[i][j] << " ";
            }
        }
    }
    return true;
}

bool BasicNET::LoadFromFile(const string& filename) {
    ifstream fp(filename.c_str());
    if (!fp.good())
        return false;

    return this->LoadFromStream(fp);
}

bool BasicNET::BinaryLoadFromFile(const string& filename) {
    ifstream fp(filename.c_str(), ios::binary);
    if (!fp.good())
        return false;

    return this->BinaryLoadFromStream(fp);
}

bool BasicNET::BinaryLoadFromStream(istream& is) {
    if (!is.good())
        return false;

    this->Dealloc();

    is.read((char*) & Alpha, sizeof(Value));
    is.read((char*) & Eta, sizeof(Value));
    is.read((char*) & bias, sizeof(Value));

    is.read((char*) & NUM_LAYERS, sizeof(Index));
    if (NUM_LAYERS <= 0)
        return false;

    Units = new Index[NUM_LAYERS + 1];
    is.read((char*) Units, sizeof(Index) * (NUM_LAYERS + 1));

    vector<ActivationFunction::Type> activations;
    for (Index l = 1; l <= NUM_LAYERS; ++l) {
        int ft_as_int = -1;
        is.read((char*) & ft_as_int, sizeof(int));
        activations.push_back(static_cast<ActivationFunction::Type>(ft_as_int));
    }
    this->Generate(activations);

    for (Index l = 1; l <= NUM_LAYERS; ++l) {
        for (Index i = 0; i < layer[l]->Units; ++i) {
            is.read((char*) (layer[l]->Weight[i]),
                    sizeof(Value) *
                    static_cast<unsigned int>(1 + layer[l - 1]->Units));
        }
    }
    return true;
}

bool BasicNET::LoadFromStream(istream& is) {
    if (!is.good())
        return false;
    this->Dealloc();

    if (!(is >> Alpha >> Eta >> bias >> NUM_LAYERS)) {
        WARN("Wrong input");
        return false;
    }

    if (NUM_LAYERS <= 0) {
        WARN("Wrong number of layers");
        return false;
    }

    Units = new Index[NUM_LAYERS + 1];
    for (Index l = 0; l <= NUM_LAYERS; ++l) {
        if (!(is >> Units[l])) {
            WARN("Wrong number of units");
            return false;
        }
    }

    vector<ActivationFunction::Type> activations;
    for (Index l = 1; l <= NUM_LAYERS; ++l) {
        string ft;
        if (!(is >> ft)) {
            WARN("Wrong str activation name");
            return false;
        }
        activations.push_back(ActivationFunction::TypeFromName(ft));
    }
    this->Generate(activations);

    for (Index l = 1; l <= NUM_LAYERS; ++l) {
        for (Index i = 0; i < layer[l]->Units; ++i) {
            for (Index j = 0; j <= layer[l - 1]->Units; ++j) {
                if (!(is >> layer[l]->Weight[i][j])) {
                    WARN("Wrong weight");
                    return false;
                }
            }
        }
    }

    return true;
}

/* static */
bool BasicNET::Equals(const BasicNET* a, const BasicNET* b,
        const Value err) {
    if (std::abs(a->Alpha - b->Alpha) > err)
        return false;
    if (std::abs(b->Eta - b->Eta) > err)
        return false;
    if (std::abs(a->bias - b->bias) > err)
        return false;
    if (a->NUM_LAYERS != b->NUM_LAYERS)
        return false;
    for (Index l = 0; l <= a->NUM_LAYERS; ++l) {
        if (a->Units[l] != b->Units[l])
            return false;
    }

    for (Index l = 1; l <= a->NUM_LAYERS; ++l) {



        if (a->layer[l]->ofunction->GetType() != b->layer[l]->ofunction->GetType()) {
            return false;
        }

        for (Index i = 0; i < a->layer[l]->Units; ++i) {
            for (Index j = 0; j <= a->layer[l - 1]->Units; ++j) {
                if (std::abs(a->layer[l]->Weight[i][j] -
                        b->layer[l]->Weight[i][j]) > err) {
                    return false;
                }
            }
        }
    }
    return true;
}

// NET constructors
NET::NET() : BasicNET() 
{ }

NET::NET(Index nl,
        Index* theUnits,
        const ActivationFunction::Type foutput_type_) :
        BasicNET(nl, theUnits, foutput_type_)
{ }

NET::NET(Index nl,
        Index* theUnits,
        const vector<ActivationFunction::Type>& foutput_types_) :
        BasicNET(nl, theUnits, foutput_types_)
{ }

NET::NET(const NET& N) : BasicNET(N)
{ }


void
NET::SetInput(const Pattern& input)
{
    memcpy(layer[0]->Output,
           input.data(),
           sizeof(Value) * layer[0]->Units);

    layer[0]->Output[layer[0]->Units] = bias;
}

// sparseNET constructors
SparseNET::SparseNET() : BasicNET()
{ }

// sparseNET destructor
SparseNET::~SparseNET()
{ }

SparseNET::SparseNET(Index nl,
        Index* theUnits,
        const ActivationFunction::Type foutput_type_) :
        BasicNET(nl, theUnits, foutput_type_)
{ }

SparseNET::SparseNET(Index nl,
        Index* theUnits,
        const vector<ActivationFunction::Type>& foutput_types_):
        BasicNET(nl, theUnits, foutput_types_) {
}

SparseNET::SparseNET(const SparseNET& N) :
            BasicNET(N)
{ }

void
SparseNET::SetInput(const SparsePattern& Input) {
    theInput.clear();
    for (SparsePattern::const_iterator i = Input.begin();
         i != Input.end(); ++i) {
        if (i->first < layer[0]->Units) {
            theInput.push_back(SparsePatternEntry(i->first, i->second));
        } else {
            VMESSAGE(1, "Unknown feature " << i->first);
        }
    }

    theInput.push_back(SparsePatternEntry(layer[0]->Units, bias));
}

void
SparseNET::SetAllInputs(const vector<SparsePattern>& inputs)
{
    set<SparsePatternIndex> s;
    for (vector<SparsePattern>::const_iterator iter = inputs.begin(); iter != inputs.end(); ++iter) {
        const SparsePattern& input = *iter;
        for (SparsePattern::const_iterator j = input.begin();
                j != input.end();
                j ++)
            if (s.find(j->first) == s.end())
                s.insert(j->first);
    }
    s.insert(layer[0]->Units);
    for (set<SparsePatternIndex>::const_iterator k = s.begin();
            k != s.end();
            k ++) {
        allInput.push_back(*k);
    }
}

void
SparseNET::SetAllInputs(const map<string, SparsePattern>& inputs)
{
    set<SparsePatternIndex> s;
    for (map<string, SparsePattern>::const_iterator iter = inputs.begin(); iter != inputs.end(); ++iter) {
        const SparsePattern& input = iter->second;
        for (SparsePattern::const_iterator j = input.begin();
                j != input.end();
                j ++)
            if (s.find(j->first) == s.end())
                s.insert(j->first);
    }
    s.insert(layer[0]->Units);
    for (set<SparsePatternIndex>::const_iterator k = s.begin();
            k != s.end();
            k ++) {
        allInput.push_back(*k);
    }
}

void
BasicNET::PrintLayersWeights() const {
    for (Index l = 1; l <= NUM_LAYERS; ++l) {
        const Layer* L = layer[l];
        const Layer* L1 = layer[l - 1];
        for (Index i = 0; i < L->Units; ++i)
            for (Index j = 0; j <= L1->Units; ++j)
                cout << L->Weight[i][j] << " ";
    }
    cout << endl;
}

void BasicNET::SaveWeights() {
    if (NUM_LAYERS <= 0)  return;

    for (Index l = 1; l <= NUM_LAYERS; ++l) {
        for (Index i = 0; i < layer[l]->Units; ++i) {
            if (layer[l]->WeightSave) {
                memcpy(layer[l]->WeightSave[i],
                       layer[l]->Weight[i],
                       (layer[l - 1]->Units + 1) * sizeof(Value));
            }
        }
    }
}


void BasicNET::GetWeightUpdateAccumulator(
        Math::Vector<Value>* weightUpdateAccumulator) const {
    Index k = 0;
    weightUpdateAccumulator->Init(this->NumWeights());
    for (Index l = 1; l <= NUM_LAYERS; ++l) {
        for (Index i = 0; i < layer[l]->Units; ++i) {
            for (Index j = 0; j <= layer[l - 1]->Units; ++j) {
                weightUpdateAccumulator->Set(
                        k++, layer[l]->WeightUpdateAccumulator[i][j]);
            }
        }
    }
}

void BasicNET::AddWeightUpdateAccumulator(
        Math::Vector<Value>* weightUpdateAccumulator) const {
    CHECK_EQ(this->NumWeights(), static_cast<Index>(weightUpdateAccumulator->Size()));
    Index k = 0;
    for (Index l = 1; l <= NUM_LAYERS; ++l) {
        for (Index i = 0; i < layer[l]->Units; ++i) {
            for (Index j = 0; j <= layer[l - 1]->Units; ++j) {
                weightUpdateAccumulator->Add(
                        k++, layer[l]->WeightUpdateAccumulator[i][j]);
            }
        }
    }
}

void BasicNET::GetWeights(Math::Vector<Value>* weights) const {
    Index k = 0;
    weights->Init(this->NumWeights());
    for (Index l = 1; l <= NUM_LAYERS; ++l) {
        const Layer* upper = layer[l];
        const Layer* lower = layer[l - 1];
        for (Index i = 0; i < upper->Units; ++i) {
            for (Index j = 0; j <= lower->Units; ++j) {
                weights->Set(k++, upper->Weight[i][j]);
            }
        }
    }
    if (k != this->NumWeights()) {
        FAULT("ERROR unexpected weights size " << this->NumWeights() <<
                " != " << k);
    }
}

void BasicNET::SetWeights(const Math::Vector<Value>& weights) const {
    if (weights.Size() != this->NumWeights()) {
        FAULT("ERROR unexpected weights size " << this->NumWeights() <<
                " != " << this->NumWeights());
    }

    int k = 0;
    for (Index l = 1; l <= NUM_LAYERS; ++l) {
        for (Index i = 0; i < layer[l]->Units; ++i) {
            for (Index j = 0; j <= layer[l - 1]->Units; ++j) {
                layer[l]->Weight[i][j] = weights[k++];
            }
        }
    }
}

void BasicNET::ComputeWeightPositions() {
    weight_positions.reserve(this->NumWeights());
    for (Index l = 1; l <= NUM_LAYERS; ++l)
        for (Index i = 0; i < layer[l]->Units; ++i)
            for (Index j = 0; j <= layer[l - 1]->Units; ++j)
                weight_positions.push_back(WeightPosition(l, i, j));
}

void BasicNET::SetWeight(Index index, const Value weight) {
    if (index >= this->NumWeights() ||
        index >= weight_positions.size()) {
        FAULT("ERROR unexpected weight index " << index);
    }
    const WeightPosition& wp = weight_positions[index];
    layer[wp.layer]->Weight[wp.unit_upper][wp.unit_lower] = weight;
}

void
BasicNET::RestoreWeights() {
    for (Index l = 1; l <= NUM_LAYERS; ++l) {
        for (Index i = 0; i < layer[l]->Units; ++i) {
            if (layer[l]->WeightSave) {
                memcpy(layer[l]->Weight[i],
                       layer[l]->WeightSave[i],
                       (layer[l - 1]->Units + 1) * sizeof(Value));
            }
        }
    }
}

void
BasicNET::ComputeNumWeights() {
    num_weights = 0;
    for (Index l = 1; l <= NUM_LAYERS; ++l)
        num_weights += layer[l]->NumWeights();
}

void
BasicNET::ComputeNumUnits() {
    num_units = 0;
    for (Index l = 1; l <= NUM_LAYERS; ++l)
        num_units += layer[l]->Units;
}

void
BasicNET::Propagate()
{
    for (Index l = 1; l <= NUM_LAYERS; ++l) {
        PropagateLayer(layer[l - 1], layer[l]);
    }
}


void
BasicNET::PropagateLayer(const Layer* lower, Layer* upper) {
#if __ACTIVATE_OPENMP_FUNCTIONS__ > 0
#pragma omp parallel default(none) shared(lower,upper)
#endif
    {
#if __ACTIVATE_OPENMP_FUNCTIONS__ > 0
#pragma omp for
#endif
        for (Index i = 0; i < upper->Units; ++i) {
            Value sum = 0.0;

            for (Index j = 0; j <= lower->Units; ++j) {
                if (lower->dropouts != NULL && lower->dropouts[j]) {
                    continue;
                }
                sum += upper->Weight[i][j] * lower->Output[j];
            }
            upper->Output[i] = upper->ofunction->Function(sum);
        }
        upper->Output[upper->Units] = bias;
    }  // end parallel section
}

void
SparseNET::PropagateInputLayer()
{
    Layer* upper = layer[1];
    Layer* lower = layer[0];

    Value sum[upper->Units];
    memset(sum, 0, upper->Units * sizeof(Value));

    Value* output = upper->Output;
    Value** weights = upper->Weight;
    for (SparsePattern::const_iterator j = theInput.begin();
         j != theInput.end(); ++j) {
        if (lower->dropouts != NULL && lower->dropouts[j->first]) {
            continue;
        }

        for (Index i = 0; i < upper->Units; ++i) {
            sum[i] += weights[i][j->first] * j->second;
        }
    }
    for (Index i = 0; i < upper->Units; ++i) {
        output[i] = upper->ofunction->Function(sum[i]);
    }
    output[upper->Units] = bias;
}

void
SparseNET::Propagate()
{
    PropagateInputLayer();
    for (Index l = 2; l <= NUM_LAYERS; ++l)
        PropagateLayer(layer[l - 1], layer[l]);
}


void
BasicNET::BackpropagateLayer(const Layer* upper, Layer* lower) {
    CHECK_GT(lower->Units, static_cast<Index>(0));

    // If the input and output layers are the
    // same, use a temporary vector to allow backpropagating a layer on itself.
    Value* error = (lower == upper ? new Value[lower->Units] : lower->Error);

#if __ACTIVATE_OPENMP_FUNCTIONS__ > 0
#pragma omp parallel default(none) shared(lower,upper,error)
#endif
    {
#if __ACTIVATE_OPENMP_FUNCTIONS__ > 0
#pragma omp for
#endif
        for (Index i = 0; i < lower->Units; ++i) {
            if (lower->dropouts != NULL && lower->dropouts[i]) {
                continue;
            }
            Value err = 0.0;
            for (Index j = 0; j < upper->Units; ++j) {
                err += upper->Weight[j][i] * upper->Error[j];
            }
            error[i] = lower->ofunction->Derivative(lower->Output[i]) * err;
        }
    }  // end parallel section

    if (lower == upper) {
        memcpy(lower->Error, error, sizeof(Value) * lower->Units);
        delete[] error;
    }
}

void
BasicNET::Backpropagate() {
    for (Index l = NUM_LAYERS; l > 1; l--)
        BackpropagateLayer(layer[l], layer[l - 1]);
}

// Computes the gradient using the derivative definition:
// dE(input)/dw = dE/dNN dNN/dw where
// dNN/dw = lim_{\epsilon->0} [NN(w+\epsilon, input) - NN(w, input)] / \epsilon
// This is very slow and can be done only for small nets and for debugging purposes.
void
NET::NumericDerivative(const Pattern& input, const Value* errors,
        const Value epsilon, Math::Vector<Value>* derivative) {
    derivative->Init(this->NumWeights());

    Index offset = 0;
    ScopedArr<Value> output(new Value[layer[NUM_LAYERS]->Units]);
    ScopedArr<Value> output1(new Value[layer[NUM_LAYERS]->Units]);
    for (Index l = 1; l <= NUM_LAYERS; ++l) {
        for (Index i = 0; i < layer[l]->Units; ++i) {
            for (Index j = 0; j <= layer[l - 1]->Units; ++j) {
                Simulate(input, output.Get());
                layer[l]->Weight[i][j] += epsilon;
                Simulate(input, output1.Get());
                layer[l]->Weight[i][j] -= epsilon;

                Value der = 0;
                for (Index k = 0; k < layer[NUM_LAYERS]->Units; ++k) {
                    der += errors[k] * (output1[k] - output[k]) / epsilon;
                }
                derivative->Add(offset++, der);
            }
        }
    }
}

// Computes the gradient using the derivative definition:
// dE(input)/dw = dE/dNN dNN/dw where
// dNN/dw = lim_{\epsilon->0} [NN(w+\epsilon, input) - NN(w, input)] / \epsilon
// This is very slow and can be done only for small nets and for debugging purposes.
void
SparseNET::NumericDerivative(const SparsePattern& input, const Value* errors,
        const Value epsilon, Math::Vector<Value>* derivative) {
    derivative->Init(this->NumWeights());

    Index offset = 0;
    ScopedArr<Value> output(new Value[layer[NUM_LAYERS]->Units]);
    ScopedArr<Value> output1(new Value[layer[NUM_LAYERS]->Units]);
    for (Index l = 1; l <= NUM_LAYERS; ++l) {
        for (Index i = 0; i < layer[l]->Units; ++i) {
            for (Index j = 0; j <= layer[l - 1]->Units; ++j) {
                Simulate(input, output.Get());
                layer[l]->Weight[i][j] += epsilon;
                Simulate(input, output1.Get());
                layer[l]->Weight[i][j] -= epsilon;

                Value der = 0;
                for (Index k = 0; k < layer[NUM_LAYERS]->Units; ++k) {
                    der += errors[k] * (output1[k] - output[k]) / epsilon;
                }
                derivative->Add(offset++, der);
            }
        }
    }
}

void
BasicNET::SetOutputError(const Value* errors) {
    Value patternError = 0.0;
    for (Index i = 0; i < layer[NUM_LAYERS]->Units; ++i) {
        const Value Out = layer[NUM_LAYERS]->Output[i];
        const Value Err = errors[i];
        patternError += Err;
        layer[NUM_LAYERS]->Error[i] = layer[NUM_LAYERS]->ofunction->Derivative(Out) * Err;
    }

    Error += patternError;
}

void
BasicNET::ComputeOutputError(const Targets& target) {
    Value patternError = 0.0;
    for (Index i = 0; i < layer[NUM_LAYERS]->Units; ++i) {
        const Value Out = layer[NUM_LAYERS]->Output[i];
        const Value Err = target[i] - Out;
        layer[NUM_LAYERS]->Error[i] = layer[NUM_LAYERS]->ofunction->Derivative(Out) * Err;

        patternError += 0.5 * Err * Err;
    }

    Error += patternError;
}

void
BasicNET::ClearOutputError() {
    Error = 0;
    memset(layer[NUM_LAYERS]->Error, 0,
           layer[NUM_LAYERS]->Units * sizeof(Value));
}

void
BasicNET::ClearLayersError()
{
    Error = 0;
    for (Index i = 1; i <= NUM_LAYERS; ++i)
        memset(layer[i]->Error, 0, layer[i]->Units * sizeof(Value));
}

void
BasicNET::AccumulateUpdates() {
    for (Index l = 1; l <= NUM_LAYERS; ++l) {
        Layer* upper = layer[l];
        const Layer* lower = layer[l - 1];
        Value** weightUpdateAccumulator = upper->WeightUpdateAccumulator;
#if __ACTIVATE_OPENMP_FUNCTIONS__ > 1
#pragma omp parallel default(none) shared(upper,lower,weightUpdateAccumulator)
#endif
        {
#if __ACTIVATE_OPENMP_FUNCTIONS__ > 1
#pragma omp for
#endif
            for (Index i = 0; i < upper->Units; ++i) {
                const Value err = upper->Error[i];
                for (Index j = 0; j <= lower->Units; ++j) {
                    const Value out = lower->Output[j];
                    weightUpdateAccumulator[i][j] += err * out;
                }
            }
        }  // end parallel section
    }
}

void
BasicNET::AccumulateUpdates(Math::Vector<Value>* updates, const Value weight) const {
    Index k = 0;
    for (Index l = 1; l <= NUM_LAYERS; ++l) {
        const Layer* upper = layer[l];
        const Layer* lower = layer[l - 1];
        for (Index i = 0; i < upper->Units; ++i) {
            const Value err = weight * upper->Error[i];
            for (Index j = 0; j <= lower->Units; ++j) {
                const Value out = lower->Output[j];
                updates->Add(k++, err * out);
            }
        }
    }
}

void
BasicNET::ScaleErrors(const Value weight) {
    for (Index l = 1; l <= NUM_LAYERS; ++l) {
        Layer* L = layer[l];
        for (Index i = 0; i < L->Units; ++i) {
            L->Error[i] *= weight;
        }
    }
}

void
SparseNET::AccumulateUpdates() {
    CHECK_GT(NUM_LAYERS, static_cast<Index>(0));

    Layer* L = layer[1];
    Value** app = layer[1]->WeightUpdateAccumulator;
    for (SparsePattern::const_iterator k = theInput.begin();
            k != theInput.end(); ++k) {
        for (Index i = 0; i < L->Units; ++i)
            app[i][k->first] += L->Error[i] * k->second;
    }

    for (Index l = 2; l <= NUM_LAYERS; ++l) {
        L = layer[l];
        const Layer* L1 = layer[l - 1];
        app = L->WeightUpdateAccumulator;

#if __ACTIVATE_OPENMP_FUNCTIONS__ > 1
#pragma omp parallel default(none) shared(app,L,L1)
#endif
        {
#if __ACTIVATE_OPENMP_FUNCTIONS__ > 1
#pragma omp for
#endif
            for (Index i = 0; i < L->Units; ++i) {
                const Value Err = L->Error[i];
                for (Index j = 0; j <= L1->Units; ++j) {
                    app[i][j] += Err * L1->Output[j];
                }
            }
        }  // end parallel section
    }
}

void
SparseNET::AccumulateUpdates(Math::Vector<Value>* updates, const Value weight) const {
    CHECK_GT(NUM_LAYERS, static_cast<Index>(0));

    const Layer* input_upper = layer[1];
    for (SparsePattern::const_iterator k = theInput.begin();
            k != theInput.end(); ++k) {
        for (Index i = 0; i < input_upper->Units; ++i)
            updates->Add((Units[0] + 1) * i + k->first,
                    weight * input_upper->Error[i] * k->second);
    }

    Index offset = (Units[0] + 1) * input_upper->Units;
    for (Index l = 2; l <= NUM_LAYERS; ++l) {
        const Layer* upper = layer[l];
        const Layer* lower = layer[l - 1];
        for (Index i = 0; i < upper->Units; ++i) {
            const Value Err = weight * upper->Error[i];
            for (Index j = 0; j <= lower->Units; ++j) {
                updates->Add(offset++, Err * lower->Output[j]);
            }
        }
    }
}

Value
BasicNET::MaxWeight(Index startLayer) const {
    CHECK_GT(NUM_LAYERS, static_cast<Index>(0));

    Value max_weight = 0;
    for (Index l = startLayer; l <= NUM_LAYERS; ++l) {
        const Layer* L = layer[l];
        for (Index i = 0; i < L->Units; ++i) {
            for (Index j = 0; j <= layer[l - 1]->Units; ++j) {
                if (std::abs(L->Weight[i][j]) > max_weight) {
                    max_weight = std::abs(L->Weight[i][j]);
                }
            }
        }
    }

    return max_weight;
}

Value
BasicNET::MaxG(Index startLayer) const {
    CHECK_GT(NUM_LAYERS, static_cast<Index>(0));

    Value max_update = 0;
    for (Index l = startLayer; l <= NUM_LAYERS; ++l) {
        const Layer* L = layer[l];
        for (Index i = 0; i < L->Units; ++i) {
            for (Index j = 0; j <= layer[l - 1]->Units; ++j) {
                if (std::abs(L->WeightUpdateAccumulator[i][j]) > max_update) {
                    max_update = std::abs(L->WeightUpdateAccumulator[i][j]);
                }
            }
        }
    }

    return max_update;
}

void
BasicNET::NormalizeG(const Value factor)
{
    if (factor < 1.0e-6)
        return;

    const Value norm = 1.0 / factor;

    for (Index l = 1; l <= NUM_LAYERS; ++l) {
        Layer* L = layer[l];
#if __ACTIVATE_OPENMP_FUNCTIONS__ > 1
#pragma omp parallel default(none) shared(L,l)
#endif
        {
#if __ACTIVATE_OPENMP_FUNCTIONS__ > 1
#pragma omp for
#endif
            for (Index i = 0; i < L->Units; ++i) {
                for (Index j = 0; j <= layer[l - 1]->Units; ++j) {
                    L->WeightUpdateAccumulator[i][j] *= norm;
                }
            }
        }  // end parallel section
    }
}

void
BasicNET::NormalizeWeights(const Value factor)
{
    if (factor < 1.0e-6)  return;

    const Value norm = 1.0 / factor;

    for (Index l = 1; l <= NUM_LAYERS; ++l) {
        Layer* L = layer[l];
#if __ACTIVATE_OPENMP_FUNCTIONS__ > 1
#pragma omp parallel default(none) shared(L,l)
#endif
        {
#if __ACTIVATE_OPENMP_FUNCTIONS__ > 1
#pragma omp for
#endif
            for (Index i = 0; i < L->Units; ++i)
                for (Index j = 0; j <= layer[l - 1]->Units; ++j)
                    L->Weight[i][j] *= norm;
        }  // end parallel section
    }
}

void
BasicNET::ScaleWeights(const Value factor)
{
    for (Index l = 1; l <= NUM_LAYERS; ++l) {
        Layer* L = layer[l];
        for (Index i = 0; i < L->Units; ++i)
            for (Index j = 0; j <= layer[l - 1]->Units; ++j)
                L->Weight[i][j] *= factor;
    }
}

void
BasicNET::ScaleWeightsForDropout() {
    if (this->dropout_thr == 0 && this->input_dropout_thr == 0) {
        return;
    }

    Layer* L = layer[1];
    for (Index i = 0; i < L->Units; ++i)
        for (Index j = 0; j <= layer[0]->Units; ++j)
            L->Weight[i][j] *= 1.0 - this->input_dropout_thr;
    for (Index l = 2; l <= NUM_LAYERS; ++l) {
        L = layer[l];
        for (Index i = 0; i < L->Units; ++i)
            for (Index j = 0; j <= layer[l - 1]->Units; ++j)
                L->Weight[i][j] *= 1.0f - this->dropout_thr;
    }
}

void
BasicNET::UnscaleWeightsForDropout() {
    if (this->dropout_thr == 0 && this->input_dropout_thr == 0)
        return;

    const Value input_rescale = 1.0 / (1.0 - this->input_dropout_thr);
    Layer* L = layer[1];
    for (Index i = 0; i < L->Units; ++i) {
        for (Index j = 0; j <= layer[0]->Units; ++j) {
            L->Weight[i][j] *= input_rescale;
        }
    }

    const Value rescale = 1.0 / (1.0 - this->dropout_thr);
    for (Index l = 2; l <= NUM_LAYERS; ++l) {
        L = layer[l];
        for (Index i = 0; i < L->Units; ++i) {
            for (Index j = 0; j <= layer[l - 1]->Units; ++j) {
                L->Weight[i][j] *= rescale;
            }
        }
    }
}

void
BasicNET::LimitWeightNormByNeuron(const Value max_norm) {
    CHECK_GT(max_norm, static_cast<Value>(0));
    for (Index l = 1; l <= NUM_LAYERS; ++l) {
        Layer* L = layer[l];
        for (Index i = 0; i < L->Units; ++i) {
            Value norm = 0;
            for (Index j = 0; j <= layer[l - 1]->Units; ++j) {
                norm += L->Weight[i][j] * L->Weight[i][j];
            }
            norm = std::sqrt(norm);

            if (norm > max_norm) {
                const float rescale = max_norm / norm;
                for (Index j = 0; j <= layer[l - 1]->Units; ++j) {
                    L->Weight[i][j] *= rescale;
                }
            }
        }
    }
}

void
NET::Update(Value factor)
{
    Value app, *appDW;
    Value uF;

    Layer* L;
    for (Index l = 1; l <= NUM_LAYERS; ++l) {
        L = layer[l];
        for (Index i = 0; i < L->Units; ++i)
            for (Index j = 0; j <= layer[l - 1]->Units; ++j) {
                app = L->WeightUpdateAccumulator[i][j] * factor;
                if (L->dWeight) {
                    appDW = &(L->dWeight[i][j]);
                    uF = Eta * app + Alpha * (*appDW) * factor;
                    // uF = Eta * (app + 2 * L->Weight[i][j] / WeightsNorm) + Alpha * (*appDW) * factor; // se voglio fare regolarizzazione
                    L->Weight[i][j] += uF;
                    (*appDW) = uF;
                }
                else {
                    L->Weight[i][j] += Eta * app;
                }
            }
    }
}

Value
SparseNET::MaxG() const {
    Value max = 0;

    for (Index l = 2; l <= NUM_LAYERS; ++l) {
        const Layer* L = layer[l];
        for (Index i = 0; i < L->Units; ++i)
            for (Index j = 0; j <= layer[l - 1]->Units; ++j)
                if (std::abs(L->WeightUpdateAccumulator[i][j]) > max)
                    max = std::abs(L->WeightUpdateAccumulator[i][j]);
    }
    const Layer* L = layer[1];
    for (AllInputs::const_iterator k = allInput.begin();
            k != allInput.end(); ++k)
        for (Index i = 0; i < L->Units; ++i) {
            if (std::abs(L->WeightUpdateAccumulator[i][*k]) > max)
                max = std::abs(L->WeightUpdateAccumulator[i][*k]);
        }

    return max;
}

Value
SparseNET::MaxWeight() const {
    CHECK_GT(NUM_LAYERS, static_cast<Index>(0));

    Value max = 0;
    for (Index l = 2; l <= NUM_LAYERS; ++l) {
        const Layer* L = layer[l];
        for (Index i = 0; i < L->Units; ++i)
            for (Index j = 0; j <= layer[l - 1]->Units; ++j)
                if (std::abs(L->Weight[i][j]) > max)
                    max = std::abs(L->Weight[i][j]);
    }
    const Layer* L = layer[1];
    for (AllInputs::const_iterator k = allInput.begin();
            k != allInput.end(); ++k) {
        for (Index i = 0; i < L->Units; ++i) {
            if (std::abs(L->Weight[i][*k]) > max)
                max = std::abs(L->Weight[i][*k]);
        }
    }
    return max;
}

void
SparseNET::NormalizeG(Value factor)
{
    if (NUM_LAYERS <= 0 || factor < 1.0e-6)
        return;

    Index l, i, j;

    Layer* L;

    for (l = 2; l <= NUM_LAYERS; ++l) {
        L = layer[l];
        for (i = 0; i < L->Units; ++i)
            for (j = 0; j <= layer[l - 1]->Units; ++j)
                L->WeightUpdateAccumulator[i][j] /= factor;
    }
    L = layer[1];
    for (AllInputs::const_iterator k = allInput.begin();
            k != allInput.end(); ++k)
        for (i = 0; i < L->Units; ++i)
            L->WeightUpdateAccumulator[i][*k] /= factor;
}

void
SparseNET::NormalizeWeights(Value factor)
{
    Index l, i, j;

    Layer* L;

    if (NUM_LAYERS > 0 && factor > 1.0e-10)
    {
        for (l = 2; l <= NUM_LAYERS; ++l)
        {
            L = layer[l];
            for (i = 0; i < L->Units; ++i)
                for (j = 0; j <= layer[l - 1]->Units; ++j)
                    L->Weight[i][j] /= factor;
        }
        L = layer[1];
        for (AllInputs::const_iterator k = allInput.begin();
                k != allInput.end(); ++k)
            for (i = 0; i < L->Units; ++i)
                L->Weight[i][*k] /= factor;
    }
}

void
SparseNET::Update_upper_layers(Value factor)
{
    Index l, i, j;

    Value app;
    Value uF;
    Layer* L;

    if (NUM_LAYERS > 0) {
        for (l = 2; l <= NUM_LAYERS; ++l) {
            L = layer[l];
            for (i = 0; i < L->Units; ++i) {
                for (j = 0; j <= layer[l - 1]->Units; ++j) {
                    app = L->WeightUpdateAccumulator[i][j] * factor;
                    if (L->dWeight) {
                        uF = Eta * app + Alpha * L->dWeight[i][j] * factor;
                        L->Weight[i][j] += uF;
                        L->dWeight[i][j] = uF;
                    }
                    else {
                        L->Weight[i][j] += Eta * app;
                    }
                }
            }
        }
    }
}

void
SparseNET::Update(Value factor)
{
    Index i;

    Value app;
    Value uF;
    Layer* L;

    Update_upper_layers(factor);

    if (NUM_LAYERS > 0) {
        L = layer[1];
        for (AllInputs::const_iterator k = allInput.begin();
                k != allInput.end(); ++k) {
            for (i = 0; i < L->Units; ++i) {
                app = L->WeightUpdateAccumulator[i][*k] * factor;
                if (L->dWeight) {
                    uF = Eta * app + Alpha * L->dWeight[i][*k] * factor;
                    L->Weight[i][*k] += uF;
                    L->dWeight[i][*k] = uF;
                } else {
                    L->Weight[i][*k] += Eta * app;
                }
            }
        }
    }
}

void
SparseNET::UpdateForPattern(
        const SparsePattern& Input, Value factor)
{
    Index i;

    Value app;
    Value uF;
    Layer* L;

    Update_upper_layers(factor);

    if (NUM_LAYERS > 0)
    {
        L = layer[1];
        for (SparsePattern::const_iterator k = Input.begin();
                k != Input.end();
                k ++)
            for (i = 0; i < L->Units; ++i) {
                app = L->WeightUpdateAccumulator[i][k->first] * factor;
                if (L->dWeight) {
                    uF = Eta * app + Alpha * L->dWeight[i][k->first] * factor;
                    L->Weight[i][k->first] += uF;
                    L->dWeight[i][k->first] = uF;
                }
                else
                    L->Weight[i][k->first] += Eta * app;
            }
    }
}

void
BasicNET::ClearUpdates(Index startFromLayer)
{
    Index l, i;

    if (NUM_LAYERS > 0)
        for (l = startFromLayer; l <= NUM_LAYERS; ++l)
            for (i = 0; i < layer[l]->Units; ++i)
                memset(layer[l]->WeightUpdateAccumulator[i],
                        0,
                        sizeof(Value) * (layer[l - 1]->Units + 1));
}

void
SparseNET::ClearInputLayerUpdates(bool allinputs)
{
    if (NUM_LAYERS > 0) {
        if (allinputs) {
            AllInputs::const_iterator j;
            for (Index i = 0; i < layer[1]->Units; ++i)
                for (j = allInput.begin(); j != allInput.end(); j ++)
                    layer[1]->WeightUpdateAccumulator[i][*j] = 0;
        } else {
            SparsePattern::const_iterator j;
            for (Index i = 0; i < layer[1]->Units; ++i)
                for (j = theInput.begin(); j != theInput.end(); j ++)
                    layer[1]->WeightUpdateAccumulator[i][j->first] = 0;
        }
    }
}

void
NET::Simulate(const Pattern& input, Value* output)
{
    SetInput(input);
    Propagate();
    if (output) {
        this->GetOutput(output);
    }
}

void
SparseNET::Simulate(const SparsePattern& input, Value* output)
{
    this->SetInput(input);
    Propagate();
    if (output != NULL)
        this->GetOutput(output);
}

Index
NET::Train(const PatternSet& inputs,
        const TargetSet& targets,
        const PatternSet& crossvalidation,
        const TargetSet& crossvalidationTargets,
        Index Epochs) {
    if (inputs.size() == 0) {
        return 0;
    }
    if (inputs.size() < 10 && train_mode == STOCHASTIC) {
        train_mode = BATCH;
    }
    bool Stop = false;
    Value MinTestError = std::numeric_limits<Value>::max();
    Error = std::numeric_limits<Value>::max();

    Value* Output = new Value[Units[NUM_LAYERS]];

    std::vector<Index> pattern_index;
    if (train_mode == STOCHASTIC) {
        pattern_index.reserve(inputs.size());
        for (Index i = 0; i < inputs.size(); ++i) {
            pattern_index.push_back(i);
        }
    } else {
        pattern_index.resize(static_cast<Index>(inputs.size() * 0.1));
    }
    Index n = 0;
    for (; n < Epochs && !Stop; ++n) {
        this->setDropout(this->input_dropout_thr, this->dropout_thr);

        Value oldError = Error;
        if (train_mode == STOCHASTIC) {
            for (Index i = 0; i < static_cast<Index>(inputs.size() * 0.1); ++i) {
                pattern_index[i] = Math::Rand(static_cast<Index>(0), static_cast<Index>(inputs.size() - 1));
            }
        }

        ClearUpdates();  // to get a correct initialization
        ClearOutputError();
        for (Index i = 0; i < pattern_index.size(); ++i) {
            // #define VERBOSE 1
#if VERBOSE > 0
            if (pattern_index.size() / 10 > 0 && i % (pattern_index.size() / 10) == 0)
                cout << "." << flush;
#endif

            this->Simulate(inputs[pattern_index[i]], Output);
            this->ComputeOutputError(targets[pattern_index[i]]);
            this->Backpropagate();
            this->AccumulateUpdates();

            if(train_mode == PATTERN) {
                this->Update();
                this->ClearUpdates();
            }
        }

        if(train_mode == BATCH || train_mode == STOCHASTIC) {
            this->NormalizeG(this->MaxG());
            this->Update(); // normalizza gradiente rispetto max
            // Update(1.0/(double)NUM); // normalizza gradiente rispetto num esempi
        }

#if VERBOSE > 0
        this->PrintLog(n + 1, Error / pattern_index.size());
#endif

        AdaptLearningRate(oldError, Error);

        if (Error < MIN_ERROR) {
            Stop = true;
        } else if (crossvalidation.size() > 0 && crossvalidationTargets.size() > 0) {
            this->ScaleWeightsForDropout();
            Stop = Crossvalidate(crossvalidation, crossvalidationTargets, MinTestError);
            this->UnscaleWeightsForDropout();
        }
    }
    delete[] Output;

    this->ScaleWeightsForDropout();
    return n; // ritorna numero epoche
}

Value
NET::Test(const PatternSet& inputs, const TargetSet& targets) {
  Value datasetError = 0;
  Value* Output = new Value[Units[NUM_LAYERS]];

  for (Index i = 0; i < inputs.size(); ++i)
    {
      ClearOutputError();
      Simulate(inputs[i], Output);
      ComputeOutputError(targets[i]);
      datasetError += Error;
    }

  delete[] Output;
  return datasetError;
}

bool
NET::Crossvalidate(const PatternSet& crossvalidation,
        const TargetSet& crossvalidationTargets,
        Value MinTestError) {
    bool stop = false;
    const Value testError = this->Test(crossvalidation, crossvalidationTargets);
    if (testError < MinTestError) {
        MinTestError = testError;
        if(this->getWeightSaveMode()) {
            this->SaveWeights();
        }
    } else if (testError > STOP_CONDITION * MinTestError) {
        stop = true;
        if(this->getWeightSaveMode()) {
            this->RestoreWeights();
        }
    }
    return stop;
}

bool
SparseNET::Crossvalidate(const SparsePatternSet& crossvalidation,
        const TargetSet& crossvalidationTargets,
        Value MinTestError) {
    bool stop = false;
    const Value testError = Test(crossvalidation, crossvalidationTargets);
    if (testError < MinTestError) {
        MinTestError = testError;
        if(this->getWeightSaveMode()) {
            this->SaveWeights();
        }
    } else if (testError > STOP_CONDITION * MinTestError) {
        stop = true;
        if(this->getWeightSaveMode()) {
            this->RestoreWeights();
        }
    }
    return stop;
}

Index
SparseNET::Train(const SparsePatternSet& inputs,
        const TargetSet& targets,
        const SparsePatternSet& crossvalidation,
        const TargetSet& crossvalidationTargets,
        Index Epochs) {
    bool Stop = false;
    Value MinTestError = std::numeric_limits<Value>::max();
    Error = std::numeric_limits<Value>::max();

    Value* Output = new Value[Units[NUM_LAYERS]];

    Index n = 0;

    SetAllInputs(inputs);

    for (n = 0; n < Epochs && !Stop; ++n) {
        this->setDropout(this->input_dropout_thr, this->dropout_thr);

        Value oldError = Error;
        ClearInputLayerUpdates(true);  // serve?
        ClearUpdates(); // altrimenti non sono ben inizializzati
        ClearOutputError();
        for (Index i = 0; i < static_cast<Index>(inputs.size()); ++i) {
#if VERBOSE > 0
            if (inputs.size() / 10 > 0 && i % (inputs.size() / 10) == 0)
                cout << "."; cout.flush();
#endif
            Simulate(inputs[i], Output);
            ComputeOutputError(targets[i]);
            Backpropagate();
            AccumulateUpdates();

            if(train_mode == PATTERN) {
                UpdateForPattern(inputs[i]);
                ClearInputLayerUpdates(false);  // only used inputs are cleared for speed.
                BasicNET::ClearUpdates(2);
            }
        }

        if(train_mode == BATCH) {
            this->NormalizeG(this->MaxG());
            Update(); // normalizza gradiente rispetto max
        }

#if VERBOSE > 0
        this->PrintLog(n + 1, Error / Inputs.size());
#endif

        AdaptLearningRate(oldError, Error);

        if (crossvalidation.size() > 0 && crossvalidationTargets.size() > 0) {
            this->ScaleWeightsForDropout();
            Stop = Crossvalidate(crossvalidation, crossvalidationTargets, MinTestError);
            this->UnscaleWeightsForDropout();
        }
    }

    delete[] Output;
    this->UnscaleWeightsForDropout();

    return n; // ritorna numero epoche
}

Value
SparseNET::Test(const vector<SparsePattern>& inputs, const TargetSet& targets)
{
    Value datasetError = 0.0;
    Value* output = new Value[Units[NUM_LAYERS]];

    for (Index i = 0; i < static_cast<Index>(inputs.size()); ++i) {
        ClearOutputError();
        Simulate(inputs[i], output);
        ComputeOutputError(targets[i]);
        datasetError += Error;
    }

    delete[] output;
    return datasetError;

}


// Perceptron Constructors
Perceptron::Perceptron() : NET()
{ }

Perceptron::Perceptron(const Perceptron& N) : NET(N)
{ }

Perceptron::Perceptron(Index inputs, Index outputs)
{
    NUM_LAYERS = 1;
    Units = new Index[2];
    Units[0] = inputs;
    Units[1] = outputs;
    Generate(BP::ActivationFunction::LINEAR);
    RandomWeights(346623);
}

void
Perceptron::ComputeOutputError(const Targets& target)
{
    Value Out, Err;

    Value patternError = 0;
    for (Index i = 0; i < layer[NUM_LAYERS]->Units; ++i)
    {
        Out = layer[NUM_LAYERS]->Output[i];
        if (target[i] * Out > 0)
            Err = 0.1 / (1.0 + std::abs(Out));
        else
            Err = 1.0 + std::abs(Out);

        patternError += 0.5 * Err * Err;
    }
    Error += patternError;
}

Index
Perceptron::TrainPerceptron(const PatternSet& inputs,
        const TargetSet& targets,
        Index Epochs)
{

    bool Stop = false;

    Index n, k, j;
    Layer* L = layer[1];
    NormalizeWeights(this->MaxWeight());
    for (n = 0; n < Epochs && !Stop; ++n) {
        ClearUpdates();
        ClearOutputError();

        for (Index i = 0; i < inputs.size(); ++i) {
#if VERBOSE > 0
            if (inputs.sze() / 10 > 0 && i % (inputs.sze() / 10) == 0)
                cout << "." << flush;
#endif

            Simulate(inputs[i], NULL);
            ComputeOutputError(targets[i]);
            for (j = 0; j < Units[1]; ++j) {
                if (targets[i][j] > 0)
                    for (k = 0; k < Units[0]; ++k)
                        L->WeightUpdateAccumulator[j][k] += inputs[i][k];
                else
                    for (k = 0; k < Units[0]; ++k)
                        L->WeightUpdateAccumulator[j][k] -= inputs[i][k];
            }
        }
        this->Update();
        this->NormalizeWeights(this->MaxWeight());

#if VERBOSE > 0
        this->PrintLog(n + 1, 1);
#endif
    }

    return n; // ritorna numero epoche
}

// Sparse Perceptron Constructors
SparsePerceptron::SparsePerceptron() : 
            SparseNET()
{ }

SparsePerceptron::SparsePerceptron(const SparsePerceptron& N) :
            SparseNET(N)
{ }

SparsePerceptron::SparsePerceptron(Index inputs, Index outputs)
{
    NUM_LAYERS = 1;
    Units = new Index[2];
    Units[0] = inputs;
    Units[1] = outputs;
    Generate(BP::ActivationFunction::LINEAR);
    RandomWeights(346623);
}

void
SparsePerceptron::ComputeOutputError(const Targets& target) {
    Value patternError = 0;
    for (Index i = 0; i < layer[NUM_LAYERS]->Units; ++i) {
        Value Out = layer[NUM_LAYERS]->Output[i];
        Value Err = 0;
        if (target[i] * Out > 0)
            Err = 0.1 / (1.0 + std::abs(Out));
        else
            Err = 1.0 + std::abs(Out);

        patternError += 0.5 * Err * Err;
    }
    Error += patternError;
}

Index
SparsePerceptron::TrainPerceptron(const SparsePatternSet& inputs,
        const TargetSet& targets,
        Index Epochs)
{

    bool Stop = false;

    SetAllInputs(inputs);

    Layer* L = layer[1];
    NormalizeWeights(this->MaxWeight());
    Index n, j;
    SparsePattern::const_iterator k;
    for (n = 0; n < Epochs && !Stop; ++n) {
        ClearUpdates();
        ClearOutputError();

        for (Index i = 0; i < inputs.size(); ++i) {
#if VERBOSE > 0
            if (inputs.size() / 10 > 0 && i % (inputs.size() / 10) == 0)
                cout << "." << flush;
#endif
            Simulate(inputs[i], NULL);
            ComputeOutputError(targets[i]);
            for (k = inputs[i].begin(); k != inputs[i].end(); ++k)
                for (j = 0; j < Units[1]; ++j) {
                    if (targets[i][j] > 0)
                        L->WeightUpdateAccumulator[j][k->first] += k->second;
                    else
                        L->WeightUpdateAccumulator[j][k->first] -= k->second;
                }
        }
        this->Update();
        this->NormalizeWeights(this->MaxWeight());

#if VERBOSE > 0

        this->PrintLog(n + 1, Error / inputs.size());
#endif

    }
    return n; // ritorna numero epoche
}

OneLayerNET::OneLayerNET(const OneLayerNET& N) :
            NET(N)
{ }

OneLayerNET::OneLayerNET(const Index inputs,
        const Index outputs,
        const ActivationFunction::Type foutput_type_)
{
    Init();
    NUM_LAYERS = 1;
    Units = new Index[NUM_LAYERS + 1];
    Units[0] = inputs;
    Units[1] = outputs;

    Generate(foutput_type_);

    // initWeights(0.5);
    RandomWeights(346623);
}

TwoLayersNET::TwoLayersNET(const Index inputs,
        const Index hidden,
        const Index outputs,
        const ActivationFunction::Type foutput_type_)
{
    Init();
    NUM_LAYERS = 2;
    Units = new Index[NUM_LAYERS + 1];
    Units[0] = inputs;
    Units[1] = hidden;
    Units[2] = outputs;


    Generate(foutput_type_);

    // initWeights(0.5);
    RandomWeights(346623);
}

TwoLayersNET::TwoLayersNET(const Index inputs,
        const Index hidden,
        const Index outputs,
        const vector<ActivationFunction::Type>& foutput_types_)
{
    Init();
    NUM_LAYERS = 2;
    Units = new Index[NUM_LAYERS + 1];
    Units[0] = inputs;
    Units[1] = hidden;
    Units[2] = outputs;


    Generate(foutput_types_);

    // initWeights(0.5);
    RandomWeights(346623);
}

TwoLayersNET::TwoLayersNET(const TwoLayersNET& N) :
            NET(N)
{ }

// Autoassociator Constructors
Autoassociator::Autoassociator(
        const Index inputs,
        const Index hidden,
        const ActivationFunction::Type foutput_type_) :
        TwoLayersNET(inputs, hidden, inputs, foutput_type_)
{ }

Autoassociator::Autoassociator(const Autoassociator& N) :
            TwoLayersNET(N)
{ }


Index
Autoassociator::TrainAutoass(const PatternSet& inputs, Index Epochs) {
    return NET::Train(inputs, inputs, Epochs);
}

