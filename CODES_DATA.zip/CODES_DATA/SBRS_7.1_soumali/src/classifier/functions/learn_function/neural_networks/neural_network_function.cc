#include <iostream>
#include <sstream>

#include "classifier/functions/learn_function/neural_networks/neural_network_function.h"
#include "classifier/functions/learn_function/neural_networks/BP/myBP.h"
#include "data/dataset.h"
#include "data/examples.h"
#include "train/options.h"
#include "utils/general.h"
#include "utils/math/math_vector_operations.h"
#include "utils/string_utils.h"


using namespace std;

namespace Regularization {
NeuralNetworkFunction::NeuralNetworkFunction() :
        CachedLearnFunction("", Function::LEARN, 1, "", 1.0),
        net(NULL),
        input_size(0),
        pre_built_shared_net(NULL),
        pre_built_shared_net_output_index(0),
        pre_built_shared_net_output_size(0),
        pre_built_inputs(false),
        dropout_thr(-1),
        input_dropout_thr(-1),
        limit_weight_norm_by_neuron(-1),
        bias(0) {
}

/* static */
template<typename NN>
NN* NeuralNetworkFunction::CreateNeuralNetworkFromOptions(
        const TrainOptions& options, const Index input_size, const Index output_size, const Function::ID& id) {
    const int num_hidden_units = options.GetNeuralNetworkNumUnits(id);
    const int num_layers = options.GetNeuralNetworkNumLayers();
    CHECK_GE(num_layers, 1);
    if (num_layers > 1) {
        CHECK_GE(num_hidden_units, 0);
    }
    VMESSAGE(3, "FunctionID " << id << " InputSize for NN is: " <<
            input_size << " Layers " << num_layers);

    const BP::ActivationFunction::Type hidden_layer_activation_type =
            BP::ActivationFunction::TypeFromName(
                    options.GetNeuralNetworkHiddenLayerActivation());
    const BP::ActivationFunction::Type output_layer_activation_type =
            BP::ActivationFunction::TypeFromName(
                    options.GetNeuralNetworkOutputLayerActivation());

    vector<BP::ActivationFunction::Type> activations;
    for (int i = 0; i < num_layers - 1; ++i) {
        activations.push_back(hidden_layer_activation_type);
    }
    activations.push_back(output_layer_activation_type);

    BP::Index units[num_layers + 1];
    units[0] = input_size;
    units[num_layers] = output_size;

    for (int i = 1; i < num_layers; ++i) {
        units[i] = num_hidden_units;
    }
    NN* net = new NN(num_layers, units, activations);

    // Initialize the weights.
    net->LecunRandomWeights(12345);

    return net;
}

NeuralNetworkFunction::NeuralNetworkFunction(
        const Function::ID& id_,
        const Function::TYPE predicate_type_,
        const Function::Arity arity_,
        const std::string& domain_,
        const Value bias_,
        const Dataset* dataset,
        const TrainOptions* options,
        NN* pre_built_shared_net_,
        const Index pre_built_shared_net_output_index_) :
        CachedLearnFunction(id_, predicate_type_, arity_, domain_,
                            options ? options->GetBalanceWeight(id) : 1.0),
        net(NULL),
        input_size(0),
        pre_built_shared_net(pre_built_shared_net_),
        pre_built_shared_net_output_index(pre_built_shared_net_output_index_),
        pre_built_shared_net_output_size(0),
        pre_built_inputs(options ? options->GetNeuralNetworkPreBuiltInputs() : false),
        dropout_thr(options ? options->GetNeuralNetworkDropoutThr() : -1),
        input_dropout_thr(options ? options->GetNeuralNetworkInputDropoutThr() : -1),
        limit_weight_norm_by_neuron(options ? options->GetNeuralNetworkWeightNormThr() : -1),
        bias(bias_) {
    static const TrainOptions default_options;
    const TrainOptions* options_to_use = (options ? options : &default_options);

    CHECK_NE_NULL(dataset);
    CHECK_INE_RANGE(bias, static_cast<Value>(0), static_cast<Value>(1));

    const Index datasetSize = dataset->Size();
    CHECK_GT(datasetSize, static_cast<Regularization::Index>(0));

    // First pass over the dataset to compute the input size.
    // This will determine the size of the NN in the input layer.
    // This assumes that the input has feature IDs in terms of positive
    // integer values.
    for (Index i = 0; i < datasetSize; ++i) {
        const Pattern* pattern = dataset->Get(i);
        int max_feature_id = pattern->MaxFeatureId();
        if (max_feature_id >= this->input_size) {
            this->input_size = max_feature_id + 1;
        }
    }
    CHECK_GT(this->input_size, 0);

    if (pre_built_shared_net == NULL) {
        net = CreateNeuralNetworkFromOptions<NN>(*options_to_use, this->input_size, 1, id);
        CHECK_NE_NULL(net);

        // Initialize the weights.
        net->LecunRandomWeights(12345);
        // net->RandomWeights(12345, 0.1);
        if (this->limit_weight_norm_by_neuron > 0) {
            net->LimitWeightNormByNeuron(this->limit_weight_norm_by_neuron);
        }
    } else {
        CHECK_LE_WITH_MESSAGE(this->input_size,
                              static_cast<int>(pre_built_shared_net->getUnits(0)),
                              "Passed a shared network which is not compatible with the required input size");
        net = pre_built_shared_net;
        pre_built_shared_net_output_size = pre_built_shared_net->getUnits(
                pre_built_shared_net_->getNumLayers());
        CHECK_LT(pre_built_shared_net_output_index, pre_built_shared_net_output_size);
    }
    net->GetWeights(&weights);

    // WARNING: net::AllInputs is not initialized to save memory.
    // Not all SparseNet methods will work correctly!
    // Generate the inputs for the NET.
    if (pre_built_inputs) {
        for (Index i = 0; i < datasetSize; ++i) {
            const Pattern* pattern = dataset->Get(i);
            NNinput input;
#ifdef __SPARSE_NN__
            pattern->ToSparseVector(&input, this->input_size - 1);
#else
            pattern->ToVector(&input, this->input_size);
#endif
            inputs[pattern->GetName()] = input;
        }
    }
}

/**
 * Copy constructor:
 */
NeuralNetworkFunction::NeuralNetworkFunction(
        const NeuralNetworkFunction& function_) :
        CachedLearnFunction(function_.GetId(),
                function_.GetType(),
                function_.GetArity(),
                function_.GetDomain(),
                function_.balance_weight),
                net(NULL),
                input_size(function_.input_size),
                pre_built_shared_net(function_.pre_built_shared_net),
                pre_built_shared_net_output_index(function_.pre_built_shared_net_output_index),
                pre_built_shared_net_output_size(function_.pre_built_shared_net_output_size),
                pre_built_inputs(function_.pre_built_inputs),
                dropout_thr(function_.dropout_thr),
                input_dropout_thr(function_.input_dropout_thr),
                limit_weight_norm_by_neuron(function_.limit_weight_norm_by_neuron),
                bias(function_.bias) {
    weights.Copy(function_.Get());

    // Copy the network unless it is a shared one.
    if (function_.net != NULL && function_.net != function_.pre_built_shared_net) {
        net = new NN(*(function_.net));
        inputs = function_.inputs;
    } else if (pre_built_shared_net) {
        // Shared network, just copy the pointer.
        net = pre_built_shared_net;
        CHECK_NE_NULL(net);
    }
}

Function* NeuralNetworkFunction::Clone() const {
    return new NeuralNetworkFunction(*this);
}

/**
 * Destructor
 */
NeuralNetworkFunction::~NeuralNetworkFunction() {
    // Shared networks are owned externally.
    if (net != NULL && net != pre_built_shared_net) {
        delete net;
    }
}

/**
 * Set the W_k weights vector
 */
void NeuralNetworkFunction::Set(const Math::Vector<Value>& weights_)
{
    this->CachedLearnFunction::Set(weights_);
    CHECK_NE_NULL(net);
    net->SetWeights(weights);
}

/**
 * Update the W_k weights vector
 */
void NeuralNetworkFunction::Update(const Math::Vector<Value>& derivative) {
    this->CachedLearnFunction::Update(derivative);
    CHECK(net != NULL);
    net->SetWeights(weights);
}

/**
 * Update the i-th (w_k)i weights
 */
void NeuralNetworkFunction::Update(const Index i, const Value delta) {
    this->CachedLearnFunction::Update(i, delta);
    net->SetWeight(i, weights.Get(i));
}

namespace {
inline Value NormalizeOutput(const Value in, const Value bias, const BP::ActivationFunction* afunction) {
    // return in;
    return in + bias;
    // Bring the result back into the desired range.
    // return ((in - afunction->Min()) / (afunction->Max() - afunction->Min())) + bias; // range [bias+0,1+bias]
    // return (in / (afunction->Max() - afunction->Min())) + bias;  // range [bias - 0.5, bias + 0.5]
}

inline Value NormalizeOutputDerivative(const Value /* in */, const Value /* bias */,
        const BP::ActivationFunction* afunction) {
    return 1;
   //  return 1.0 / (afunction->Max() - afunction->Min());
}
}  // end namespace

/**
 * Eval the function on the pattern of the test set
 */
Value NeuralNetworkFunction::RunEval(const Pattern& pattern) const {
    if (pre_built_shared_net) {
        return RunEvalWithSharedNet(pattern);
    } else {
        bool computed = false;

        // Standard case without shared network.
        Value values = 0;
        if (pre_built_inputs) {
            InputMap::const_iterator iter = inputs.find(pattern.GetName());
            if (iter != inputs.end()) {
                const NNinput& input = iter->second;
                net->Simulate(input, &values);
                computed = true;
            }
        }

        if (!computed) {
            NNinput input;
#ifdef __SPARSE_NN__
            pattern.ToSparseVector(&input, this->input_size - 1);
#else
            pattern.ToVector(&input, this->input_size);
#endif
            net->Simulate(input, &values);
        }
        return NormalizeOutput(values, bias, net->layer[net->NUM_LAYERS]->ofunction);
    }
}

Value NeuralNetworkFunction::RunEvalWithSharedNet(const Pattern& pattern) const {
    bool computed = false;

    CHECK(pre_built_shared_net);
    CHECK_NE_NULL(net);
    ScopedArr<Value> values(new Value[pre_built_shared_net_output_size]);
    if (pre_built_inputs) {
        InputMap::const_iterator iter = inputs.find(pattern.GetName());
        if (iter != inputs.end()) {
            const NNinput& input = iter->second;
            net->Simulate(input, values.Get());
            computed = true;
        }
    }

    if (!computed) {
        NNinput input;
#ifdef __SPARSE_NN__
        pattern.ToSparseVector(&input, this->input_size - 1);
#else
        pattern.ToVector(&input, this->input_size);
#endif
        net->Simulate(input, values.Get());
    }
    return NormalizeOutput(values[pre_built_shared_net_output_index],
                           bias, NULL /* net->layer[net->NUM_LAYERS]->ofunction */);
}


/**
 * Get the derivative of the function with respect to the weights on a pattern.
 */
bool NeuralNetworkFunction::AccumulateGradientInternal(
        const Pattern& pattern,
        const Value weight,
        Math::Vector<Value>* derivative) const {
    // Force a forward step, backprob needs the output of the neurons to be pre-computed.
    // TODO(michi): find a way to cache the outputs without re-doing the forward step every time.
    const Value out = this->RunEval(pattern);
    const Value out_der = NormalizeOutputDerivative(out, bias, net->layer[net->NUM_LAYERS]->ofunction);

    // Backward step.
    if (pre_built_shared_net) {
        ScopedArr<Value> output_error_scp(new Value[pre_built_shared_net_output_size]);
        Value* output_error = output_error_scp.Get();
        memset(output_error, 0, pre_built_shared_net_output_size * sizeof(Value));
        // std::fill(output_error, output_error + pre_built_shared_net_output_size * sizeof(Value), 0);
        output_error[pre_built_shared_net_output_index] = 1;
        net->SetOutputError(output_error);
    } else {
        static const Value one = 1;
        net->SetOutputError(&one);
    }
    net->Backpropagate();

    // Directly accumulate the derivative into the derivative vector.
    net->AccumulateUpdates(derivative, out_der * weight);

    return true;
}

Value NeuralNetworkFunction::EvalRegularizationError() const
{
    return 0.5 * Math::VectorOperations<Value>::DotProduct(weights, weights);
}

/**
 * Evaluate the derivative of regularization error part of the cost function.
 */
void NeuralNetworkFunction::GetRegularizationErrorGradient(
        Math::Vector<Value>* derivative_regularization_part) const {
    derivative_regularization_part->Copy(weights);
}

void NeuralNetworkFunction::InternalClear() {
    if (net && net != pre_built_shared_net) {
        delete net;
    }
    net = NULL;
    pre_built_shared_net = NULL;
    inputs.clear();
    input_size = 0;
    bias = 0;
}

/**
 * Save to stream
 **/
bool NeuralNetworkFunction::InternalSaveToStream(ostream& os) const
{
    os << " " << bias << " ";
    if (!net) {
        return false;
    }
    return net->SaveToStream(os);
}

/*
 * Load weights from a stream.
 */
bool NeuralNetworkFunction::InternalLoadFromStream(istream& is)
{
    this->InternalClear();
    is >> bias;
    if (net == NULL) {
        net = new NN();
    }
    const bool ret = net->LoadFromStream(is);
    net->GetWeights(&this->weights);
    this->input_size = net->Units[0];
    return ret;
}

/* bool NeuralNetworkFunction::InternalLoadFromStream(istream& is)
{
    this->InternalClear();
    is >> bias;
    string filename;
    is >> filename;
    if (net == NULL) {
        net = new NN();
    }

    const bool ret = net->LoadFromFile(filename);
    net->GetWeights(&this->weights);
    this->input_size = net->Units[0];
    return ret;
} */
void NeuralNetworkFunction::EndTrain() {
    if (this->HasDropout()) {
        net->UnscaleWeightsForDropout();
    }
    net->GetWeights(&this->weights);
}

void NeuralNetworkFunction::StartTrainIteration() {
    if (this->HasDropout()) {
        net->setDropout(input_dropout_thr, dropout_thr);
    }
}

void NeuralNetworkFunction::EndTrainIteration() {
    if (this->limit_weight_norm_by_neuron > 0) {
        net->LimitWeightNormByNeuron(this->limit_weight_norm_by_neuron);
    }
    net->GetWeights(&this->weights);
}

void NeuralNetworkFunction::PrepareForCrossvalidation() {
    if (this->HasDropout()) {
        net->UnscaleWeightsForDropout();
    }
    net->GetWeights(&this->weights);
}

void NeuralNetworkFunction::EndCrossvalidation() {
    if (this->HasDropout()) {
        net->ScaleWeightsForDropout();
    }
    net->GetWeights(&this->weights);
}
}  // end Regularization
