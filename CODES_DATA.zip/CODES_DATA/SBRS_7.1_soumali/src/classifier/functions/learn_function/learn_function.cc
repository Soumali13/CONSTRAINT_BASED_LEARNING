#include "classifier/functions/learn_function/learn_function.h"

#include "classifier/functions/learn_function/squashing.h"  // for SquashingFunction
#include "data/dataset.h"
#include "data/examples.h"
#include "data/pattern.h"
#include "train/loss/loss_function.h"  // for LossFunction
#include "utils/gflags/gflags/gflags.h"


// Squashing Function
DEFINE_bool(apply_squashing_function_on_function_output, false,
        "If true and squashing functions are defined via --squashing_function_type, "
        "then the squashing function is applied on the function output, "
        "otherwise it is applied on the constraints side");

DEFINE_bool(learn_function_use_max_weight, false, "");
DEFINE_double(learn_function_max_weight, 0.0, "");
DEFINE_bool(learn_function_use_min_weight, false, "");
DEFINE_double(learn_function_min_weight, 0.0, "");

using namespace Regularization;

LearnFunction::LearnFunction(const Function::ID& id_,
        const Function::TYPE predicate_type_,
        const Function::Arity arity_,
        const std::string& domain_,
        const Value balance_weight_) :
    Function(id_, predicate_type_, arity_, domain_),
    balance_weight(balance_weight_) {
    this->SetSquashingFunction();
}

LearnFunction::LearnFunction(const LearnFunction& function) :
        Function(function),
        balance_weight(function.balance_weight) {
    this->SetSquashingFunction();
}


LearnFunction::~LearnFunction() { }

/*
 *  Eval the function and applies a squashing function on it if requested.
 */
Value LearnFunction::Eval(const Pattern& pattern) const {
    const Value value = this->EvalInternal(pattern);
    return (squashing_function.Get() != NULL ? squashing_function->LIMIT(value) : value);
}

/**
 * Set the W_k weights vector
 */
void LearnFunction::Set(const Math::Vector<Value>& weights_) {
    CHECK_EQ(weights.Size(), weights_.Size());
    weights.Copy(weights_);
}

/**
 * Update the W_k weights vector
 */
void LearnFunction::Update(const Math::Vector<Value>& derivative)
{
    // w = w - \delta Error / \delta w
    weights.SubInPlace(derivative);
    if (FLAGS_learn_function_use_max_weight &&
        FLAGS_learn_function_use_min_weight) {
      weights.UpperLowerCap(FLAGS_learn_function_min_weight,
                            FLAGS_learn_function_max_weight);
    } else if (FLAGS_learn_function_use_max_weight) {
      weights.UpperCap(FLAGS_learn_function_max_weight);
    } else if (FLAGS_learn_function_use_min_weight) {
      weights.LowerCap(FLAGS_learn_function_min_weight);
    }
}

/**
 * Update the i-th (w_k)i weights
 */
void LearnFunction::Update(const Index i, const Value delta) {
    // w = w - \delta Error / \delta w
  if (delta != static_cast<Value>(0)) {
    float new_val = weights.Get(i) - delta;
    if (FLAGS_learn_function_use_max_weight &&
        new_val > FLAGS_learn_function_max_weight) {
      new_val = FLAGS_learn_function_max_weight;
    } else if (FLAGS_learn_function_use_min_weight &&
               new_val < FLAGS_learn_function_min_weight) {
      new_val = FLAGS_learn_function_min_weight;
    }
    weights.Set(i, new_val);
  }
}

Value LearnFunction::EvalLabeledError(
        const Dataset* dataset_,
        const Examples* examples,
        const LossFunction& labeled_loss_function) const {
    if (examples == NULL) {
        return 0.0;
    }

    const Examples::PerFunctionExamples* fexamples =
        examples->GetExamplesForPredicate(this->GetId());
    if (fexamples == NULL) {
      return 0.0;
    }

    Value sum = static_cast<Value>(0.0);
    for (unsigned int i = 0; i < fexamples->size(); ++i) {
        const Value y = (*fexamples)[i]->value;
        const Index index = dataset_->GetPatternIndexOrDie((*fexamples)[i]->pattern);
        const Value fx = this->Eval(*dataset_->Get(index));
        const Value err = (y != 0 ? balance_weight : 1.0) *
                labeled_loss_function.Eval(LossFunction::MAP_TO(fx), LossFunction::MAP_TO(y));
        sum += err;
    }

    return sum;
}

void LearnFunction::GetLabeledErrorGradient(const Dataset* dataset_,
        const Examples::PerFunctionExamples* fexamples,
        const LossFunction& labeled_loss_function,
        Math::Vector<Value>* derivative_labeled_part) const {
    CHECK_EQ(weights.Size(), derivative_labeled_part->Size());
    derivative_labeled_part->SetAll(0);
    for (unsigned int i = 0; i < fexamples->size(); ++i) {
        const Value y = (*fexamples)[i]->value;
        const Pattern* pattern = dataset_->GetByNameOrDie((*fexamples)[i]->pattern);
        const Value eval_derivative = (y != 0 ? balance_weight : 1.0) *
                labeled_loss_function.EvalDerivative(
                LossFunction::MAP_TO(this->Eval(*pattern)), LossFunction::MAP_TO(y));
        if (eval_derivative == 0.0) {
            continue;
        }

        this->AccumulateGradient(*pattern, eval_derivative, derivative_labeled_part);
    }
}

bool LearnFunction::AccumulateGradient(const Pattern& pattern,
        const Value weight,
        Math::Vector<Value>* derivative) const {
    const Value value = (squashing_function.Get() != NULL ?
            squashing_function->LIMIT_DERIVATIVE(this->Eval(pattern)) : 1.0f);
    return AccumulateGradientInternal(pattern, value * weight, derivative);
}

void LearnFunction::SetSquashingFunction() {
    squashing_function.Reset(NULL);
    if (FLAGS_apply_squashing_function_on_function_output) {
        squashing_function.Reset(SquashingFunction::BuildFromFlags(this->GetId()));
    }
}
