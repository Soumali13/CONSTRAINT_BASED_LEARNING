/*
 * File:   kernel_machine_function.h
 * Author: Tore
 *
 * Created on 24 gennaio 2011, 12.07
 */

#ifndef GIVEN_FUNCTION_H
#define GIVEN_FUNCTION_H

#include <map>
#include <iostream>
#include <string>

#include "classifier/functions/function.h"

namespace Regularization
{

class Pattern;
class Examples;
class Predicate;

class GivenFunction : public Function {
public:
    typedef Regularization::Value Value;
    typedef std::map<const std::string, Value> FunctionValueMap;

    /********************************
     * Constructors.
     ********************************/
    /**
     * Build a given function
     */
    GivenFunction(const Function::ID& id_, const Function::TYPE predicate_type_,
            const Function::Arity arity, const std::string& domain_,
            const Value default_value_, const Examples* examples_);

    /**
     * Copy constructor
     */
    GivenFunction(const GivenFunction& GivenFunction_);

    Function* Clone() const;

    /********************************
     * Destructors.
     ********************************/
    virtual ~GivenFunction()
    {
    }

    /**********************************************
     * Accessors and Mutators
     **********************************************/
    inline Value GetDefaultValue() const {
        return default_value;
    }

    inline Index Size() const {
        return functionValueMap.size();
    }

    /***********************************************************
     * Get values for map functions
     ***********************************************************/
    const FunctionValueMap& GetMap () const
    {
        return functionValueMap;
    }

    // Eval the function on the pattern of the test set
    // only kernel machine can evaluate a pattern not in training
    Value Eval(const Pattern& pattern) const;

protected:
    /************************************************************
     * I/O
     ************************************************************/
    virtual bool InternalLoadFromStream(std::istream& is);
    virtual bool InternalSaveToStream(std::ostream& os) const;
    virtual void InternalClear();

    // the vector of the value of the function
    FunctionValueMap functionValueMap;

    // default_value = 0 or 0.5 depending on the flags of the corresponding
    // predicate
    Value default_value;
}; // end GivenFunction

} // end namespace Regularization
#endif /* KERNEL_MACHINE_FUNCTION_H */
