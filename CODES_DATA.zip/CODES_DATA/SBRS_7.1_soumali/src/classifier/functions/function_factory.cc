/*
 * function_factory.cc
 *
 *  Created on: 10/feb/2010
 *      Author: leonardo
 */

#include "classifier/functions/function_factory.h"

#include "classifier/functions/learn_function/map_function.h"
#include "classifier/functions/given_function.h"
#include "classifier/functions/learn_function/kernel_machine/kernel_machine_function.h"
#include "classifier/functions/learn_function/kernel_machine/gram_matrix.h"
#include "classifier/functions/learn_function/kernel_machine/gram_matrix_manager.h"
#include "classifier/functions/learn_function/neural_networks/neural_network_function.h"
#include "data/dataset.h"
#include "data/predicate.h"
#include "train/options.h"


using namespace std;
using namespace Regularization;

// TODO(michi): find a better way to store this.
static GramMatrixManager gram_matrix_manager;

/* static */
FunctionFactory::FUNCTION_TYPE
FunctionFactory::FunctionTypeFromName(const std::string& name) {
    if (name == "KERNEL_MACHINE")
        return KERNEL_MACHINE;
    if (name == "NEURAL_NETWORK")
        return NEURAL_NETWORK;
    if (name == "MAP_FUNCTION")
        return MAP_FUNCTION;
    FAULT("Unknown name " << name);
    return INVALID;
}

/* static */
FunctionFactory::FUNCTION_TYPE
FunctionFactory::TypeFromFunction(const Function* function) {
    if (dynamic_cast<const KernelMachineFunction*>(function))
        return KERNEL_MACHINE;
    if (dynamic_cast<const NeuralNetworkFunction*>(function))
        return NEURAL_NETWORK;
    if (dynamic_cast<const MapFunction*>(function))
        return MAP_FUNCTION;
    FAULT("Unknown function");
    return INVALID;
}

/* static */
std::string
FunctionFactory::NameFromFunction(const Function* function) {
    const FUNCTION_TYPE type = TypeFromFunction(function);
    return NameFromFunctionType(type);
}

/* static */
string FunctionFactory::NameFromFunctionType(const FUNCTION_TYPE type) {
    if (type == KERNEL_MACHINE)
        return "KERNEL_MACHINE";
    if (type == NEURAL_NETWORK)
        return "NEURAL_NETWORK";
    if (type == MAP_FUNCTION)
        return "MAP_FUNCTION";
    FAULT("Unknown type " << type);
    return "";
}

/* static */
Function* FunctionFactory::LoadFromStream(std::istream& is, const TrainOptions& options) {
    string name;
    CHECK(static_cast<bool>(is >> name));

    const FUNCTION_TYPE type = FunctionTypeFromName(name);

    Function* function = NULL;
    if (type == KERNEL_MACHINE) {
        // Build an initial km function.
        KernelMachineFunction* km_function = new KernelMachineFunction(
                "" /* id */, Function::LEARN /* type */, 1 /* cardinality */, "" /* domain */,
                1.0 /* balance weight */, 0.5 /* bias */,
                NULL /* dataset */, NULL /* gram matrix */, NULL /* kernel */);
        // Populate it from the stored model.
        CHECK(km_function->LoadFromStream(is));
        // In case gram matrices are user (externally) provided, it is needed to link the km
        // function to the gram matrix.
        const GramMatrix* gram_matrix = (options.OnlineGramMatrix() ?
                NULL :
                gram_matrix_manager.Get(km_function->GetDomain(), options.GetGramMatricesFilesMap()));
        if (gram_matrix) {
            km_function->InitGramMatrixes(gram_matrix);
        }
        function = km_function;
    } else if (type == NEURAL_NETWORK) {
        function = new NeuralNetworkFunction();
        CHECK(function->LoadFromStream(is));
    } else if (type == MAP_FUNCTION) {
        function = new MapFunction("", Function::LEARN, 1, "", 0, NULL, NULL);
        CHECK(function->LoadFromStream(is));
    } else {
        FAULT("Unsupported type " << type);
    }
    return function;
}

/* static */
Function* FunctionFactory::LoadFromFile(
        const std::string& filename,
        const FunctionFactory::FUNCTION_TYPE type,
        const TrainOptions& options) {
    Function* function = NULL;
    if (type == KERNEL_MACHINE) {
        // Build an initial km function.
        KernelMachineFunction* km_function = new KernelMachineFunction(
                "" /* id */, Function::LEARN /* type */, 1 /* cardinality */, "" /* domain */,
                1.0 /* balance weight */, 0.5 /* bias */,
                NULL /* dataset */, NULL /* gram matrix */, NULL /* kernel */);

        // Populate it from the stored model.
        CHECK(km_function->LoadFromFile(filename));
        // In case gram matrices are user (externally) provided, it is needed to link the km
        // function to the gram matrix.
        const GramMatrix* gram_matrix = (options.OnlineGramMatrix() ?
                NULL :
                gram_matrix_manager.Get(km_function->GetDomain(), options.GetGramMatricesFilesMap()));
        if (gram_matrix) {
            km_function->InitGramMatrixes(gram_matrix);
        }
        function = km_function;
    } else if (type == NEURAL_NETWORK) {
        function = new NeuralNetworkFunction();
        CHECK(function->LoadFromFile(filename));
    } else if (type == MAP_FUNCTION) {
        function = new MapFunction("", Function::LEARN, 1, "", 0, NULL, NULL);
        CHECK(function->LoadFromFile(filename));
    } else {
        FAULT("Unsupported type " << type);
    }
    return function;
}

/* static */
bool FunctionFactory::SaveToStream(const Function* function, std::ostream& os) {
    if (dynamic_cast<const KernelMachineFunction*>(function))
        os << "KERNEL_MACHINE ";
    else if (dynamic_cast<const NeuralNetworkFunction*>(function))
        os << "NEURAL_NETWORK ";
    else if (dynamic_cast<const MapFunction*>(function))
        os << "MAP_FUNCTION ";
    else
        FAULT("Unknown function type");

    return function->SaveToStream(os);
}

/* static */
void FunctionFactory::Print(const Function* function) {
    FunctionFactory::SaveToStream(function, std::cout);
}

/*
 *  Builds a function starting from the predicates for training.
 */
Function* FunctionFactory::BuildFunction(
        const Predicate& predicate,
        const Examples* examples,
        const Dataset* dataset,
        const TrainOptions& options) {
    VMESSAGE(2, "Building function type " << predicate.GetPredicateType());
    if (predicate.GetPredicateType() == Function::MAP_GIVEN) {
      return BuildGivenFunction(predicate, examples);
    } else if (predicate.GetPredicateType() == Function::MAP_LEARN) {
        CHECK_NE_NULL(dataset);
        return BuildMapFunction(predicate, *dataset, examples);
    } else if (predicate.GetPredicateType() == Function::LEARN) {
      if (options.GetFunctionType(predicate.GetName()) == "KERNEL_MACHINE") {
        CHECK_NE_NULL(dataset);
        Kernel* kernel = KernelFactory::BuildKernel(predicate.GetName(), options);
        CHECK_NE_NULL(kernel);
        const GramMatrix* gram_matrix = (options.OnlineGramMatrix() ?
                NULL :
                gram_matrix_manager.Get(*dataset, *kernel, options.GetGramMatricesFilesMap()));
        return BuildKernelMachineFunction(
                predicate, kernel, *dataset, gram_matrix, options);
      } else if (options.GetFunctionType(predicate.GetName()) == "NEURAL_NETWORK") {
          // Create the KernelMachineFunction
          CHECK_NE_NULL(dataset);
          return BuildNeuralNetworkFunction(predicate, *dataset, options);
      } else {
        FAULT("Undefined function type " << options.GetFunctionType(predicate.GetName()) <<
              " for predicate " << predicate.GetName());
      }
    } else {
        FAULT("Undefined predicate type for predicate " << predicate.GetName());
    }

    return NULL;
}

/* static */
std::vector<Function*> FunctionFactory::BuildSharedFunctions(
        const std::vector<const Predicate*>& predicates,
        const Examples* examples,
        const Dataset* dataset,
        const TrainOptions& options) {
    for (unsigned int i = 0; i < predicates.size(); ++i) {
        CHECK_EQ_WITH_MESSAGE(options.GetFunctionType(predicates[i]->GetName()),
                string("NEURAL_NETWORK"), "Only neural networks support shared functions.");
    }

    const Index datasetSize = dataset->Size();
    CHECK_GT(datasetSize, static_cast<Regularization::Index>(0));

    Index input_size = 0;
    // First pass over the dataset to compute the input size.
    // This will determine the size of the NN in the input layer.
    // This assumes that the input has feature IDs in terms of positive
    // integer values.
    for (Index i = 0; i < datasetSize; ++i) {
        const Pattern* pattern = dataset->Get(i);
        Index max_feature_id = pattern->MaxFeatureId();
        if (max_feature_id >= input_size) {
            input_size = max_feature_id + 1;
        }
    }
    NeuralNetworkFunction::NN* net =
            NeuralNetworkFunction::CreateNeuralNetworkFromOptions<NeuralNetworkFunction::NN>(
            options, input_size, predicates.size(), predicates[0]->GetName());
    std::vector<Function*> functions(predicates.size());
    for (unsigned int i = 0; i < predicates.size(); ++i) {
        const Predicate& predicate = *predicates[i];
        functions[i] = new NeuralNetworkFunction(
                predicates[i]->GetName(),
                Function::LEARN,
                predicate.GetArity(),
                predicate.GetDomainString(),
                predicate.GetDefaultValue(),
                dataset,
                &options,
                net, i);
    }
    return functions;
}

Function* FunctionFactory::BuildNeuralNetworkFunction(
        const Predicate& predicate,
        const Dataset& dataset,
        const TrainOptions& options) {
    const Function::ID& id = predicate.GetName();
    return new NeuralNetworkFunction(id,
                                     Function::LEARN,
                                     predicate.GetArity(),
                                     predicate.GetDomainString(),
                                     predicate.GetDefaultValue(),
                                     &dataset,
                                     &options);
}

Function* FunctionFactory::BuildKernelMachineFunction(
        const Predicate& predicate,
        const Kernel* kernel,
        const Dataset& dataset,
        const GramMatrix* gramMatrix,
        const TrainOptions& options) {
    const Function::ID& id = predicate.GetName();
    return new KernelMachineFunction(id,
                                     Function::LEARN,
                                     predicate.GetArity(),
                                     predicate.GetDomainString(),
                                     options.GetBalanceWeight(id),
                                     predicate.GetDefaultValue(),
                                     &dataset, gramMatrix,
                                     kernel);
}

Function* FunctionFactory::BuildGivenFunction(
        const Predicate& predicate,
        const Examples* examples) {
    return new GivenFunction(predicate.GetName(),
                             Function::MAP_GIVEN,
                             predicate.GetArity(),
                             predicate.GetDomainString(),
                             predicate.GetDefaultValue(),
                             examples);
}

Function* FunctionFactory::BuildMapFunction(
        const Predicate& predicate,
        const Dataset& dataset,
        const Examples* examples) {
    // Create the function,
    MapFunction* mfunction =
            new MapFunction(predicate.GetName(),
                            Function::MAP_LEARN,
                            predicate.GetArity(),
                            predicate.GetDomainString(),
                            predicate.GetDefaultValue(),
                            &dataset,
                            examples);
    return mfunction;
}


