/*
 * dataset.cc
 *
 *  Created on: May 6, 2009
 *      Author: michi
 */

#include "data/dataset.h"

#include <fstream>
#include <map>
#include <string>

#include "data/pattern.h"
#include "data/predicates.h"
#include "data/examples.h"
#include "utils/stl_utils.h"
#include "utils/string_utils.h"


using namespace std;
using namespace Regularization;

Dataset::Dataset() {
}

Dataset::Dataset(const std::string& filename) {
    CHECK(this->LoadFromFile(filename));
}

/*
 * Copy constructor. Note: the dataset associated to the function can't
 * be copied, they must be rebuild
 */
Dataset::Dataset(const Dataset& dataset)
{
    this->name = dataset.GetName();
    for (Index i = 0; i < dataset.Size(); ++i)
    {
        const Pattern* pattern = dataset.Get(i);
        this->Add(pattern->Clone());
    }
}

Dataset::~Dataset()
{
    std::DeallocVectorOfPointers(&patternsVector);
    this->ClearSubDatasets();
    this->ClearPatterns();
}

/**
 * Clear the patterns of the dataset
 **/
void Dataset::ClearPatterns()
{
    patternsVector.clear();
    patternIndexMap.clear();
    for (DomainToPatternsVector::iterator it = domains_to_patterns_vector.begin(); it != domains_to_patterns_vector.end(); ++it)
    {
        for (PatternsVector::iterator jt = it->second.begin(); jt != it->second.end(); ++jt)
        {
            *jt = NULL;
        }

        it->second.clear();
    }

    domains_to_patterns_vector.clear();
    domain_to_pattern_index_map.clear();
}

/**
 * Clear the sub datasets of the dataset
 **/
void Dataset::ClearSubDatasets()
{
    std::DeallocMapOfPointers(&datasets_by_domain);
}

/*
 * Add a pattern to dataset
 */
bool Dataset::Add(const Pattern* pattern)
{
    bool ret = true;
    // add the pattern to the dataset
    ret &= this->AddToPatternsVector(pattern);
    // add a pattern to the dataset indexed by domain
    ret &= this->AddToDomainsPatternsVectorMap(pattern->GetDomain(), pattern);
    // update the map of the correspondence between name of the pattern and index
    ret &= this->AddToPatternIndexMap(pattern->GetName(), patternsVector.size() - 1);
    // update the map, indexed by the domain, of the correspondence between name
    // of the pattern and index
    ret &= this->AddToDomainsPatternIndexMap(
            pattern->GetDomain(), pattern->GetName(), domains_to_patterns_vector[pattern->GetDomain()].size() - 1);
    return ret;
}

bool Dataset::Update(
        const Index global_index, const Index domain_index, const Pattern* pattern) {
    if (this->patternsVector[global_index] != NULL) {
        delete this->patternsVector[global_index];
    }
    // add the pattern to the dataset
    this->patternsVector[global_index] = pattern;
    // add a pattern to the dataset indexed by domain
    this->domains_to_patterns_vector[pattern->GetDomain()][domain_index] = pattern;
    // update the map of the correspondence between name of the pattern and index
    this->AddToPatternIndexMap(pattern->GetName(), global_index);
    // update the map, indexed by the domain, of the correspondence between name
    // of the pattern and index
    this->domain_to_pattern_index_map[pattern->GetDomain()][pattern->GetName()] = domain_index;
    return true;
}

/**
 * Add a pattern to the dataset (vector)
 **/
bool Dataset::AddToPatternsVector(const Pattern* pattern)
{
    patternsVector.push_back(pattern);
    return true;
}

/**
 * Add a pattern to the dataset indexed by domain (map of vector)
 **/
bool Dataset::AddToDomainsPatternsVectorMap(const std::string& domain_name, const Pattern* pattern)
{
    domains_to_patterns_vector[domain_name].push_back(pattern);
    return true;
}

/*
 * Add the correspondence between pattern and index (map)
 **/
bool Dataset::AddToPatternIndexMap(const std::string& pattern_name, const Index index)
{
    // check if pattern is already inserted
    PatternIndexMap::const_iterator it = patternIndexMap.find(pattern_name);
    if (it != patternIndexMap.end())
        return false;

    patternIndexMap[pattern_name] = index;
    return true;
}

/*
 * Add the correspondence between pattern and index in the corresponding domain (map of map)
 */
bool Dataset::AddToDomainsPatternIndexMap(const std::string& pattern_domain, const std::string& pattern_name, const Index index)
{
    DomainToPatternIndexMap::iterator it = domain_to_pattern_index_map.find(pattern_domain);
    if (it != domain_to_pattern_index_map.end()) {
        // check if pattern is already inserted
        PatternIndexMap::iterator jt = it->second.find(pattern_name);
        if (jt != it->second.end())
            return false;
        it->second[pattern_name] = index;
    } else {
        domain_to_pattern_index_map[pattern_domain][pattern_name] = index;
    }

    return true;
}

Index Dataset::GetBiggestDomainSize() const
{
    Index dsize = 0;
    DomainToPatternsVector::const_iterator iter = domains_to_patterns_vector.begin();
    for (; iter != domains_to_patterns_vector.end(); ++iter) {
        if (iter->second.size() > dsize) {
            dsize = iter->second.size();
        }
    }
    return dsize;
}

namespace {
bool AllPredicatesGivenInDomain(
        const Predicates& predicates,
        const std::vector<Function::ID>& predicates_in_domain) {
    bool all_given = true;
    for (unsigned int i = 0; i < predicates_in_domain.size(); ++i) {
        if (predicates.Get(predicates_in_domain[i])->GetPredicateType() != Function::MAP_GIVEN) {
            all_given = false;
        }
    }
    return all_given;
}
}  // end namespace

void Dataset::BuildDomainDatasetForGivenFunctions(const Predicates& predicates, const Examples& examples) {
    VMESSAGE(0, "Building datasets for given functions");
    const Predicates::PerDomainPredicates& per_domain_predicates = predicates.GetPerDomainPredicates();

    // for each group of predicates/functions that share the same domains
    for (unsigned int l = 0; l < per_domain_predicates.size(); ++l) {
        const std::vector<Function::ID>& predicates_in_domain = per_domain_predicates[l].first;
        // skip domains for only given predicates.
        if (!AllPredicatesGivenInDomain(predicates, predicates_in_domain)) {
            continue;
        }

        const std::vector<std::string>& domains = per_domain_predicates[l].second;
        CHECK(!domains.empty());

        const std::string domain_name = StringUtils::VectorToString(domains, "_", "");
        Dataset* domain_dataset = new Dataset();
        domain_dataset->SetName(domain_name);

        for (unsigned int i = 0; i < predicates_in_domain.size(); ++i) {
            const Examples::PerFunctionExamples* fexamples =
                    examples.GetExamplesForPredicate(predicates_in_domain[i]);
            if (fexamples == NULL)  continue;

            for (unsigned int e = 0; e < fexamples->size(); ++e) {
                // The same example may be repeated for different given predicates,
                // we want to add it once.
                const Examples::PatternName& pattern_name = (*fexamples)[e]->pattern;
                if (domain_dataset->GetByName(pattern_name) == NULL) {
                    Pattern* newPattern = DatasetUtils::MakePattern(
                            pattern_name, domain_name, *this);
                    CHECK_NE_NULL(newPattern);
                    CHECK(domain_dataset->Add(newPattern));
                }
            }
        }

        CHECK_WITH_MESSAGE(this->AddDomainDataset(domain_name, domain_dataset),
                "Cannot add domain dataset");
    }
}

/*
 * Build the dataset for each function. The dataset contains the Nary Pattern
 */
void Dataset::BuildDomainDataset(const Predicates& predicates, const Examples& examples) {
    this->ClearSubDatasets();

	VMESSAGE(0, "Building datasets for functions");
    const Predicates::PerDomainPredicates& per_domain_predicates = predicates.GetPerDomainPredicates();

    // for each group of predicates/functions that share the same domains
    for (unsigned int l = 0; l < per_domain_predicates.size(); ++l) {
        const std::vector<std::string>& domains = per_domain_predicates[l].second;
        CHECK(!domains.empty());

        const std::vector<Function::ID>& predicates_in_domain = per_domain_predicates[l].first;
        // Skip domains for only given predicates.
        // THis is an optimization to avoid building all possible pattern combinations for
        // domains where only given patterns live.
        if (AllPredicatesGivenInDomain(predicates, predicates_in_domain)) {
            continue;
        }

        // get the group of predicates/functions that share the same domains
        const std::vector<std::string>& functionsNameVector = per_domain_predicates[l].first;
        CHECK(!functionsNameVector.empty());

        LogicCardinalityIndex cardinality = static_cast<LogicCardinalityIndex>(1);
        for (Index k = 0; k < domains.size(); ++k) {
            // compute the cardinality of the domain of the variable check if the
            // value of the cardinality is equal to the max representable number
            const Index domainCardinality = this->GetSizeForDomain(domains[k]);
            cardinality *= domainCardinality;
        }

        std::vector<unsigned int> patternsVector(domains.size());
        std::vector<unsigned int> domainsVector(domains.size());

        const std::string domain_name = StringUtils::VectorToString(domains, "_", "");

        // build the name of the new dataset
        VMESSAGE(3, "Building Dataset for domain " << domain_name << " cardinality " << static_cast<double>(cardinality));

        // create the new dataset with the name dataset_name
        Dataset* domain_dataset = new Dataset();
        domain_dataset->SetName(domain_name);

        // reserve space for the patternsVector of new dataset
        domain_dataset->patternsVector.resize(cardinality);
        domain_dataset->domains_to_patterns_vector[domain_name].resize(cardinality);

        // loop over the subset of the dataset (a single loop with the number of
        // iteration equal to the cardinality i.e. the product of the cardinality of
        // each variables of the predicate/function)
        for (LogicCardinalityIndex i = 0; i < cardinality; ++i) {
            std::string pattern_name;

            // loop over the vector of the domains
            for (Index j = 0; j < domains.size(); ++j) {
                // get the domain
                const std::string& domain = domains[j];

                // get the corresponding cardinality
                const Index domainCardinality = this->GetSizeForDomain(domain);
                CHECK_GT_WITH_MESSAGE(domainCardinality, static_cast<Index>(0),
                                      "Domain cardinality for domain " + domain + "is zero");
                if (j == 0) {
                    // initialization
                    // i % |Dv| (cardinality of the first domain)
                    // i / |Dv| (cardinality of the first domain)
                    patternsVector[j] = (i % domainCardinality);
                    domainsVector[j] = (i / domainCardinality);
                } else if (j < domains.size()) {
                    // (i % |Dv-1|) % |Dv| (cardinality of the current domain)
                    // (i % |Dv-1|) / |Dv| (cardinality of the current domain)
                    patternsVector[j] = (domainsVector[j - 1] % domainCardinality);
                    domainsVector[j] = (domainsVector[j - 1] / domainCardinality);
                }

                // get the pattern from the dataset
                const Pattern* pattern = this->GetByDomain(domain, patternsVector[j]);
                if (pattern == NULL) {
                    FAULT("Error: domain " << domain << " does not exist or pattern " <<
                          patternsVector[j] << " does not exist");
                }
                // Create the new name and domain name for the pattern
                pattern_name += pattern->GetName();

                if (j != domains.size() - 1) {
                    pattern_name += "_";
                }
            }

            // add the pattern to the dataset
            // make a pattern from the name and the domain of the patterns
            Pattern* newPattern = DatasetUtils::MakePattern(pattern_name, domain_name, *this);
            CHECK_NE_NULL(newPattern);
            CHECK(domain_dataset->Update(i, i, newPattern));
            if (i == cardinality - 1 || (i != 0 && i % 10000 == static_cast<Index>(0))) {
                VPRINT(2, "\rDataset " << domain_name << " " <<
                       l + 1 << "/" << per_domain_predicates.size() <<
                       " processed " << (100.0 * (i + 1)) / cardinality << "%");
            }
        }  // end loop on cardinality
        VPRINT(2, "\n");

        CHECK_WITH_MESSAGE(this->AddDomainDataset(domain_name, domain_dataset),
        		           "Cannot add domain dataset");
    }

    BuildDomainDatasetForGivenFunctions(predicates, examples);

    VMESSAGE(0, "Finished building datasets for functions");
}

/*
 * Add the association between the functions and the dataset.
 * All functions will share the same dataset as the work on the same domain.
 **/
bool Dataset::AddDomainDataset(const std::string& domain_name,
                               const Dataset* dataset) {
    VMESSAGE(0, "Adding dataset for domain " << domain_name);

    // check if the dataset is already inserted
    DatasetsByDomain::const_iterator it = datasets_by_domain.find(domain_name);
    if (it != datasets_by_domain.end()) {
        WARN("The dataset for domain " << domain_name << " is already inserted");
        return false;
    }

    datasets_by_domain[domain_name] = dataset;

    return true;
}


/**************************************************************
 * Checkers
 **************************************************************/

/**
 * Check if two datasets are equals
 **/
bool Dataset::Equals(const Dataset& dataset) const
{
    if (this->Size() != dataset.Size()) {
        return false;
    }

    for (Index i = 0; i < this->Size(); ++i)
    {
        const Pattern& pattern1 = *this->Get(i);
        const Pattern& pattern2 = *dataset.Get(i);

        if (!pattern1.Equals(&pattern2)) {
            return false;
        }
    }

    return true;
}

bool Dataset::EqualsIncludingDomainDatasets(const Dataset& dataset) const
{
    if (!this->Equals(dataset)) {
        return false;
    }

    if (this->datasets_by_domain.size() != dataset.datasets_by_domain.size()) {
        return false;
    }

    for (DatasetsByDomain::const_iterator iter = datasets_by_domain.begin();
         iter != datasets_by_domain.end(); ++iter) {
        const Dataset& dataset1 = *this->GetDomainDataset(iter->first);
        const Dataset* dataset2 = dataset.GetDomainDataset(iter->first);
        if (dataset2 == NULL || !dataset1.Equals(*dataset2)) {
            return false;
        }
    }

    return true;
}

/**
 * Check if a pattern is present
**/
bool Dataset::Has(const std::string& pattern_name) const
{
	if (patternIndexMap.find(pattern_name) == patternIndexMap.end())
		return false;

    return false;
}

/*
 * Get the vector of all distinct domains in the dataset.
 */
void Dataset::GetDomains(std::vector<std::string>* domains) {
    domains->clear();
    for (DomainToPatternsVector::const_iterator iter = domains_to_patterns_vector.begin();
         iter != domains_to_patterns_vector.end(); ++iter) {
        domains->push_back(iter->first);
    }
}
/****************************************************************
 * I/O
 ****************************************************************/

/**
 * Load from file (data)
 **/
bool Dataset::LoadFromFile(const std::string& dataFilename)
{
    std::ifstream ifs(dataFilename.c_str());

    if (!ifs.is_open()) {
        WARN("Could not open the file " << dataFilename);
        return false;
    }
    this->SetName(dataFilename);
    return this->LoadFromStream(ifs);
}

/**
 * Load from stream (data)
 **/
bool Dataset::LoadFromStream(std::istream& is)
{
    this->ClearPatterns();
    this->ClearSubDatasets();
    unsigned int lineCounter = 0;

    // counter of pattern added
    Index globalIndex = 0;
    // counter of pattern added for each domain
    std::map<std::string, Index> domainsIndex;
    // Map of domains size
    std::map<std::string, Index> domains_size;

    while (!is.eof()) {
        std::string line;
        getline(is, line);
        StringUtils::RemoveSpacesAtStartAndEndOfString(&line);
        lineCounter++;

        // skip empty lines.
        if (line.empty()) {
            continue;
        }

        // skip comment line
        if (StringUtils::StartsWith(line, '#', true)) {
            continue;
        }

        // search for invalid character, the second parameter are valid ASCII symbols
        if (!StringUtils::IsAlphaNumericOrInSet(line, "*-;:,. \r")) {
            WARN("Invalid character used, see the the file of the data at line " <<
                 lineCounter << " line: " << line);
            return false;
        }

        const int num_separators = StringUtils::CharCounter(line, ';');
        if (num_separators > 2 || num_separators < 1) {
          WARN("Invalid number of ';', see the file of the data at line " << lineCounter <<
               " line: " << line);
          return false;
        }

        std::vector<std::string> dataVector;
        // split the line into three parts: name, domain and feature
        StringUtils::SplitToVector(line, &dataVector, ';', false);
        // parser error; pattern is written in invalid form
        if (dataVector.size() < 2) {
          WARN("Wrong pattern, see the file of the data at line " << lineCounter << " line: " << line);
          return false;
        }

        // set the name of the pattern and the domain
        const std::string& pattern_name = dataVector[0];
        const std::string& domain_name = dataVector[1];

        // '_' will be used as a delimiter to build n-ary patterns, so it
        // should not be used in the unary pattern names.
        if (StringUtils::HasChar(pattern_name, '_')) {
            WARN("Invalid _ char used in pattern_name:" << pattern_name <<
                 " see the file of data at line " << lineCounter << " line: " << line);
            return false;
        }

        // check for invalid correct naming
        if (!StringUtils::IsAlphaNumericOrInSet(pattern_name, "-")) {
          WARN("Invalid character used " << pattern_name <<
               ", see the file of data at line " << lineCounter << " line: " << line);
          return false;
        }

        // check for invalid correct domain name
        if (!StringUtils::IsAlphaNumericOrInSet(domain_name, "-")) {
          WARN("Invalid character used " << domain_name <<
               ", see the file of data at line " << lineCounter << " line: " << line);
          return false;
        }

        // check if a pattern is already provided
        if (Has(pattern_name)) {
            WARN("Pattern " << pattern_name << " repeated, see the file of the data at line " <<
                 lineCounter << " line: " << line);
            return false;
        }

        // create new pattern
        SparsePattern* sp = new SparsePattern(pattern_name, domain_name);

        if (dataVector.size() > 2 && !dataVector[2].empty()) {  // There are features.
            std::deque<std::string> featureVec;
            // remove the commas from the features vector
            StringUtils::SplitToDeque(dataVector[2], &featureVec, ',', 0);

            // Keys must be sorted in the patterns to be able to perform dot products
            // and distances efficiently.
            std::map<SparsePattern::Key, Value> sorted_features;
            for (unsigned int i = 0; i < featureVec.size(); ++i) {
                SparsePattern::Key key;
                Value value = static_cast<Value>(0.0);
                // read the features and its values
                if (!StringUtils::ReadPair(featureVec[i], &key, &value, ':')) {
                    WARN("Invalid feature name: " << featureVec[i] <<
                         " see the file of the data at line " << lineCounter << " line: " << line);
                    return false;
                }
                sorted_features[key] = value;
            }
            for (std::map<SparsePattern::Key, Value>::const_iterator iter = sorted_features.begin();
                 iter != sorted_features.end(); ++iter) {
                // add the feature to the pattern in increasing order of key.
                sp->Add(iter->first, iter->second);
            }
        }

        // add the pattern to the map of vector indexed by domain
        CHECK_WITH_MESSAGE(this->Add(sp), "Can not add the pattern:" + sp->GetName());
        // increase counter of pattern added
        if (++globalIndex % 10000 == 0) {
            VPRINT(1, "\rPatterns imported " << lineCounter);
        }
    }

    if (globalIndex > 10000) {
        VPRINT(1, "\n");
    }
    return (this->Size() > 0);
}

bool Dataset::LoadFromStreamFast(std::istream& is) {
    this->ClearPatterns();
    this->ClearSubDatasets();

    std::string sizes;
    if (!(is >> sizes)) {
        WARN("Can not read dataset size.");
        return false;
    }

    Index dataset_size = 0;
    std::map<std::string, Index> domain_sizes;
    StringUtils::SplitToMapByType(sizes, &domain_sizes, ",", ":", static_cast<Index>(0), 0);
    for (std::map<std::string, Index>::const_iterator it = domain_sizes.begin();
         it != domain_sizes.end(); it++) {
      dataset_size += it->second;
      this->domains_to_patterns_vector[it->first].resize(it->second);
    }

    // reserve space for the patternsVector of loading dataset
    this->patternsVector.resize(dataset_size);

    std::map<std::string, Index> domains_size;
    for (Index i = 0; i < dataset_size; ++i) {
        // This currently works only with NarySparsePatterns as stored in the
        // per-function datasets.
        // TODO(michi): fix this.
        NarySparsePattern* sp = new NarySparsePattern();
        if (!sp->Load(is)) {
            WARN("Can not read pattern " << i << ", exiting.");
            return false;
        }

        if (!this->Update(i, domains_size[sp->GetDomain()]++, sp)) {
            WARN("Can not add pattern " << i << ", exiting.");
            return false;
        }
    }
    return true;
}

/**
 * Save to a stream
 **/
bool Dataset::SaveToStream(std::ostream& os) const {
    if (this->Size() <= 0)
        return false;

    Index count = 0;
    for (DomainToPatternsVector::const_iterator it = domains_to_patterns_vector.begin();
            it != domains_to_patterns_vector.end(); it++, count++) {
        os << it->first << ":" << it->second.size();
        if (count != domains_to_patterns_vector.size() - 1) {
            os << ",";
        } else {
            os << " ";
        }
    }

    bool ret = true;
    for (Index i = 0; i < this->Size(); ++i) {
        const Pattern* pattern = this->Get(i);
        ret &= pattern->Save(os);
    }
    return ret;
}

/**
 * Save to a file
 **/
bool Dataset::SaveToFile(const std::string& filename) const
{
    std::ofstream ofs(filename.c_str());

    if (!ofs.is_open())
    {
        WARN("Could not open the file " << filename);
        return false;
    }

    return this->SaveToStream(ofs);
}

/**
 * Print dataset info to stdout
 **/
void Dataset::Print() const
{
    std::cout << "----------------------------------------" << std::endl;
    std::cout << "Dataset Info:" << std::endl;
    std::cout << "Dataset name: " << name << std::endl;
    std::cout << "Dataset size: " << this->Size() << std::endl << std::endl;
    this->SaveToStream(std::cout);
    std::cout << std::endl;
    std::cout << "----------------------------------------" << std::endl;
}

/**
 * Merges a dataset into another one.
 **/
/* static */
bool DatasetUtils::AddTo(const Dataset& datasetToAdd, Dataset* dataset)
{
    bool ret = true;
    Index i;
    for (i=0; i<datasetToAdd.Size(); ++i)
    {
        const Pattern* pattern = datasetToAdd.Get(i)->Clone();
        // add the pattern to the dataset
        ret &= dataset->AddToPatternsVector(pattern);
        // add a pattern to the dataset indexed by domain
        ret &= dataset->AddToDomainsPatternsVectorMap(pattern->GetDomain(), pattern);
        // update the map of the correspondence between name of the pattern and index
        const Index patternsVectorSize = dataset->Size();
        ret &= dataset->AddToPatternIndexMap(pattern->GetName(), patternsVectorSize - 1);
        // update the map, indexed by the domain, of the correspondence between name
        // of the pattern and index
        const Index domainPatternsVectorSize = dataset->GetSizeForDomain(pattern->GetDomain());
        ret &= dataset->AddToDomainsPatternIndexMap(
                pattern->GetDomain(), pattern->GetName(), domainPatternsVectorSize - 1);
    }
    return ret;

}

/*
 * Merge one set of examples into another set.
 */
/* static */
bool DatasetUtils::AddTo(const Examples& examplesToAdd, Examples* examples)
{
    bool ret = true;
    Examples::Iterator iter(examplesToAdd);
    while (iter.HasNext()) {
        examples->Add(*(iter.GetNext()));
    }
    return ret;
}

/*
 * Make a Nary pattern.
 * static
 */
Pattern* DatasetUtils::MakePattern(const string& pattern_name,
                                   const string& pattern_domain,
                                   const Dataset& dataset) {
    // Initialize the new Nary pattern with its name and the domain
    NarySparsePattern* nsp = new NarySparsePattern(pattern_name, pattern_domain);
    // split the pattern
    vector<string> patternsNameVector;
    StringUtils::SplitToVector(pattern_name, &patternsNameVector, "_", 0);

    // make the Nary pattern through chaining of each pattern
    for (unsigned int i = 0; i < patternsNameVector.size(); ++i) {
        const Pattern* pattern = dataset.GetByName(patternsNameVector[i]);
        CHECK_NE_NULL_WITH_MESSAGE(
                pattern, "Error: the pattern " + patternsNameVector[i] + " does not exist");

        const SparsePattern* sparse_pattern =
                dynamic_cast<const SparsePattern*>(pattern);
        CHECK_NE_NULL(sparse_pattern);
        nsp->Add(sparse_pattern);
    }

    return nsp;
}

/*
 * Make a Nary pattern.
 */
Pattern* DatasetUtils::MakePattern(const vector<const Pattern*>& patterns) {
    string pattern_name = patterns[0]->GetName();
    string domain_name = patterns[0]->GetDomain();
    for (unsigned int i = 1; i < patterns.size(); ++i) {
        pattern_name += "_" + patterns[i]->GetName();
        domain_name += "_" + patterns[i]->GetDomain();
    }

    // Initialize the new Nary pattern with its name and the domain
    NarySparsePattern* nsp = new NarySparsePattern(pattern_name, domain_name);

    // make the Nary pattern through chaining of each pattern
    for (unsigned int i = 0; i < patterns.size(); ++i) {
        const SparsePattern* sparse_pattern = dynamic_cast<const SparsePattern*>(patterns[i]);
        CHECK_NE_NULL(sparse_pattern);
        nsp->Add(sparse_pattern);
    }

    return nsp;
}
