#include <cmath>
#include <sstream>
#include "data/pattern.h"
#include "utils/string_utils.h"


using namespace std;

namespace Regularization
{

/**
 * Copy
 **/
void Pattern::CopyInfo(const Pattern* pattern)
{
    name = pattern->GetName();
    domain = pattern->GetDomain();
}

void DensePattern::ToVector(vector<Value>* vec, int size) const {
  if (size > 0) {
    if (vec->size() != static_cast<unsigned int>(size)) {
      vec->resize(size);
    }
    fill(vec->begin(), vec->end(), 0);
  } else {
    if (vec->size() != this->GetSize()) {
      vec->resize(this->GetSize());
    }
  }

  for (Index i = 0; i < this->GetSize(); ++i)
    vec->push_back(this->Get(i));
}

void DensePattern::ToSparseVector(
    vector<pair<Index, Value> >* vec, const Index max_index) const {
  vec->resize(this->GetSize());

  for (Index i = 0; i < this->GetSize(); ++i) {
    if (max_index <= 0 || i <= max_index) {
        (*vec)[i] = make_pair(i, this->Get(i));
    } else {
        VMESSAGE(2, "Discarded feature index " << i
                 << " limit is " << max_index);
    }
  }
}

FeatureIndex DensePattern::MaxFeatureId() const {
  return this->GetSize();
}

Pattern* DensePattern::Clone() const
{
    DensePattern* pattern = new DensePattern();
    pattern->CopyInfo(this);

    for (Index i = 0; i < this->GetSize(); ++i)
      pattern->Add(this->Get(i));

    return pattern;
}

void SparsePattern::ToVector(vector<Value>* vec,
                             int size) const {
  if (size > 0 && vec->size() != static_cast<unsigned int>(size)) {
    vec->resize(size);
    fill(vec->begin(), vec->end(), 0);
  } else {
    vec->clear();
  }

  SparsePattern::Iterator iter(*this);
  while (iter.HasNext()) {
    const pair<FeatureIndex, Value>* el = iter.GetNext();

#if __LOW_MEMORY_USAGE__ > 0
    const int index = el->first;
    if (index >= 0) {
#else
    int index = -1;
    istringstream is(el->first);

    if ((is >> index) && index >= 0) {
#endif
      if (static_cast<unsigned int>(index) >= vec->size()) {
        vec->resize(index + 1);
      }
      (*vec)[index] = el->second;
    } else {
      FAULT("Can not convert id " << el->first << " to non-negative integer value");
    }
  }
}

void SparsePattern::ToSparseVector(
    vector<pair<Index, Value> >* vec, const Index max_index) const {
  vec->resize(this->GetSize());

  int i = 0;
  SparsePattern::Iterator iter(*this);
  while (iter.HasNext()) {
    const pair<FeatureIndex, Value>* el = iter.GetNext();

#if __LOW_MEMORY_USAGE__ > 0
    const int index = el->first;
    if (index >= 0) {
#else
    int index = -1;
    istringstream is(el->first);

    if ((is >> index) && index >= 0) {
#endif
        if (max_index <= 0 || index <= static_cast<int>(max_index)) {
            (*vec)[i++] = make_pair(index, el->second);
        } else {
            VMESSAGE(2, "Discarded feature index " << index
                    << " limit is " << max_index);
        }
    } else {
        FAULT("Can not convert id " << el->first << " to non-negative integer value");
    }
  }
}

FeatureIndex SparsePattern::MaxFeatureId() const {
  FeatureIndex ret = 0;
  SparsePattern::Iterator iter(*this);
  while (iter.HasNext()) {
    const pair<FeatureIndex, Value>* el = iter.GetNext();

#if __LOW_MEMORY_USAGE__ > 0
    const int index = el->first;
    if (index >= 0) {
#else
    int index = -1;
    istringstream is(el->first);

    if ((is >> index) && index >= 0) {
#endif
      if (index > ret)
        ret = index;
    } else {
      FAULT("Can not convert id " << el->first << " to non-negative integer value");
    }
  }
  return ret;
}

Pattern* SparsePattern::Clone() const
{
    SparsePattern* pattern = new SparsePattern();
    pattern->CopyInfo(this);

    SparsePattern::Iterator iter(*this);
    while (iter.HasNext())
    {
        const pair<FeatureIndex, Value>* el = iter.GetNext();
        pattern->Add(el->first, el->second);
    }

    return pattern;
}

Pattern* NaryDensePattern::Clone() const {
  NaryDensePattern* pattern = new NaryDensePattern();
  pattern->CopyInfo(this);

  for (Index i = 0; i < this->GetSize(); ++i)
    pattern->Add(this->Get(i));

  return pattern;
}

void NaryDensePattern::ToVector(vector<Value>* vec,
                                int size) const {
  if (size > 0) {
    if (vec->size() != this->GetSize() * static_cast<unsigned int>(size)) {
      vec->resize(this->GetSize() * size);
    }
    fill(vec->begin(), vec->end(), 0);
  } else {
    int sum = 0;
    for (Index i = 0; i < this->GetSize(); ++i) {
      const Pattern* pattern = this->Get(i);
      sum += pattern->GetSize();
    }
    vec->resize(sum);
  }

  int index = 0;
  for (Index i = 0; i < this->GetSize(); ++i) {
    const DensePattern* pattern = this->Get(i);
    for (Index j = 0; j < pattern->GetSize(); ++j) {
      (*vec)[index++] = pattern->Get(j);
    }
  }
}

void NaryDensePattern::ToSparseVector(
    vector<pair<Index, Value> >* vec, const Index max_index) const {
  int sum = 0;
  for (Index i = 0; i < this->GetSize(); ++i) {
    const Pattern* pattern = this->Get(i);
    sum += pattern->GetSize();
  }
  vec->resize(sum);

  int index = 0;
  for (Index i = 0; i < this->GetSize(); ++i) {
    const DensePattern* pattern = this->Get(i);
    for (Index j = 0; j < pattern->GetSize(); ++j) {
        if (max_index <= 0 || index + j <= max_index) {
            (*vec)[index + j] = make_pair(index + j, pattern->Get(j));
        } else {
            VMESSAGE(2, "Discarded feature index " << index + j
                    << " limit is " << max_index);
        }
    }
    index += pattern->GetSize();
  }
}

FeatureIndex NaryDensePattern::MaxFeatureId() const {
  FeatureIndex ret = 0;
  for (Index i = 0; i < this->GetSize(); ++i) {
    const DensePattern* pattern = this->Get(i);
    ret += pattern->MaxFeatureId();
  }
  return ret;
}

Pattern* NarySparsePattern::Clone() const {
  NarySparsePattern* pattern = new NarySparsePattern();
  pattern->CopyInfo(this);

  for (Index i = 0; i < this->GetSize(); ++i)
    pattern->Add(this->Get(i));

  return pattern;
}

void NarySparsePattern::ToVector(vector<Value>* vec, int size) const {
  CHECK_GT(size, 0);
  unsigned int usize = size;  // to avoid compiler warnings
  if (vec->size() != this->GetSize() * usize) {
    vec->resize(this->GetSize() * usize);
  }
  fill(vec->begin(), vec->end(), 0);

  for (Index i = 0; i < this->GetSize(); ++i) {
    const SparsePattern* pattern = this->Get(i);
    SparsePattern::Iterator iter(*pattern);
    while (iter.HasNext()) {
      const pair<FeatureIndex, Value>* el = iter.GetNext();

#if __LOW_MEMORY_USAGE__ > 0
      const int index = el->first;
      if (index >= 0) {
#else
      int index = -1;
      istringstream is(el->first);

      if ((is >> index) && index >= 0) {
#endif
        unsigned int uindex = index;  // to avoid compiler warnings
        if (i * usize + uindex >= vec->size()) {
          vec->resize(i * usize + uindex + 1);
        }
        (*vec)[i * usize + uindex] = el->second;
      } else {
        FAULT("Can not convert key: " << el->first <<
              " to integer value for pattern:" << this->ToString());
      }
    }
  }
}

void NarySparsePattern::ToSparseVector(
    std::vector<std::pair<Index, Value> >* vec, const Index max_index) const {
  int sum = 0;
  for (Index i = 0; i < this->GetSize(); ++i) {
    const Pattern* pattern = this->Get(i);
    sum += pattern->GetSize();
  }
  vec->resize(sum);

  int count = 0;
  for (Index i = 0; i < this->GetSize(); ++i) {
    const SparsePattern* pattern = this->Get(i);
    SparsePattern::Iterator iter(*pattern);
    while (iter.HasNext()) {
      const pair<FeatureIndex, Value>* el = iter.GetNext();

#if __LOW_MEMORY_USAGE__ > 0
      const int index = el->first;
      if (index >= 0) {
#else
      int index = -1;
      istringstream is(el->first);

      if ((is >> index) && index >= 0) {
#endif
          if (max_index <= 0 || index <= static_cast<int>(max_index)) {
              (*vec)[count++] = make_pair(index, el->second);
          } else {
              VMESSAGE(2, "Discarded feature index " << index
                      << " limit is " << max_index);
          }
      } else {
        FAULT("Can not convert key: " << el->first <<
              " to integer value for pattern:" << this->ToString());
      }
    }
  }
}

FeatureIndex NarySparsePattern::MaxFeatureId() const {
  CHECK_EQ(this->GetSize(), static_cast<Index>(1));  // NEED TO BE FIXED FOR BINARY
  FeatureIndex ret = 0;
  for (Index i = 0; i < this->GetSize(); ++i) {
    const SparsePattern* pattern = this->Get(i);
    ret += pattern->MaxFeatureId();
  }

  return ret;
}


void DensePattern::Clear()
{
    data.clear();
}

void SparsePattern::Clear()
{
    data.clear();
}

void NaryDensePattern::Clear()
{
    for (PatternsContainer::iterator jt = patternsContainer.begin ();
            jt != patternsContainer.end (); ++jt)
    {
        *jt = NULL;
    }

    patternsContainer.clear();
}

void NarySparsePattern::Clear()
{
    for (PatternsContainer::iterator jt = patternsContainer.begin ();
            jt != patternsContainer.end (); ++jt)
    {
        *jt = NULL;
    }

    patternsContainer.clear();
}

/************************************************************
 * Other functions.
 ************************************************************/

/**
 * Check if two patterns are equal
 **/
bool DensePattern::Equals(const Pattern* p) const
{
    const DensePattern* dp = dynamic_cast<const DensePattern*>(p);
    CHECK_NE_NULL_WITH_MESSAGE(dp, "Can not compare with a non DensePattern");
    const Index size = this->GetSize();
    bool equals = (this->GetName() == dp->GetName() && size == dp->GetSize());

    if (equals)
    {
        Index i;

        for (i = 0; i < size; ++i)
        {
            if (this->Get(i) != dp->Get(i))
            {
                equals = false;
                break;
            }
        }
    }

    return equals;
}

bool SparsePattern::Equals(const Pattern* p) const
{
    const SparsePattern* sp = dynamic_cast<const SparsePattern*>(p);
    CHECK_NE_NULL_WITH_MESSAGE(sp, "Can not compare with a non SparsePattern");
    bool equals = (this->GetName() == sp->GetName() && this->GetSize() == sp->GetSize());

    if (equals)
    {
        SparsePattern::Iterator iter(*sp);
        SparsePattern::Iterator iter1(*this);
        while (iter.HasNext() && iter1.HasNext())
        {
            FeatureIndex key;
            Value val;
            iter.GetNext(&key, &val);
            FeatureIndex key1;
            Value val1;
            iter1.GetNext(&key1, &val1);

            if (key != key1 || val != val1) {
                equals = false;
                break;
            }
        }
    }

    return equals;
}

bool NaryDensePattern::Equals(const Pattern* p) const
{
    const NaryDensePattern* ndp = dynamic_cast<const NaryDensePattern*>(p);
    CHECK_NE_NULL_WITH_MESSAGE(ndp, "Can not compare with a non DensePattern");
    const Index size = this->GetSize();
    bool equals = (this->GetName() == ndp->GetName() && size == ndp->GetSize());

    if (equals)
    {
        Index i, j;

        for (i = 0; i < size; ++i)
        {
            const DensePattern* dp1 = static_cast<const DensePattern*>(ndp->Get(i));
            const DensePattern* dp2 = static_cast<const DensePattern*>(this->Get(i));
            const Index dp1Size = dp1->GetSize();
            CHECK_EQ(dp1Size, dp2->GetSize());

            for (j = 0; i < dp1Size; ++i)
            {
                if (dp2->Get(j) != dp1->Get(j))
                {
                    equals = false;
                    break;
                }
            }
        }
    }
    return equals;
}

bool NarySparsePattern::Equals(const Pattern* p) const
{
    const NarySparsePattern* nsp = dynamic_cast<const NarySparsePattern*>(p);
    CHECK_NE_NULL_WITH_MESSAGE(nsp, "Can not compare with a non NarySparsePattern");
    const Index size = this->GetSize();
    bool equals = (this->GetName() == nsp->GetName() && size == nsp->GetSize());

    if (equals) {
        for (Index i = 0; i < size; ++i) {
            if (!nsp->Get(i)->Equals(this->Get(i))) {
                equals = false;
                break;
            }
        }
    }

    return equals;
}

/**
 * Euclidean Distance Implementation
 **/
Value DensePattern::EuclideanDist(const Pattern* p) const
{
    const DensePattern* dp = dynamic_cast<const DensePattern*>(p);
    CHECK_NE_NULL_WITH_MESSAGE(dp, "Can not compare with a non DensePattern");
    const Index size = this->GetSize();
    CHECK_EQ(size, dp->GetSize());
    Value sum = static_cast<Value > (0.0);

    for (Index i = 0; i < size; ++i)
    {
        Value diff = this->Get(i) - dp->Get(i);
        sum += diff * diff;
    }

    return static_cast<Value > (sqrt(sum));
}

Value SparsePattern::EuclideanDist(const Pattern* p) const
{
    const SparsePattern* sp = dynamic_cast<const SparsePattern*>(p);
    CHECK_NE_NULL_WITH_MESSAGE(sp, "Can not compare with a non SparsePattern");
    Value sum = static_cast<Value > (0.0);
    SparsePattern::Iterator iter(*sp);
    SparsePattern::Iterator iter1(*this);

    FeatureIndex key = FeatureIndex();
    Value val = 0;
    FeatureIndex key1 = FeatureIndex();
    Value val1 = 0;

    bool done  = !iter.HasNext();
    bool done1 = !iter1.HasNext();

    if (!done)
      iter.GetNext(&key, &val);
    if (!done1)
      iter1.GetNext(&key1, &val1);

    while (!done || !done1) {
      if (!done && !done1 && key == key1) {
        const Value diff = val - val1;
        sum += diff * diff;
        if (iter.HasNext())   iter.GetNext(&key, &val);
        else done = true;
        if (iter1.HasNext())  iter1.GetNext(&key1, &val1);
        else done1 = true;
      } else if (done1 || (!done && key < key1)) {
        sum += val * val;
        if (iter.HasNext())  iter.GetNext(&key, &val);
        else done = true;
      } else if (done || (!done1 && key1 < key)) {
        sum += val1 * val1;
        if (iter1.HasNext()) iter1.GetNext(&key1, &val1);
        else done1 = true;
      }
    }

    return static_cast<Value> (sqrt(sum));}

Value NaryDensePattern::EuclideanDist(const Pattern* p) const
{
    const NaryDensePattern* ndp = dynamic_cast<const NaryDensePattern*>(p);
    CHECK_NE_NULL_WITH_MESSAGE(ndp, "Can not compare with a non DensePattern");
    const Index size = this->GetSize();
    CHECK_EQ(size, ndp->GetSize());
    Value sum = static_cast<Value > (0.0);

    for (Index i = 0; i < size; ++i)
    {
        const DensePattern* dp1 = static_cast<const DensePattern*>(ndp->Get(i));
        const DensePattern* dp2 = static_cast<const DensePattern*>(this->Get(i));
        const Value dist = dp1->EuclideanDist(dp2);
        sum += dist * dist;
    }

    return static_cast<Value > (sqrt(sum));
}

Value NarySparsePattern::EuclideanDist(const Pattern* p) const
{
    const NarySparsePattern* nsp = dynamic_cast<const NarySparsePattern*>(p);
    CHECK_NE_NULL_WITH_MESSAGE(nsp, "Can not compare with a non NarySparsePattern");
    const Index size = this->GetSize();
    CHECK_EQ(size, nsp->GetSize());
    Value sum = static_cast<Value> (0.0);
    // for each pair of patterns
    for (Index i = 0; i < size; ++i)
    {
        const SparsePattern* sp1 = static_cast<const SparsePattern*>(nsp->Get(i));
        const SparsePattern* sp2 = static_cast<const SparsePattern*>(this->Get(i));
        const Value dist = sp1->EuclideanDist(sp2);
        sum += dist * dist;
    }

    return static_cast<Value > (sqrt(sum));
}

/**
 * Dot Product Implementation
 **/
Value DensePattern::DotProduct(const Pattern* p) const
{
    const DensePattern* dp = dynamic_cast<const DensePattern*>(p);
    CHECK_NE_NULL_WITH_MESSAGE(dp, "Can not compare with a non DensePattern");
    const Index size = this->GetSize();
    CHECK_EQ(size, dp->GetSize());
    Value sum = static_cast<Value > (0.0);

    for (Index i = 0; i < size; ++i)
        sum += this->Get(i) * dp->Get(i);

    return sum;
}

Value SparsePattern::DotProduct(const Pattern* p) const
{
    const SparsePattern* sp = dynamic_cast<const SparsePattern*>(p);
    CHECK_NE_NULL_WITH_MESSAGE(sp, "Can not compare with a non SparsePattern");
    Value sum = static_cast<Value>(0.0);
    SparsePattern::Iterator iter(*sp);
    SparsePattern::Iterator iter1(*this);

    FeatureIndex key = FeatureIndex();
    Value val = 0;
    FeatureIndex key1 = FeatureIndex();
    Value val1 = 0;
    if (!iter.HasNext() || !iter1.HasNext())
        return sum;

    iter.GetNext(&key, &val);
    iter1.GetNext(&key1, &val1);

    while (true) {
      if (key == key1) {
        sum += val * val1;
        if (!iter.HasNext() || !iter1.HasNext()) break;
        iter.GetNext(&key, &val);
        iter1.GetNext(&key1, &val1);
      } else if (key < key1) {
        if (!iter.HasNext()) break;
        iter.GetNext(&key, &val);
      } else {
        if (!iter1.HasNext()) break;
        iter1.GetNext(&key1, &val1);
      }
    }

    return sum;
}

Value NaryDensePattern::DotProduct(const Pattern* p) const
{
    const NaryDensePattern* ndp = dynamic_cast<const NaryDensePattern*>(p);
    CHECK_NE_NULL_WITH_MESSAGE(ndp, "Can not compare with a non DensePattern");
    const Index size = this->GetSize();
    CHECK_EQ(size, ndp->GetSize());
    Value sum = static_cast<Value > (0.0);
    Index i, j;

    for (i = 0; i < size; ++i)
    {
        const DensePattern* dp1 = static_cast<const DensePattern*>(ndp->Get(i));
        const DensePattern* dp2 = static_cast<const DensePattern*>(this->Get(i));
        const Index dp1Size = dp1->GetSize();
        CHECK_EQ(dp1Size, dp2->GetSize());

        for (j = 0; i < dp1Size; ++j)
            sum += dp2->Get(j) * dp1->Get(j);
    }

    return sum;
}

Value NarySparsePattern::DotProduct(const Pattern* p) const
{
    const NarySparsePattern* nsp = dynamic_cast<const NarySparsePattern*>(p);
    CHECK_NE_NULL_WITH_MESSAGE(nsp, "Can not compare with a non NarySparsePattern");
    const Index size = this->GetSize();
    CHECK_EQ(size, nsp->GetSize());
    Value sum = static_cast<Value > (0.0);

    for (Index i = 0; i < size; ++i)
    {
        const SparsePattern* sp1 = static_cast<const SparsePattern*>(nsp->Get(i));
        const SparsePattern* sp2 = static_cast<const SparsePattern*>(this->Get(i));
        sum += sp1->DotProduct(sp2);
    }

    return sum;
}

/**
 * Module Implementation
 **/
Value DensePattern::Mod() const
{
    Value sum = static_cast<Value > (0.0);
    Index i;

    for (i = 0; i < this->GetSize(); ++i)
        sum += this->Get(i) * this->Get(i);

    return static_cast<Value > (sqrt(sum));
}

Value SparsePattern::Mod() const
{
    Value sum = static_cast<Value > (0.0);
    SparsePattern::Iterator iter(*this);

    while (iter.HasNext())
    {
        FeatureIndex key;
        Value val;
        iter.GetNext(&key, &val);
        sum += (val) * (val);
    }

    return static_cast<Value > (sqrt(sum));
}

Value NaryDensePattern::Mod() const
{
    Value sum = static_cast<Value > (0.0);
    Index i, j;

    for (i = 0; i < this->GetSize(); ++i)
    {
        const DensePattern* dp = dynamic_cast<const DensePattern*>(this->Get(i));

        for (j = 0; j < dp->GetSize(); ++j)
            sum += dp->Get(j) * dp->Get(j);
    }

    return static_cast<Value > (sqrt(sum));
}

Value NarySparsePattern::Mod() const
{
    Value sum = static_cast<Value > (0.0);
    Index i;

    for (i = 0; i < this->GetSize(); ++i)
    {
        SparsePattern::Iterator iter(*static_cast<const SparsePattern*>(this->Get(i)));

        while (iter.HasNext())
        {
            FeatureIndex key;
            Value val;
            iter.GetNext(&key, &val);
            sum += (val) * (val);
        }
    }

    return static_cast<Value > (sqrt(sum));
}

/**
 * Cosine Similarity Implementation
 **/
Value DensePattern::CosineSimilarity(const Pattern* p) const
{
    Value dot = this->DotProduct(p);
    Value den = this->Mod() * p->Mod();
    return dot / den;
}

Value SparsePattern::CosineSimilarity(const Pattern* p) const
{
    Value dot = this->DotProduct(p);
    Value den = this->Mod() * p->Mod();
    return dot / den;
}

Value NaryDensePattern::CosineSimilarity(const Pattern* p) const
{
    Value dot = this->DotProduct(p);
    Value den = this->Mod() * p->Mod();
    return dot / den;
}

Value NarySparsePattern::CosineSimilarity(const Pattern* p) const
{
    Value dot = this->DotProduct(p);
    Value den = this->Mod() * p->Mod();
    return dot / den;
}

/****************************************************************
 * I/O
 ****************************************************************/

/**
 * Save in a ostream
 **/
bool Pattern::SaveInfo(ostream& os) const
{
    os << this->GetName() << " " << this->GetDomain() << " ";
    return true;
}

bool Pattern::LoadInfo(istream& is) {
    string name_;
    string domain_;
    if (!(is >> name_ >> domain_)) {
      return false;
    }
    this->SetName(name_);
    this->SetDomain(domain_);
    return true;
}

bool DensePattern::Save(ostream& os) const
{
    bool ret = this->SaveInfo(os);

    os << " " << this->GetSize();
    for (Index j = 0; j < this->GetSize(); ++j)
        os << " " << this->Get(j);
    os << " ";
    return ret;
}

bool DensePattern::Load(istream& is)
{
    bool ret = this->LoadInfo(is);

    Index size = 0;
    if (!(is >> size)) {
        return false;
    }
    data.reserve(size);
    Value val = 0;
    for (Index j = 0; j < size; ++j) {
        if (!(is >> val)) {
            return false;
        }
        this->Add(val);
    }
    return ret;
}

bool SparsePattern::Save(ostream& os) const
{
    bool ret = this->SaveInfo(os);
    os << this->GetSize() << " ";

    SparsePattern::Iterator iter(*this);
    while (iter.HasNext())
    {
        FeatureIndex key;
        Value val;
        iter.GetNext(&key, &val);
        os << key << ':' << val << " ";
    }
    return ret;
}

bool SparsePattern::Load(istream& is)
{
    bool ret = this->LoadInfo(is);

    Index size = 0;
    if (!(is >> size)) {
        return false;
    }

    // FeatureIndexs must be sorted in the patterns to be able to perform dot products
    // and distances efficiently.
    std::map<FeatureIndex, Value> sorted_features;

    FeatureIndex key;
    Value val = 0;
    for (Index j = 0; j < size; ++j) {
        string token;
        if (!(is >> token) || !StringUtils::ReadPair(token, &key, &val, ":")) {
            return false;
        }
        sorted_features[key] = val;
    }

    for (std::map<FeatureIndex, Value>::const_iterator iter = sorted_features.begin();
         iter != sorted_features.end(); ++iter) {
        // add the feature to the pattern in increasing order of key.
        this->Add(iter->first, iter->second);
    }
    return ret;
}

bool NaryDensePattern::Save(ostream& os) const
{
    bool ret = this->SaveInfo(os);
    os << this->GetSize() << " ";

    for (Index i = 0; i < this->GetSize(); ++i)
    {
        const DensePattern* dp = static_cast<const DensePattern*>(this->Get(i));
        ret &= dp->Save(os);
    }
    return ret;
}

bool NaryDensePattern::Load(istream& is)
{
    bool ret = this->LoadInfo(is);

    Index size = 0;
    if (!(is >> size)) {
        return false;
    }
    for (Index j = 0; j < size; ++j) {
        DensePattern* dp = new DensePattern;
        ret &= dp->Load(is);
        this->Add(dp);
    }
    return ret;
}

bool NarySparsePattern::Save(ostream& os) const
{
    bool ret = this->SaveInfo(os);
    os << this->GetSize() << " ";

    for (Index i = 0; i < this->GetSize(); ++i)
    {
        const SparsePattern* dp = static_cast<const SparsePattern*>(this->Get(i));
        ret &= dp->Save(os);
    }
    return ret;
}

bool NarySparsePattern::Load(istream& is)
{
    bool ret = this->LoadInfo(is);

    Index size = 0;
    if (!(is >> size)) {
        return false;
    }
    for (Index j = 0; j < size; ++j) {
        SparsePattern* sp = new SparsePattern;
        ret &= sp->Load(is);
        this->Add(sp);
    }
    return ret;
}
/**
 * To string
 **/
string Pattern::ToString() const
{
    ostringstream os;
    this->Save(os);
    return os.str();
}

/**
 * Print to stdout
 **/
void Pattern::Print() const
{
    this->Save(cout);
}

}
