/*
 * uint128_iostream_support.cc
 *
 *  Created on: Mar 1, 2017
 *      Author: michi
 */
#include "data/uint128_std_support.h"

#if __USE_BOOST_INT128__ > 0
std::ostream& operator<<(std::ostream& os, boost::multiprecision::uint128_t num) {
    unsigned __int128 tmp = num < 0 ? -num : num;
    char buffer[128];
    char* d = std::end(buffer);
    do {
        --d;
        *d = "0123456789"[tmp % 10];
        tmp /= 10;
    } while (tmp != 0);

    if (num < 0) {
        --d;
        *d = '-';
    }
    const int len = std::end(buffer) - d;
    if (os.rdbuf()->sputn(d, len) != len) {
        os.setstate(std::ios_base::badbit);
    }
    return os;
}

#elif __USE_GCC_INT128__ > 0

std::ostream& operator<<(std::ostream& os, unsigned __int128 num) {
    unsigned __int128 tmp = num;
    char buffer[128];
    char* d = std::end(buffer);
    do {
        --d;
        *d = "0123456789"[tmp % 10];
        tmp /= 10;
    } while (tmp != 0);

    const int len = std::end(buffer) - d;
    if (os.rdbuf()->sputn(d, len) != len) {
        os.setstate(std::ios_base::badbit);
    }
    return os;
}

std::ostream& operator<<(std::ostream& os, __int128 num) {
    __int128 tmp = num < 0 ? -num : num;
    char buffer[128];
    char* d = std::end(buffer);
    do {
        --d;
        *d = "0123456789"[tmp % 10];
        tmp /= 10;
    } while (tmp != 0);

    if (num < 0) {
        --d;
        *d = '-';
    }
    const int len = std::end(buffer) - d;
    if (os.rdbuf()->sputn(d, len) != len) {
        os.setstate(std::ios_base::badbit);
    }
    return os;
}
#endif
