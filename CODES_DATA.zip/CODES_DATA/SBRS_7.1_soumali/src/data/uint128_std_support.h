/*
 * uint128_iostream_support.h
 *
 *  Created on: Feb 28, 2017
 *      Author: michi
 */

#ifndef UINT128_IOSTREAM_SUPPORT_H_
#define UINT128_IOSTREAM_SUPPORT_H_

#include <iostream>

#if __USE_BOOST_INT128__ > 0
std::ostream& operator<<(std::ostream& os, boost::multiprecision::uint128_t num);

#elif __USE_GCC_INT128__ > 0
#include <limits>
namespace std {
    template<> class numeric_limits<unsigned __int128> {
    public:
        inline static unsigned __int128 max() {return static_cast<unsigned __int128>(1) << 127; };
    };

    template<> class numeric_limits<__int128> {
    public:
       inline static __int128 max() {return static_cast<__int128>(1) << 126; };
    };
}  // end std

std::ostream& operator<<(std::ostream& os, unsigned __int128 num);
std::ostream& operator<<(std::ostream& os, __int128 num);
#endif
#endif  /* UINT128_IOSTREAM_SUPPORT_H_ */
