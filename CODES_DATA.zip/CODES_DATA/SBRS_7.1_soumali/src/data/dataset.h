/*
 * File:  dataset.h
 * Author: Tore
 *
 * Created on 15 novembre 2010, 10.07
 */

#ifndef DATASET_H
#define DATASET_H

#include <map>
#if __NO_STD_C11__ > 0
#include <tr1/unordered_map>
#else
#include <unordered_map>
#endif
#include "data/pattern.h"
#include "utils/general.h"


namespace Regularization {
class Pattern;
class Predicates;
class Examples;

/**
 * Collects a set of patterns.
 **/
class Dataset
{
public:
    /********************************
     * Typedefs.
     ********************************/
    /**
         Table pattern2index.
     **/
#if __NO_STD_C11__ > 0
    typedef std::tr1::unordered_map<std::string, Index> PatternIndexMap;
#else
    typedef std::unordered_map<std::string, Index> PatternIndexMap;
#endif
    /**
     * Table domain_name2PatternIndexMap
     **/
    typedef std::map<std::string, PatternIndexMap> DomainToPatternIndexMap;

    /********************************
     * Constructors.
     ********************************/
    Dataset();

    // Build a dataset given the file.
    Dataset(const std::string& filename);

    /*
     * Copy constructor. Note: the dataset associated to the function can't
     * be copied, they must be rebuild
     */
    Dataset(const Dataset& dataset);

    /********************************
     * Destructor
     ********************************/
    ~Dataset();

    /**
     * Clear the patterns of the dataset
     **/
    void ClearPatterns();

    /**
     * Clear the sub datasets of the dataset
     **/
    void ClearSubDatasets();

    /**
     * Copy
     **/
    Dataset* Clone() const
    {
        return new Dataset(*this);
    }

    /********************************
     * Counters
     ********************************/

    /**
     * Return the size of the feature space
     **/
    inline Index Size() const
    {
        return patternsVector.size();
    }

    /*
     * Return DomainPatternsVector size
     */
    inline Index GetSizeForDomain(const std::string& domainName) const
    {
        DomainToPatternsVector::const_iterator iter = domains_to_patterns_vector.find(domainName);
        return (iter != domains_to_patterns_vector.end() ? iter->second.size() : 0);
    }
    Index GetBiggestDomainSize() const;

    /********************************
     * Accessors and Mutators.
     ********************************/

    /*
     * Get dataset name
     */
    inline const std::string& GetName() const
    {
        return name;
    }

    /*
     * Set dataset name
     */
    inline void SetName(const std::string& name_)
    {
        name = name_;
    }

    /**
     * Return the i-th pattern from the vector
     **/
    inline const Pattern* Get(const Index i) const
    {
        CHECK_LT(i, this->Size());
        return (i < this->Size() ? patternsVector[i] : NULL);
    }

    inline Pattern* GetMutable(const Index i) const
    {
        return (i < this->Size() ?
                const_cast<Pattern*>(patternsVector[i]) : NULL);
    }

    /**
     * Return the pattern from the domain and index
     **/
    inline const Pattern* GetByDomain(const std::string& domainName, const Index i) const
    {
        DomainToPatternsVector::const_iterator it = domains_to_patterns_vector.find(domainName);
        return (it != domains_to_patterns_vector.end() ? it->second[i] : NULL);
    }

    /**
     * Return the pattern by name from the patternVector
     **/
    inline const Pattern* GetByName(const std::string& patternName) const
    {
        bool found = false;
        const Index i = this->GetPatternIndex(patternName, &found);
        return (found ? this->Get(i) : NULL);
    }
    inline const Pattern* GetByNameOrDie(const std::string& patternName) const {
        bool found = false;
        const Index i = this->GetPatternIndex(patternName, &found);
        CHECK(found);
        return this->Get(i);
    }

    /**
     * Get the index of the input pattern
     **/
    inline Index GetPatternIndex(const std::string& patternName, bool* found) const
    {
        PatternIndexMap::const_iterator it = patternIndexMap.find(patternName);
        if (it != patternIndexMap.end()) {
            *found = true;
            return it->second;
        }
        *found = false;
        return 0;
    }

    inline Index GetPatternIndexOrDie(const std::string& patternName) const
    {
        PatternIndexMap::const_iterator it = patternIndexMap.find(patternName);
        if (it == patternIndexMap.end()) {
            FAULT("Could not find " << patternName);
        }
        return it->second;
    }
    /**
     * Get the index in the domain of the input pattern
     **/
    inline Index GetPatternIndexInDomain(const std::string& patternName) const {
        const std::string& patternDomain = GetDomain(patternName);
        DomainToPatternIndexMap::const_iterator it = domain_to_pattern_index_map.find(patternDomain);
        CHECK(it != domain_to_pattern_index_map.end());

        PatternIndexMap::const_iterator jt = it->second.find(patternName);
        CHECK(jt != it->second.end());
        return jt->second;
    }

    /**
     * Return the dataset for the domain.
     **/
    inline const Dataset* GetDomainDataset(const std::string& domain) const
    {
        DatasetsByDomain::const_iterator it = datasets_by_domain.find(domain);
        return (it != datasets_by_domain.end() ? it->second : NULL);
    }

    /**
     * Return the dataset for the domain.
     **/
    inline Dataset* GetMutableDomainDataset(const std::string& domain)
    {
        DatasetsByDomain::iterator it = datasets_by_domain.find(domain);
        return (it != datasets_by_domain.end() ?
                const_cast<Dataset*>(it->second) : NULL);
    }

    /*
     * Add a pattern to dataset.
     * For compatibility reasons, both version are used
     */
    bool Add(const Pattern* pattern);

    /*
     * Update the pattern given its position and known domain.
     * This is often done when creating the dataset by creating a dataset of NULL
     * patterns and then calling this function to set the single elements. This is
     * much faster than a direct call to AddToDataset since it never needs to
     * reallocate the vector.
     */
    bool Update(const Index index, const Index domain_index, const Pattern* pattern);

    /*
     * Build the dataset for each function. The dataset contains the Nary Pattern
     */
    void BuildDomainDataset(const Predicates& predicates, const Examples& examples);

    /**
     * Get the domain of the input pattern
     **/
    bool GetDomain(const std::string& patternName, std::string* domain) const
    {
        PatternIndexMap::const_iterator it = patternIndexMap.find(patternName);
        if (it != patternIndexMap.end()) {
            const Index pattern_index = patternIndexMap.find(patternName)->second;
            *domain = patternsVector[pattern_index]->GetDomain();
            return true;
        } else {
            return false;
        }
    }

    /**
     * Get the domain of the input pattern
     **/
    const std::string& GetDomain(const std::string& patternName) const
    {
        PatternIndexMap::const_iterator it = patternIndexMap.find(patternName);
        CHECK (it != patternIndexMap.end());
        Index pattern_index = patternIndexMap.find(patternName)->second;
        return patternsVector[pattern_index]->GetDomain();
    }

    /*
     * Get the vector of all distinct domains in the dataset.
     * Relatively slow as the vector is built on the fly.
     */
    void GetDomains(std::vector<std::string>* domains);

    /************************************************
     * Checkers
     ************************************************/
    /**
     * Check if two dataset are equal.
     **/
    bool Equals(const Dataset& dataset) const;
    bool EqualsIncludingDomainDatasets(const Dataset& dataset) const;

    /**
     * Check if a pattern is already inserted in the DomainsPatternsVectorMap
     **/
    bool Has(const std::string& patternName) const;

    /*************************************************************
     * I/O
     *************************************************************/

    bool LoadFromFile(const std::string& filename);
    bool LoadFromStream(std::istream& is);
    // Shorter and faster version of the above. Currently used by KernelMachineClassifier
    // to reload its underlying connected dataset.
    bool LoadFromStreamFast(std::istream& is);

    bool SaveToFile(const std::string& filename) const;
    bool SaveToStream(std::ostream& os) const;
    void Print() const;

protected:
    // The name of the dataset
    std::string name;
    /**
     * The vector of the patterns. Used in training
     **/
    typedef std::vector<const Pattern*> PatternsVector;
    PatternsVector patternsVector;

    /**
     * Map domain to vector of the patterns in the domain.
     **/
    typedef std::map<std::string, PatternsVector> DomainToPatternsVector;
    DomainToPatternsVector domains_to_patterns_vector;

    PatternIndexMap patternIndexMap;

    /**
     * The map of the map of the patterns and the indexes indexed by domain.
     * The key is the domain of the patterns, the value is map of the pattern
     * and indexes
     **/
    DomainToPatternIndexMap domain_to_pattern_index_map;

    typedef std::map<std::string, const Dataset*> DatasetsByDomain;
    DatasetsByDomain datasets_by_domain;

    /*
     * Add a pattern to the dataset (vector)
     **/
    bool AddToPatternsVector(const Pattern* pattern);

    /**
     * Add a pattern to the dataset indexed by domain (map of vector)
     **/
    bool AddToDomainsPatternsVectorMap(const std::string& domainName, const Pattern* pattern);

    /*
     * Add the correspondence between pattern and index (map)
     **/
    bool AddToPatternIndexMap(const std::string& patternName, const Index index);

    /*
     * Add the correspondence between pattern and index in the corresponding domain (map of map)
     **/
    bool AddToDomainsPatternIndexMap(const std::string& patternDomain, const std::string& patternName, const Index index);

    /*
     * Called by BuildDomainDataset() to add a leaner dataset for domains with only given functions.
     * In this case, we do not build datasets with all possible combinations of patterns in the
     * sub-domains, but only the patterns for the examples, as the given function will have a
     * default value on any other pattern, they do not need to be listed.
     * This allows to grow given function to n-ary domains that would be too large for
     * domains where LEARN functions work on.
     */
    void BuildDomainDatasetForGivenFunctions(const Predicates& predicates, const Examples& examples);

    /*
     * Add the association between the functions and their dataset
     **/
    bool AddDomainDataset(const std::string& domain_name, const Dataset* dataset);
    friend class DatasetUtils;
}; // end Dataset

class DatasetUtils
{
public:
    static bool AddTo(const Dataset& datasetToAdd, Dataset* dataset);

    // Add the examples of a dataset into the examples of another dataset
    static bool AddTo(const Examples& examplesToAdd, Examples* examples);

    /*
     * Make a Nary pattern from the aggregated pattern name.
     */
    static Pattern* MakePattern(const std::string& patternName,
                                const std::string& patternDomain,
                                const Dataset& dataset);

    /*
     * Make a Nary pattern from the patterns.
     */
    static Pattern* MakePattern(const std::vector<const Pattern*>& patterns);
}; // end DatasetUtils

}  // end Regularization
#endif /* DATASET_H */
