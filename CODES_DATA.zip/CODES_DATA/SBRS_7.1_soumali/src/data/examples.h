/*
 * File:   examples.h
 * Author: Tore
 *
 * Created on 3 febbraio 2011, 14.40
 */

#ifndef EXAMPLES_H
#define EXAMPLES_H

#include <string>
#include <deque>
#include <map>
#include <vector>

#include "classifier/functions/function.h"  // for Function::ID
#include "data/basic_data_types.h"


namespace Regularization {
class Predicates;
class Dataset;

/******************************************************************************
 * class for the examples for the predicates
 * predicate example declaration (PED)
 * name(ei1,...ein)=[value]
 * (For instance A(p1,p2,...,pn)=1.2)
 ******************************************************************************/

/**
 * Collects a set of examples for the predicates.
 **/
class Examples
{
public:
    /*
     * The predicates can be Nary so the name is a vector of strings.
     * */
    // If the name is n-ary, merge the unary pattern names with a '_'.
    typedef std::string PatternName;

    /*
     * A single example for the predicate (For instance: A(p1,p2,...,p3) = 0.1,
     */
    struct Example {
        PatternName pattern;
        Function::ID id;
        Value value;
        inline bool Equals(const Example& example_) const {
            return pattern == example_.pattern && id == example_.id && value == example_.value;
        }
        inline Example(const PatternName& pattern_, const Function::ID& id_, const Value value_) :
            pattern(pattern_), id(id_), value(value_) {
        }
        inline Example(const Example& example_) :
            pattern(example_.pattern), id(example_.id), value(example_.value) {
        }
        std::string ToString() const;
    };

    // The container of examples. The use of a deque speeds up the loading, as
    // it is not known a priori how many examples will be loaded.
    typedef std::deque<Example*> ExampleContainer;

    /**
     * Map used to store the examples for each predicate.
     **/
    typedef std::deque<Example*> PerFunctionExamples;
    typedef std::map<Function::ID, PerFunctionExamples> FunctionExampleMap;
    /**
     * Map used to store the examples for each pattern.
     **/
    typedef std::vector<Example*> PerPatternExamples;
    typedef std::map<PatternName, PerPatternExamples> PatternExampleMap;
    /**
     * Map used to lookup an example given the pattern and function.
     **/
    typedef std::map<std::pair<Function::ID, PatternName>, Example*> FunctionPatternExampleMap;

    /*
     * Example iterator
     */
    class Iterator
    {
    private:
        ExampleContainer::const_iterator iter;
        const Examples* examples;

    public:
        Iterator(const Examples& examples_)
        {
            examples = &examples_;
            iter = examples->examples.begin();
        }

        inline bool HasNext() const
        {
            return (iter != examples->examples.end());
        }

        inline const Example* GetNext() {
            if (this->HasNext())
            {
                const Example* ret = *iter;
                iter++;
                return ret;
            }

            return NULL;
        }

        void Rewind()
        {
            iter = examples->examples.begin();
        }
    };

    /********************************
     * Constructors
     ********************************/
    Examples();

    /*
     * Copy constructor
     */
    Examples(const Examples& examples_);

    /********************************
     * Destructor
     ********************************/
    ~Examples();

    /**********************************************
     * Accessors and Mutators
     **********************************************/

    /**
     * Clears the whole dataset
     **/
    void Clear();

    /**
     * Get the name
     **/
    inline const std::string& GetName() const
    {
        return name;
    }

    /**
     * Returns the examples for the predicate.
     **/
    inline const PerFunctionExamples* GetExamplesForPredicate(const Function::ID& id) const
    {
        FunctionExampleMap::const_iterator it = function2examples.find(id);
        return (it == function2examples.end() ? NULL : &(it->second));

    }

    /**
     * Returns the examples for the pattern.
     **/
    inline const PerPatternExamples* GetExamplesForPattern(const PatternName& name) const
    {
        PatternExampleMap::const_iterator it = pattern2examples.find(name);
        return (it == pattern2examples.end() ? NULL : &(it->second));
    }

    /*
     * Add an example to exampleMap
     */
    bool Add(const Example& example);

    /********************************
     * Counters
     ********************************/

    /**
     * Return the number of examples
     **/
    inline Index Size() const {
        return examples.size();
    }

    /*
     * Check if the pattern is supervised.
     */
    inline bool IsSupervised(const PatternName& patternName) const {
        PatternExampleMap::const_iterator iter = pattern2examples.find(patternName);
        return (iter != pattern2examples.end() && !iter->second.empty());
    }

    /*
     * Check if the vector of patterns for the predicate is supervised
     * and get the target
     */
    inline bool IsSupervised(
            const Function::ID& id, const PatternName& patternName,
            Value* target) const {
        FunctionPatternExampleMap::const_iterator iter =
                function_pattern2examples.find(make_pair(id, patternName));
        if (iter == function_pattern2examples.end()) {
            return false;
        }
        *target = iter->second->value;
        return true;
    }

    /*
     * Check if the vector of patterns for the predicate is supervised.
     */
    inline bool IsSupervised(const Function::ID& id, const PatternName& patternName) const {
        FunctionPatternExampleMap::const_iterator iter =
                function_pattern2examples.find(make_pair(id, patternName));
        if (iter == function_pattern2examples.end()) {
            return false;
        }

        return true;
    }
    inline Index NumSupervised(const Function::ID& id) const {
        FunctionExampleMap::const_iterator iter = function2examples.find(id);
        return (iter == function2examples.end() ? 0 : iter->second.size());
    }

    /*
     * Find an example in the examplesMap
     */
    inline bool HasExample(const Example& example) const {
        FunctionPatternExampleMap::const_iterator iter =
                function_pattern2examples.find(make_pair(example.id, example.pattern));
        if (iter == function_pattern2examples.end())
            return false;
        return iter->second->value == example.value;
    }

    /*
     * Get the ratio of supervised elements for the predicate. If negation is
     * false compute the ratio as Npositive/(Npositive + Nnegative) otherwise
     * compute the Nnegative/(Npositive + Nnegative)
     */
    Value GetSupervisedRatioForPredicate(const std::string& predicateName, const bool negation) const;

    /***********************************************************
     * I/O
     ************************************************************/
    bool LoadFromFile(const std::string& examplesFilename, const Dataset& dataset,
            const Predicates& predicates, const bool clear);
    bool LoadFromStream(std::istream& is, const Dataset& dataset,
            const Predicates& predicates, const bool clear);

    bool SaveToFile(const std::string& filename) const;
    bool SaveToStream(std::ostream& os) const;
    void Print() const;
    std::string ToString() const;

private:
    std::string name;
    // The plain set of examples.
    ExampleContainer examples;
    // Map used to store the examples for each predicate.
    FunctionExampleMap function2examples;
    // Map used to store the examples for each pattern.
    PatternExampleMap pattern2examples;
    // Map used to lookup an example given the pattern and function.
    FunctionPatternExampleMap function_pattern2examples;
}; // end Examples
}
#endif /* EXAMPLES_H */

