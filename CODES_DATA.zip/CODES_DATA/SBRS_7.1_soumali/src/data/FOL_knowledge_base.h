/*
 * File:   FOL_knowledge_base.h
 * Author: Tore
 *
 * Created on 11 gennaio 2011, 10.07
 */

#ifndef FOL_KNOWLEDGEBASE_H
#define FOL_KNOWLEDGEBASE_H

#include <iosfwd>
#include <vector>

#include "data/FOL_formula.h"


namespace Regularization {
class Dataset;
class Predicates;

/******************************************************************************
 * class for all FOL formulas
******************************************************************************/
/**
 * Collects a set of FOL formulas.
 **/
class FOLKnowledgeBase
{
    public:

        /********************************
         * Constructors
         ********************************/
        FOLKnowledgeBase()
        {
        }

        /******************************
         * Copy constructors
         *****************************/
        FOLKnowledgeBase(const FOLKnowledgeBase& FOL_KnowledgeBase);

        /********************************
         * Destructors
         ********************************/
        ~FOLKnowledgeBase();

        /**********************************************
         * Accessors and Mutators
         **********************************************/

        /**
         * Return the i-th formula
         * safe version
        **/
        inline const FOLFormula& Get(int i) const
        {
            return *formulas[i];
        }

        /**
         * Add a formula to the knowledge base
        **/
        bool Add(const FOLFormula& formula);

        /**
         * Clear all knowledge base
        **/
        void Clear();

        /**
         * Check if a formula is already present in knowledge base
        **/
        bool HasFormula(const std::string& formula_str) const;
        bool HasFormula(const FOLFormula& formula) const;

        /********************************
         * Counters
         ********************************/

        /**
         * Return the size of the map
         **/
        inline int Size() const
        {
            return static_cast<int>(formulas.size());
        }

        /***********************************************************
        * I/O
        ************************************************************/

        bool LoadKnowledgeBase(
                const std::string& filename, const Dataset& dataset, const Predicates& predicates, const bool clear = true);
        bool LoadKnowledgeBaseFromStream(
                std::istream& is, const Dataset& dataset, const Predicates& predicates, const bool clear);

        bool Save(const std::string& filename) const;
        bool SaveToStream(std::ostream& os) const;
        void Print() const;
        std::string ToString() const;

    private:
        /**
        * The formulas. First element is the name of a formula, the second one
        * is the correspondent class.
        **/
        typedef std::vector<const FOLFormula*> Formulas;
        Formulas formulas;
}; // end FOLKnowledgeBase
}

#endif /* FOL_KNOWLEDGEBASE_H */
