#include "data/examples.h"

#include <fstream>
#include <sstream>

#include "data/dataset.h"
#include "data/predicates.h"
#include "utils/general.h"
#include "utils/stl_utils.h"
#include "utils/string_utils.h"


using namespace Regularization;

std::string Examples::Example::ToString() const {
    std::ostringstream os;
    os << pattern << " " << id << " " << value;
    return os.str();
}

Examples::Examples() { }

Examples::Examples(const Examples& examples_)
{
    this->name = examples_.name;
    Examples::Iterator iter(examples_);
    while (iter.HasNext()) {
        const Example* example = iter.GetNext();
        CHECK(this->Add(*example));
    }
}

Examples::~Examples() {
    this->Clear();
}

void Examples::Clear()
{
    std::DeallocVectorOfPointers(&examples);
    examples.clear();
    function2examples.clear();
    pattern2examples.clear();
    function_pattern2examples.clear();
}

/**
 * Load from file (examples)
 **/
bool Examples::LoadFromFile(const std::string& filename, const Dataset& dataset,
                            const Predicates& predicates, const bool clear)
{
    std::ifstream ifs(filename.c_str());

    if (!ifs.is_open())
    {
        WARN("Could not open the file " << filename);
        return false;
    }

    this->name = filename;
    bool ret = this->LoadFromStream(ifs, dataset, predicates, clear);
    ifs.close();

    return ret;
}

/**
 * Load from stream (examples)
 **/
bool Examples::LoadFromStream(
        std::istream& is, const Dataset& dataset, const Predicates& predicates,
        const bool clear) {
    if (clear) {
        this->Clear();
    }

    std::string line;
    std::vector<std::vector<std::string> > exampleVector;
    unsigned int lineCounter = static_cast<int>(0);

    while (!is.eof()) {
        line.clear();
        getline(is, line);
        lineCounter++;

        // skip empty lines and carriage return
        if (line.empty() || line.size() == 1) {
            continue;
        }

        // skip comment line
        if (line.find('#') == 0) {
            continue;
        }

        // search for invalid character, the second parameter are valid ASCII symbols
        if (!StringUtils::IsAlphaNumericOrInSet(line, "/+_-*()=,.\r"))
        {
            WARN("Invalid character used, see the examples file at line " << lineCounter << ":\n" << line);
            return false;
        }

        // parser error; check the number of brackets
        if (StringUtils::CharCounter(line, '(') != 1 || StringUtils::CharCounter(line, ')') != 1)
        {
            WARN("Invalid number of () see the examples file at line " << lineCounter << ":\n" << line);
            return false;
        }

        // removes the brackets
        exampleVector.clear();
        StringUtils::SplitToVectorOfVectorsByType(line, &exampleVector, "(", ")", 0);
        const Function::ID& predicateName = exampleVector[0][0];

        // parser error; check the correct split of the line 0->A 10->(p1,p2) 11->=0.6 ? blank
        if (exampleVector.size() != 2 || (exampleVector[1].size() != 1 && exampleVector[1].size() != 2))
        {
            WARN("Rewrite the example, see the file of examples at line " << lineCounter << ":\n" << line);
            return false;
        }

        std::vector<std::string> exampleInputPatterns;
        // split the input patterns
        StringUtils::SplitToVector(exampleVector[1][0], &exampleInputPatterns, ",", false);
        for (unsigned int i = 0; i < exampleInputPatterns.size(); ++i) {
            if (!StringUtils::IsAlphaNumericOrInSet(exampleInputPatterns[i], "-*"))
            {
                // This is also to guarantee that the n-ary patterns, named
                // with the concatenation of the names, will not conflict.
                WARN("Rewrite the input pattern of example of the predicate " << predicateName
                     << " in appropriate form. @line " << lineCounter << ":\n" << line);
                return false;
            }
        }
        const std::string pattern_name = StringUtils::ContainerToString(exampleInputPatterns, "_", "");

        // check if the example has specified a true value
        Value predicateValue = static_cast<Value>(0);

        if (exampleVector[1].size() == 1) {
            predicateValue = static_cast<Value>(1); // default value for example
        } else {
            // parser error; check the consistency of the output value
            const size_t pos = exampleVector[1][1].find("=");
            if (pos == std::string::npos) {
                WARN("Rewrite the output value of the example, see the file of the examples at line " <<
                     lineCounter << ":\n" << line);
                return false;
            }

            const std::string target_str = exampleVector[1][1].substr(pos + 1);
            if (target_str.substr(0, 5) == "false" || target_str.substr(0, 5) == "False") {
                predicateValue = static_cast<Value>(0);
            } else if (target_str.substr(0, 4) == "true" || target_str.substr(0, 4) == "True") {
                predicateValue = static_cast<Value>(1);
            } else if (!StringUtils::FromString<Value>(target_str, &predicateValue)) {
                WARN("Invalid example target, see example file at line " << lineCounter << ":\n" << line);
                return false;
            }
        }

        // Add the example to examplesMap, it will check if the example has been already inserted.
        Example example(pattern_name, predicateName, predicateValue);
        CHECK_WITH_MESSAGE(this->Add(example),
                "Cannot add example " + example.ToString());

        // check the consistency of the definitions and the predicates, the dataset and the examples
        if (dataset.Size() == 0) {
            WARN("Error: empty Dataset provided, no consistency checks can be performed.");
            return false;
        }
        if (predicates.Size() == 0) {
            WARN("Error: no Predicates provided, no consistency checks can be performed.");
            return false;
        }
        const Predicate* predicate = predicates.Get(predicateName);
        if (predicate == NULL) {
            // parser error; check if there are examples without correspondent predicate
            WARN("Warning: an example of predicate " << predicateName <<
                 " has not a corresponding predicate in file of the definitions, " <<
                 "see the file of examples at line " << lineCounter);
            return false;
        }
        // parser error; check the consistency between value of predicate and problemType
        if (predicate->GetProblemType() == Predicate::C &&
            predicateValue != static_cast<Value>(0) && predicateValue != static_cast<Value>(1) &&
            predicate->GetPredicateType() != Function::MAP_GIVEN)
        {
            // WARN("Error: there is an inconsistency between the value of the predicate and type of problem of the predicate " << predicateName << " between the file of the definitions and the file of the examples, see the file of the examples at line " << lineCounter << std::endl);
            // return false;
        }

        // parser error; check the consistency between the arity of the predicate and the example input pattern
        if (predicate->GetArity() != static_cast<unsigned int>(exampleInputPatterns.size()))
        {
            WARN("Error: there is a discrepancy in the arity of the predicate " << predicateName << ", see the file of the examples at line " << lineCounter << std::endl);
            return false;
        }

        // N.B. the arity of the predicate and of the patterns is the same
        for (unsigned int j = 0; j < exampleInputPatterns.size(); j++)
        {
            std::string domain;

            // parser error; verify if an example input pattern is defined in data file
            if (!dataset.GetDomain(exampleInputPatterns[j], &domain))
            {
                WARN("Error: pattern " << exampleInputPatterns[j] << " of predicate " <<
                     predicateName << " not defined in the data, see example file at line " << lineCounter);
                return false;
            }

            // parser error; verify for each example input pattern if the domain is correct
            if (domain != predicate->GetDomain(j))
            {
                WARN("Error: discrepancy between the domain " << predicate->GetDomain(j) << " of the " << j + 1 <<
                     " pattern of predicate " << predicateName << " and domain " << domain << " of pattern " <<
                     exampleInputPatterns[j] << ", see the file of the examples at line " << lineCounter);
                return false;
            }
        }

        if (lineCounter % 10000 == 0) {
        	VPRINT(0, "\rExamples imported " << lineCounter);
        }
    }

    VPRINTLN(0, "\n");

    return true;
}

/**
 * Save to a stream
 **/
bool Examples::SaveToStream(std::ostream& os) const
{
    bool ret = true;

    Examples::Iterator iter(*this);
    while (iter.HasNext()) {
        const Example* example = iter.GetNext();
        if (example->pattern.empty()) {
            ret = false;
            break;
        }
        os << example->id << "(";
        std::string pattern_name = example->pattern;
        StringUtils::Replace('_', ',', &pattern_name);
        os << pattern_name;
        os << ")=" << example->value << std::endl;
    }

    return ret;
}

/**
 * Save to a file
 **/
bool Examples::SaveToFile(const std::string& filename) const
{
    std::ofstream ofs(filename.c_str());

    if (!ofs.is_open())
    {
        WARN("Could not open the file " << filename);
        return false;
    }

    return this->SaveToStream(ofs);
}

/**
 * Print examples info to stdout
 **/
void Examples::Print() const
{
    std::cout << "----------------------------------------" << std::endl;
    std::cout << "Examples Info:" << std::endl;
    std::cout << "Examples name: " << name << std::endl;
    std::cout << "Number of examples: " << this->Size() << std::endl;
    this->SaveToStream(std::cout);
    std::cout << std::endl << "----------------------------------------" << std::endl;
}

std::string Examples::ToString() const {
    std::ostringstream os;
    this->SaveToStream(os);
    return os.str();
}

/*
 * Add an example to exampleMap
 */
bool Examples::Add(const Example& example_) {
    if (example_.id.empty() || example_.pattern.empty()) {
        WARN("Wrong example inserted: " << example_.ToString());
        return false;
    }
    // check if the example is already inserted
    if (this->HasExample(example_)) {
        WARN("Example already inserted:" << example_.ToString());
        return false;
    }

    Example* example = new Example(example_);
    examples.push_back(example);
    function2examples[example->id].push_back(example);
    pattern2examples[example->pattern].push_back(example);
    function_pattern2examples[make_pair(example->id, example->pattern)] = example;
    return true;
}

/*
 * Get the ratio of supervised elements for the predicate. If negation is
 * false compute the ratio as Npositive/(Npositive + Nnegative) otherwise
 * compute the Nnegative/(Npositive + Nnegative)
 */
Value Examples::GetSupervisedRatioForPredicate(
        const Function::ID& name, const bool negation) const {

    Value val = static_cast<Value>(0);
    // find the predicate
    FunctionExampleMap::const_iterator it = function2examples.find(name);

    if (it == function2examples.end() || it->second.empty()) {
        WARN("Error: the predicate " << name << " does not have examples");
        return 0;
    }

    // Note: compute the ratio
    for (PerFunctionExamples::const_iterator it1 = it->second.begin();
            it1 != it->second.end(); ++it1) {
        // count positive examples
        if ((*it1)->value > static_cast<Value>(0)) {
            ++val;
        }
    }

    val /= it->second.size();

    return negation ? static_cast<Value>(1.0) - val : val;
}
