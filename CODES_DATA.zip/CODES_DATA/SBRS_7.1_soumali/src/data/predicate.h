/*
 * File:   predicate.h
 * Author: Tore
 *
 * Created on 3 novembre 2010, 10.07
 */

#ifndef PREDICATE_H
#define	PREDICATE_H

#include <string>
#include <vector>

#include "classifier/functions/function.h"
#include "utils/general.h"


namespace Regularization
{
/******************************************************************************
 * class for a single predicate
 * predicate definition directive (PDD)
 * DEF name(d1,...,dn);{LEARN,GIVEN};{C,R};{T,F,DC}
 ******************************************************************************/

/**
 * Class to represent a predicate.
 **/
class Predicate
{
    public:

        /**
         * The input domains for the variables of the predicate.
         * The vector is used as efficient search method for the consistency checks
         * between the input domain for the variables of the predicate
         * and the domain of the patterns. (For instance: A(d1,d2,...,dn))
         **/
        typedef std::vector<std::string> Domains;

        typedef enum
        {
            C, R
        } PROBLEM_TYPE;

        typedef enum
        {
            T, F, DC
        } DEFAULT_TRUTH_VALUE;

        inline static DEFAULT_TRUTH_VALUE DefaultTruthValueFromStringOrDie(const std::string& str) {
            if (str == "T")  return T;
            if (str == "F")  return F;
            if (str == "DC")  return DC;

            FAULT("Undefined truth value: " << str);
            return T;  // we never get here.
        }

        inline static std::string DefaultTruthValueToString(const DEFAULT_TRUTH_VALUE pt) {
             if (pt == T)  return "T";
             if (pt == F)  return "F";
             if (pt == DC)  return "DC";
             FAULT("Undefined truth value");
             return "T";  // we never get here.
        }

        inline static PROBLEM_TYPE ProblemTypeFromStringOrDie(const std::string& str) {
            if (str == "C")  return C;
            if (str == "R")  return R;

            FAULT("Undefined problem type: " << str);
            return C;  // we never get here.
        }

        inline static std::string ProblemTypeToString(const PROBLEM_TYPE pt) {
             if (pt == C)  return "C";
             if (pt == R)  return "R";
             FAULT("Undefined problem type");
             return "C";  // we never get here.
        }

        /********************************
         * Constructors.
         ********************************/
        Predicate() { }

        Predicate(const Function::ID& name_, const Domains& domains_,
                  const std::string& predicateType_, const std::string& problemType_,
                  const std::string& defaultTrueValue_);

        /********************************
         * Accessors and Mutators.
         ********************************/
        /**
         *  Get the name of the predicate
         **/
        inline const Function::ID& GetName() const
        {
            return name;
        }

        /**
         *  Get the arity of the predicate
         **/
        inline Function::Arity GetArity() const
        {
            return domains.size();
        }

        /**
         * Get the i-th domain of the variable
         **/
        inline const std::string& GetDomain(int i) const
        {
            return domains[i];
        }

        /**
         * Get the vector of domains of the variable
         **/
        inline const Domains& GetDomains() const
        {
            return domains;
        }

        // Get a single unique string representation of the domains.
        inline const std::string& GetDomainString() const
        {
            return domain_str;
        }
        /**
         * Get the type of the problem for the predicate
         **/
        inline PROBLEM_TYPE GetProblemType() const
        {
            return problemType;
        }

        /**
         * Get the type of the predicate
         **/
        inline Function::TYPE GetPredicateType() const
        {
            return predicateType;
        }

        /**
         * Get the default truth value of the predicate
         **/
        inline DEFAULT_TRUTH_VALUE GetDefaultTruthValue() const
        {
            return defaultTruthValue;
        }

        inline Value GetDefaultValue() const
        {
            switch(this->defaultTruthValue) {
            case T:
                return 1.0;
            case F:
                return 0.0;
            default:
                return 0.5;
            }
        }

        /************************************************************
         * I/O
         ************************************************************/

        void Print() const;
        std::string ToString() const;
        bool Save(std::ostream& os) const;

    private:

        /**
         * Name of the predicate
         **/
        Function::ID name;

        Domains domains;
        std::string domain_str;

        Function::TYPE predicateType;
        PROBLEM_TYPE problemType;
        DEFAULT_TRUTH_VALUE defaultTruthValue;

        /*
         * The pointer to a function for association between the predicate and the
         * function
         */
        // Function* function;
};  // end Predicate
}  // end Regularization

#endif	/* PREDICATE_H */
