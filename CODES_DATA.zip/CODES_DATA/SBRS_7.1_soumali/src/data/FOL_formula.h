/*
 * File:   FOL_formula.h
 * Author: Tore
 *
 * Created on 9 dicembre 2010, 17.07
 */

#ifndef FOL_FORMULA_H
#define FOL_FORMULA_H

#include <string>
#include <iosfwd>
#include <map>
#include <vector>

#include "data/basic_data_types.h"
#include "utils/general.h"
#include "utils/string_utils.h"
#include "constraints/propositional_constraint/tnorm.h"  // for TNormFactory


/*********************************************************************************
 * Rule Definition Directive (RDD). The FOL rule are expressed by Prenex Normal Form
 * (PNF). PNF: quantified portion + quantifier free portion (CNF)
 * (For instance forall x, ... forall z [(NOT A(x) OR ... OR B(y,z)) AND (B(x) OR C(x)) ... AND C(z)])
 **********************************************************************************/

namespace Regularization {
class Dataset;
class Predicates;

/**
 * Represent a FOL rule
 **/
class FOLFormula
{
    public:
        // logic quantifiers

        typedef enum
        {
            forall, exists, exists_N
        } QUANTIFIER;

        /**
         * The vector for quantified variables. The first element of the outer pair
         * is the quantifier while the second element is the name of the variable.
         * The inner pair represent the quantifier with its cardinality.
         * NOTE: this information is useful only for exists_N quantifier
         * (For instance forall x, exists y ... exists z)
         * (For instance forall x, exists y_5 ... exists z)
         **/
        class QuantifiedVariable {
        public:
            std::string name;
            QUANTIFIER quantifier;
            double quantifier_num;  // used only for \exists_N
            inline QuantifiedVariable(
                       const std::string& name_, const QUANTIFIER quantifier_, const double quantifier_num_) :
                       name(name_), quantifier(quantifier_), quantifier_num(quantifier_num_) {
            }
            inline bool operator==(const QuantifiedVariable& v) const {
                return name == v.name &&
                       quantifier == v.quantifier &&
                       quantifier_num == v.quantifier_num;
            }
        };
        typedef std::vector<QuantifiedVariable> QuantifiedVariables;

        /**
         * The map for the domain of the quantified variables. The first element is
         * the name of variable while the second one is the correspondent domain.
         * (For instance x->d1, y->d2 ... z->dn)
         **/
        typedef std::map<std::string, std::string> VariablesDomains;

        /**
         * The struct literal represents a single predicate.
         * (For instance A(x), NOT A(x), B(x,y,z))
         **/
        class Literal {
        private:
            // the name of the predicate
            std::string id;
            // the variables of the predicate
            std::vector<std::string> predicateVariables;
            bool valid;

        public:
            Literal() : valid(false) { }
            inline bool IsValid() const {
                return valid;
            }
            inline const std::string& GetId() const {
                return id;
            }
            inline const std::vector<std::string>& GetPredicateVariables() const {
                return predicateVariables;
            }

            bool Load(const std::string& str);
            std::string ToString() const;

            /**
             * Check if the literal is equal to the given one
             */
            bool Equals(const Literal& literal) const;
        };

        class PropositionalFormula {
        private:
            bool valid;
            // Formula is a single literal of a sequence of formulas connected by connectives.
            Literal literal;
            std::string logic_connective;  // can be empty for a single non-negated literal
            std::vector<PropositionalFormula> subformulas;
            std::set<std::string> ids;
            void PopulateInvolvedIds();

        public:
            PropositionalFormula() : valid(false) { }
            inline bool IsValid() const { return valid; }
            inline const Literal& GetLiteral() const {
                return literal;
            }
            inline const std::string& GetLogicConnective() const {
                return logic_connective;
            }
            inline const std::vector<PropositionalFormula>& GetSubFormulas() const {
                return subformulas;
            }

            // Get a list of all literals present in the formula.
            void GetAllLiterals(std::vector<const Literal*>* literals) const;
            void GetAllVariables(std::set<std::string>* variables) const;
            bool InvolvesLiteral(const std::string& id) const {
                return ids.find(id)  != ids.end();
            }
            bool Load(const std::string& str);
            std::string ToString() const;
            bool Equals(const PropositionalFormula& formula) const;
        };

        // The type of rule
        typedef enum
        {
            LEARN = 0, VERIFY = 1
        } RULE_TYPE;

        // The type of quantifier conversion norm
        typedef enum
        {
            LINF = 0, L1 = 1, L2 = 2
        } QUANTIFIER_CONVERSION_NORM;

        /********************************
         * Constructors.
         ********************************/
        FOLFormula(const std::string& name_);

        /**********************************************
         * Accessors and Mutators
         **********************************************/

        // Copy
        const FOLFormula* Clone() const
        {
            return new FOLFormula(*this);
        }

        // Set the parameters of the formula
        bool SetParameters(const std::string& ruleType_,
                const std::string& quantifier_conversion_norm_,
                const std::string& propositional_conversion_norm_,
                const std::string& lambda_,
                const std::string& priority_);

        // Get the type of rule for the formula
        inline RULE_TYPE GetRuleType() const {
            return ruleType;
        }

        // Get the type of quantifier conversion norm
        inline QUANTIFIER_CONVERSION_NORM GetQuantifierNormType() const
        {
            return quantifier_conversion_norm;
        }

        // Get the type of propositional conversion norm
        inline TNormFactory::TYPE GetPropositionalNormType() const
        {
            return propositional_conversion_norm;
        }

        // Get the name of formula
        inline const std::string& GetName() const
        {
            return name;
        }

        // Get the vector of the quantified variables
        inline const QuantifiedVariables& GetQuantifiedVariables() const
        {
            return quantifiedVariables;
        }

        // Get the FOLFormula
        inline const PropositionalFormula& GetPropositionalFormula() const
        {
            return propositional_formula;
        }

        // Get the domain of the variable
        inline const std::string& GetVariableDomain(const std::string& variableName) const
        {
            VariablesDomains::const_iterator it = variablesDomains.find(variableName);

            if (it == variablesDomains.end()) {
                FAULT("The domain of the variable not found");
            }
            return it->second;
        }

        // Get the given literal
        inline const Literal& GetGivenLiteral() const
        {
            return givenLiteral;
        }

        // Check if the FOL Formula consists only of universal quantifier
        inline bool IsUniversallyQuantified() const
        {
            return universallyQuantified;
        }
        // Check if the FOL Formula has an exists N quantifier (N>1)
        inline bool HasExistsN() const
        {
            return has_exists_n;
        }

        // Get the value of lambda for the constraint
        inline Value GetLambda() const
        {
            return lambda;
        }

        // Get the priority for the constraint
        inline unsigned int GetPriority() const
        {
            return priority;
        }

        inline bool InvolvesLiteral(const std::string& id) const {
            return propositional_formula.InvolvesLiteral(id);
        }

        /***********************************************************
         * I/O
         ************************************************************/
        bool Load(const std::string& rule,
                  const Predicates& predicates,
                  const std::string& optimization_predicate);
        bool Save(std::ostream& os, const bool full_info = true) const;
        void Print() const;
        std::string ToString(const bool full_info = true) const;

        bool Equals(const FOLFormula& formula) const;

    private:
        // Name of the formula. It is used to find a formula
        // (For instance exists x forall z [B(x) AND NOT A(x,u,v) AND F(x,y,z,u,v)])
        std::string name;

        QuantifiedVariables quantifiedVariables;

        VariablesDomains variablesDomains;

        PropositionalFormula propositional_formula;

        // LEARN, VERIFY
        RULE_TYPE ruleType;

        // LINF, L1, L2
        QUANTIFIER_CONVERSION_NORM quantifier_conversion_norm;

        // PRODUCT_TNORM, MINIMUM_TNORM, ecc.
        TNormFactory::TYPE propositional_conversion_norm;

        /*
         * Optimization:
         * The name of the literal/predicate that appears in the antecedent of
         * an implication of the FOL formula.
         * For instance forall x A(x) => ... if A is a given literal/predicate.
         * For instance forall x forall y forall z (A(x) AND B(x,y)) OR C(z) => ...
         * can be replaced by forall x forall y D(x,y) => ...
         * if all A(x), B(x,y) and C(z) are given literals/predicates and D(x,y)
         * represents them
         */
        Literal givenLiteral;

        // Optimization: if the FOL Formula consists only of universal quantifier
        // use optimized computation.
        // For instance forall x forall y phi(x,y)
        bool universallyQuantified;
        // Some Optimization not possible for functions with exists_N (N>1)
        bool has_exists_n;

        // Custom lambda of the constraint
        Value lambda;

        // Priority of the constraint
        unsigned int priority;

        // Set the vector of quantifiers and quantified variables
        bool LoadQuantifiedVariables(const std::string& quantifiedPortion);

        // Set the quantifier-free portion (propositional) of the formula
        bool LoadPropositionalFormula(const std::string& propositionalPortion, const Predicates& predicates);
}; // FOLFormula
}

#endif /* FOL_FORMULA_H */
