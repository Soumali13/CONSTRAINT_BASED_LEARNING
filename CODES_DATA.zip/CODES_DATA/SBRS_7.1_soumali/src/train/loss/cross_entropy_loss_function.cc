#include <cmath>

#include "train/loss/cross_entropy_loss_function.h"
#include "utils/general.h"
#include "utils/math/math_utils.h"


namespace Regularization {

/*********************************
 *
 * CrossEntropyLossFunction
 * This loss function is defined only for values and targets in [0,1],
 * remember to apply a Sigmoid on the output of your functions!!!
 *********************************/
CrossEntropyLossFunction::CrossEntropyLossFunction()
{
}

CrossEntropyLossFunction::~CrossEntropyLossFunction()
{
}

/**
 * It evaluates - (target * log(value) + (1-target) * log(1-value))
 */
Value CrossEntropyLossFunction::Eval(const Value value, const Value target) const
{
    CHECK_INE_RANGE(value, static_cast<Value>(-1.0), static_cast<Value>(1.0));
    CHECK_INE_RANGE(target, static_cast<Value>(-1.0), static_cast<Value>(1.0));
    // Ugly hack, the external code passes targets and values in [-1,+1] by calling MAP_TO.
    // This was done to natively support the hinge loss. However, other losses assumes values
    // to be in [0,1] like this one and need to do their own remapping.
    // Fix this by passing the raw values and have each loss to do its specific remapping.
    const Value rebalanced_target = LossFunction::MAP_FROM(target);
    const Value rebalanced_value = LossFunction::MAP_FROM(value);

    Value ret = 0;
    if (rebalanced_target > 0) {
        ret += rebalanced_target * std::log(Math::Max(rebalanced_value, static_cast<Value>(1e-6)));
    }
    if (rebalanced_target < 1) {
        ret += (1 - rebalanced_target) * std::log(Math::Max(1 - rebalanced_value, static_cast<Value>(1e-6)));
    }
    return -ret;
}

/**
 * It evaluates the result of the derivative of the cross entropy function, i.e.
 * - (target * 1/value + (1-target) * (-1)/(1-value))
 */
Value CrossEntropyLossFunction::EvalDerivative(const Value value, const Value target) const
{
    CHECK_INE_RANGE(value, static_cast<Value>(-1.0), static_cast<Value>(1.0));
    CHECK_INE_RANGE(target, static_cast<Value>(-1.0), static_cast<Value>(1.0));
    // Ugly hack, see above.
    const Value rebalanced_target = LossFunction::MAP_FROM(target);
    const Value rebalanced_value = LossFunction::MAP_FROM(value);

    Value ret = 0;
    if (rebalanced_target > 0) {
        ret += rebalanced_target * 1 / Math::Max(rebalanced_value, static_cast<Value>(1e-6));
    }
    if (rebalanced_target < 1) {
        ret += (1 - rebalanced_target) * (-1) / Math::Max(1 - rebalanced_value, static_cast<Value>(1e-6));
    }
    return -ret;
}
}  // end Regularization
