#ifndef QHINGE_LOSS_FUNCTION_H
#define QHINGE_LOSS_FUNCTION_H

#include "train/loss/bilateral_qhinge_loss_function.h"

namespace Regularization
{
/*
\
 \
  \
   \
    \_________________________
*/
class QHingeLossFunction : public BilateralQHingeLossFunction
{
    public:
        QHingeLossFunction(Value threshold_, Value slope_before_threshold_) :
            BilateralQHingeLossFunction(threshold_, slope_before_threshold_, 0.0)
        {
        }
        virtual ~QHingeLossFunction() { }
        virtual std::string Name() const { return "QHINGE"; }

        virtual LossFunction* Clone() {
            return new QHingeLossFunction(threshold, slope_before_threshold);
        }
}; // end HingeLossFunction
} // end namespace Regularization
#endif /* HINGE_LOSS_FUNCTION_H */
