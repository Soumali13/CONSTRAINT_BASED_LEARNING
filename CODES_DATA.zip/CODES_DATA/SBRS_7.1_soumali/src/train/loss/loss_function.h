#ifndef LOSS_FUNCTION_H
#define LOSS_FUNCTION_H

#include <string>
#include "data/basic_data_types.h"

namespace Regularization {

class Function;

class LossFunction {
    public:
        LossFunction() { }

        virtual ~LossFunction() { }

        virtual std::string Name() const = 0;
        /**
         * It evaluates the loss function
         */
        virtual Value Eval(const Value value, const Value target) const = 0;
        virtual Value EvalDerivative(const Value value, const Value target) const = 0;
        virtual LossFunction* Clone() = 0;

        // Converts a value in the [0,1] interval into the [-1,1] one.
        static inline Value MAP_TO(const Value val) {
            return static_cast<Value> (val * 2.0 - 1.0);
        }

        // Converts a value in the [-1,1] interval into the [0,1] one.
        static inline Value MAP_FROM(const Value val) {
            return static_cast<Value> ((val + 1.0) * 0.5);
        }
};  // end LossFunction

// A null loss that returns the input value.
class IdentityLossFunction : public LossFunction {
    virtual std::string Name() const;
    virtual Value Eval(const Value value, const Value /* target */ ) const;
    virtual Value EvalDerivative(const Value value, const Value /* target */ ) const;
    virtual LossFunction* Clone();
};  // end IdentityLossFunction

}  // end namespace Regularization
#endif /* LOSS_FUNCTION_H */
