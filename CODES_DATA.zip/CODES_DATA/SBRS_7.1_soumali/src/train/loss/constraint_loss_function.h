#ifndef CONSTRAINT_LOSS_FUNCTION_H
#define CONSTRAINT_LOSS_FUNCTION_H

#include "train/loss/loss_function.h"


namespace Regularization {

class ConstraintLossFunction : public LossFunction
{
    public:
	    ConstraintLossFunction();
        ~ConstraintLossFunction();

        Value Eval(const Value value, const Value target) const;
        Value EvalDerivative(const Value value, const Value target) const;
        virtual std::string Name() const { return "CONSTRAINT"; }
        virtual LossFunction* Clone() {
            return new ConstraintLossFunction();
        }
}; // end ConstraintLossFunction

} // end Regularization
#endif /* CONSTRAINT_LOSS_FUNCTION_H */
