/*
 * loss_function.cc
 *
 *  Created on: Nov 8, 2017
 *      Author: michi
 */
#include "train/loss/loss_function.h"

namespace Regularization {
std::string IdentityLossFunction::Name() const {
    return "IDENTITY";
}

Value IdentityLossFunction::Eval(const Value value, const Value target ) const {
    return value;
}

Value IdentityLossFunction::EvalDerivative(const Value value, const Value target) const {
    return 1.0;
}

LossFunction* IdentityLossFunction::Clone() {
    return new IdentityLossFunction();
}

}  // end Regularization
