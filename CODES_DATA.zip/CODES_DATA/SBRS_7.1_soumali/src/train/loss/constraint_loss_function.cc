#include "train/loss/constraint_loss_function.h"


namespace Regularization {

/*******************************************
 *
 * ConstraintLossFunction
 *
 *******************************************/
ConstraintLossFunction::ConstraintLossFunction() { }

/**
 * Destructor
 **/
ConstraintLossFunction::~ConstraintLossFunction() {
}

/**
 * Eval.
 **/
Value ConstraintLossFunction::Eval(const Value value, const Value target) const {
    const Value diff = target - value;
    return (diff > 0 ? diff : 0);
}

/**
 * Eval derivative with argument  dL/dphi
 **/
Value ConstraintLossFunction::EvalDerivative(const Value value, const Value target) const {
    const Value diff = target - value;
    return (diff > 0 ? -1 : 0);
}
}  // end Regularization
