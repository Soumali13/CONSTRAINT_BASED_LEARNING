#ifndef BILATERAL_HINGE_LOSS_FUNCTION_H
#define BILATERAL_HINGE_LOSS_FUNCTION_H

#include "train/loss/loss_function.h"

namespace Regularization
{

/*
\        /
 \      /
  \    /
   \  /
    \/
 */
class BilateralHingeLossFunction : public LossFunction
{
    public:
        BilateralHingeLossFunction(Value threshold_, // where becomes zero
                                   Value slope_before_threshold_, // value at x=0
                                   Value slope_after_threshold_); // slope after threshold.
        ~BilateralHingeLossFunction();

        Value Eval(const Value value, const Value target) const;
        Value EvalDerivative(const Value value, const Value target) const;
        virtual std::string Name() const { return "BILATERAL_HINGE"; }
        virtual LossFunction* Clone() {
            return new BilateralHingeLossFunction(this->threshold,
                    this->slope_before_threshold,
                    this->slope_after_threshold);
        }

    protected:
        Value threshold;
        Value slope_before_threshold;
        Value slope_after_threshold;
}; // end BilateralHingeLossFunction
} // end Regularization
#endif /* BILATERAL_HINGE_LOSS_FUNCTION_H */
