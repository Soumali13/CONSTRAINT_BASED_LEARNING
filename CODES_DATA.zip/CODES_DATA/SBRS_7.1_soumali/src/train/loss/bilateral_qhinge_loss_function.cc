#include "train/loss/bilateral_qhinge_loss_function.h"
#include "utils/general.h"

#include <cmath>

namespace Regularization
{

/*******************************************
 *
 * BilateralQHingeLossFunction
 *
 *******************************************/
BilateralQHingeLossFunction::BilateralQHingeLossFunction(Value threshold_,
        Value slope_before_threshold_,
        Value slope_after_threshold_) :
    threshold(threshold_), slope_before_threshold(slope_before_threshold_),
    slope_after_threshold(slope_after_threshold_)
{
    CHECK_GE(slope_before_threshold, static_cast<Value> (0.0));
}

/**
 * Destructor
 **/
BilateralQHingeLossFunction::~BilateralQHingeLossFunction()
{
}

/**
 * Eval with argument [1 - f(x)*y]^2
 **/
Value BilateralQHingeLossFunction::Eval(const Value value, const Value target) const
{
    Value diff = threshold - value * target;
    Value result = static_cast<Value>(0);

    if (diff >= static_cast<Value>(0))
        result = std::pow(diff, 2) * slope_before_threshold;

    else
        result = - std::pow(diff, 2) * slope_after_threshold;

    //NOTE: output of quadratic loss is in [0,4]. This remaps in [0,1]
    return (result / 4);
}

/**
 * Eval derivative with argument dL/df=-0.5*y*(1 - f(x)*y)
 **/
Value BilateralQHingeLossFunction::EvalDerivative(const Value value, const Value target) const
{
    Value diff = threshold - value * target;
    Value result = static_cast<Value>(0);

    if (diff >= static_cast<Value>(0))
        result = - target * diff * slope_before_threshold;

    else
        result = target * diff * slope_after_threshold;

    // NOTE: remaps the output
    return (result / 4);
}

}
