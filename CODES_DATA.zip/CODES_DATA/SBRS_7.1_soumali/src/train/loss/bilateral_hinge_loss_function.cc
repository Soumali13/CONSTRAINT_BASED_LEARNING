#include "train/loss/bilateral_hinge_loss_function.h"
#include "train/loss/approx_logistic_loss_function.h"
#include "utils/general.h"


namespace Regularization
{

/*******************************************
 *
 * BilateralHingeLossFunction
 *
 *******************************************/
BilateralHingeLossFunction::BilateralHingeLossFunction(Value threshold_,
        Value slope_before_threshold_,
        Value slope_after_threshold_) :
    threshold(threshold_), slope_before_threshold(slope_before_threshold_),
    slope_after_threshold(slope_after_threshold_) {
    CHECK_GE(threshold, static_cast<Value > (0.0));
    CHECK_GE(slope_before_threshold, static_cast<Value > (0.0));
}

/**
 * Destructor
 **/
BilateralHingeLossFunction::~BilateralHingeLossFunction()
{
}

/**
 * Eval with argument [1 - f(x)*y]
 **/
Value BilateralHingeLossFunction::Eval(const Value value, const Value target) const
{
    Value diff = threshold - value * target;
    Value result = static_cast<Value>(0);

    if (diff > static_cast<Value>(0))
        result = diff * slope_before_threshold;
    else
        result = - diff * slope_after_threshold;

    // NOTE: The output of hinge loss is in [0,2]. This remaps value in [0,1]
    return (result / 2);
}

/**
 * Eval derivative with argument  dL/df=-y
 **/
Value BilateralHingeLossFunction::EvalDerivative(
    const Value value, const Value target) const {
  Value ret = static_cast<Value>(0);
  const Value diff = value * target - threshold;
  if (diff >= static_cast<Value>(0))
    ret = target * slope_after_threshold;
  else
    ret = -target * slope_before_threshold;
  // std::cout << "RET " << ret << " DIFF " << diff << " THR " << threshold << " VAL " << value << " TARGET " << target << " SLOPE " << slope_after_threshold << std::endl;

  return ret;
}

}  // end Regularization
