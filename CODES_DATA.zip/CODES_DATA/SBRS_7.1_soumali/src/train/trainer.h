/*
 * File:   base_trainer.h
 * Author: tore
 *
 * Created on September 23, 2011, 11:54 AM
 */

#ifndef BASE_TRAINER_H
#define	BASE_TRAINER_H

#include <iostream>

#if __NO_STD_C11__ > 0
#include <tr1/unordered_map>
#else
#include <unordered_map> 
#endif
#include <vector>

#include "classifier/classifier.h"
#include "constraints/FOL_formula_constraint.h"
#include "train/options.h"


namespace Regularization {

class DatasetConstraint;
class BaseClassifier;
class FOLKnowledgeBase;
class Dataset;
class Examples;

class Trainer {
    public:
        Trainer(BaseClassifier* classifier_,  // may be internally reallocated.
                const Predicates& predicates,
                const FOLKnowledgeBase& FOL_KnowledgeBase,
                const TrainOptions& options_,
                const Dataset* training_dataset,
                const Examples* training_examples);
        virtual ~Trainer() {
            if (parameters)
                delete parameters;
        }

        // Train the classifier. This is the how this is the only public method of this interface.
        virtual void Train();

        typedef std::map<std::string, DatasetConstraint*> ConstraintsSet;
        typedef std::vector<DatasetConstraint*> ActivatedConstraints;

    protected:
        ConstraintsSet learn_constraint_set;
        BaseClassifier* classifier;
        // Copied from classifier::LearnIterator for easier omp parallelization.
        std::vector<BaseClassifier::LearnIterator::Element> learn_functions;

        /* The train parameters, this data structure is intended to be immutable once
         * initialized. Please insert all information changing during training in
         * TrainStatus.
         */
        struct TrainParameters
        {
            const ConstraintsSet& constraints_set;
            const TrainOptions::ConstraintsWeights& initial_constraints_weights;
            const LossFunction& labeled_loss_function;
            const LossFunction& constraint_loss_function;
        	Value lambda_labeled;
        	std::map<std::string,Value> lambda_labeled_predicate;
            Value lambda_regularization;
            Value lambda_constraints;
            Value initial_learning_rate;
            Value initial_learning_rate_for_constraints;
            Value increase_learning_rate;
            Value decrease_learning_rate;
            Value min_learning_rate;
            Value max_learning_rate;
            int max_iterations;
            Value min_gradient;
            Value min_total_error;
            Value min_delta_error;
            int iteration_start_constraints;
            int iteration;
            TrainOptions::LEARNING_TYPE learning_type;
            bool normalize_gradient;
            int iterations_x_add_constraints;
            const Dataset* dataset;
            const Examples* examples;
            const Dataset* crossvalidation_dataset;    // used only if not empty
            const Examples* crossvalidation_examples;  // used only if not empty
            int crossvalidation_iterations;
            const std::string metric;
            const bool useMicroStatistics;
            const double stochastic_portion;
            const bool predicate_lambda;
            const bool save_lowest_error_model;
            std::string output_dir;

            TrainParameters(const ConstraintsSet& constraints_set_,
            				const TrainOptions::ConstraintsWeights& initial_constraints_weights_,
                            const LossFunction& labeled_loss_function_,
                            const LossFunction& constraint_loss_function_,
				        	const Value lambda_labeled_,
				        	const std::map<std::string,Value> lambda_labeled_predicate_,
                            const Value lambda_regularization_,
                            const Value lambda_constraints_,
                            const Value learning_rate_,
                            const Value learning_rate_for_constraints_,
                            const Value increase_learning_rate_,
                            const Value decrease_learning_rate_,
                            const Value min_learning_rate_,
                            const Value max_learning_rate_,
                            const int max_iterations_,
                            const Value min_gradient_,
                            const Value min_total_error_,
                            const Value min_error_constraints_,
                            const int iteration_start_constraints_,
                            const TrainOptions::LEARNING_TYPE learning_type_,
                            const bool normalize_gradient_,
                            const int iterations_x_add_constraints_,
                            const Dataset* dataset_,
                            const Examples* examples_,
                            const Dataset* crossvalidation_dataset_,    // used only if not empty
                            const Examples* crossvalidation_examples_,  // used only if not empty
                            const int crossvalidation_iterations_,
                            const std::string& metric_,
                            const bool useMicroStatistics_,
                            const double stochastic_portion_,
				            const bool predicate_lambda_,
                            const bool save_lowest_error_model_,
                            const std::string& output_dir_);
            void CheckSettings() const;
            bool SaveToStream(std::ostream& os) const;
            std::string ToString() const;
        };  // end TrainParameters

        /*
         * The actual train status, this keeps track of the evolution of the training.
         * Will be declared two kind of train status. One GlobalStatus that take in
         * consideration the global status of the learning process during each
         * iteration, and a Status for each function to learn that stores information
         * (such as errors) for the specific function during each iteration
         */
        class TrainStatus {
          public:
            // The actual value used for the lambda_constraint.
            Value lambda_constraints;
            Value gradient_module;
            // learning rates
            Value learning_rate;
            Math::Vector<Value> rgd_learning_rate;
            Math::Vector<Value> rgd_delta_weights;
            Value error;
            Value previous_error;
            Value old_error;
            Value labeled_error;
            Value previous_labeled_error;
            Value regularization_error;
            Value previous_regularization_error;
            Value constrained_error;
            Value previous_constrained_error;
            int iteration;
            // Elements to deal with the incremental adding of constraints
            int iterations_x_lambda_constraints_counter;
            unsigned int constraints_order_list_considered_elements;
            time_t starttime_in_sec;

            // The map of weights (lambda) of each constraint, it can be more safely accessed
            // via GetConstraintWeight().
            // These are currently useless as there is already a per-constraint weight that is
            // directly baked into the FOLFormula.
            // However we want to support in the future constraint weight learning, which will
            // be based on this map.
            std::map<std::string, Value> constraint_weights;

            // metric constraint->Error
            typedef std::map<std::string, Value> ConstrainErrors;
            ConstrainErrors costrained_errors;
            ConstrainErrors training_set_costrained_errors;

            // Current priority of the constraints
            // NOTE: used only in active teaching
            unsigned int learning_stage;

            // Store the best results on cross-validation during training.
            // pair<Iteration, map<metric, result>
            std::pair<int, std::map<std::string, Value> > best_crossvalidation;
            BaseClassifier* best_crossvalidation_model;

            Value saved_model_lowest_error;
            BaseClassifier* lowest_error_model;

            TrainStatus();
            TrainStatus(const Value lambda_constraints_, const Value learning_rate_);
            void Init();
            void ResetLowestErrorModel();
            ~TrainStatus();

            inline Value GetConstraintWeight(const std::string& constraint_name) const {
                std::map<std::string, Value>::const_iterator iter = constraint_weights.find(constraint_name);
                CHECK(iter != constraint_weights.end());
                return iter->second;
            }

            inline Value GetConstraintError(const std::string& constraint_name) const {
                ConstrainErrors::const_iterator iter = costrained_errors.find(constraint_name);
                CHECK(iter != costrained_errors.end());
                return iter->second;
            }

            static const Value ConstraintTrainingSetErrorNoValue;
            inline Value GetConstraintTrainingSetError(const std::string& constraint_name) const {
                ConstrainErrors::const_iterator iter = training_set_costrained_errors.find(constraint_name);
                return (iter != training_set_costrained_errors.end() ?
                        iter->second : ConstraintTrainingSetErrorNoValue);
            }
        };  // end TrainStatus

        // The actual parameters for the global optimizer.
        const TrainParameters* parameters;

        inline const TrainParameters& Parameters() const {
            CHECK_NE_NULL(parameters);
            return *parameters;
        }

        /*
         * The initial Train status, this is to what all train statuses are defaulting
         * to when Clear() is called.
         */
        TrainStatus initial_status;

        // The actual status for the global optimizer.
        TrainStatus global_status;

        /*
         * Map storing the statuses of the optimizers of the single functions.
         * The key is the name of function in the functionsContainer of the Classifier,
         * the value is the TrainStatus associated to the that function
         */
        typedef std::map<Function::ID, TrainStatus> StatusMapByFunction;
        StatusMapByFunction status_by_function;
        // Vector of train status, used in omp parallelizations.
        typedef std::vector<TrainStatus*> StatusVectorByFunction;
        StatusVectorByFunction status_by_function_vec;

        inline const TrainStatus& GetStatus() const
        {
            return global_status;
        }

        inline TrainStatus* GetMutableStatus()
        {
            return &global_status;
        }

        // Get the train status for a function.
        // Exits if the status is not already set.
        inline const TrainStatus& GetTrainStatus(const Function::ID& functionName) const
        {
            StatusMapByFunction::const_iterator iter = status_by_function.find(functionName);
            CHECK(iter != status_by_function.end());
            return iter->second;
        }

        // Get the mutable train status for a function.
        // Exits if the status is not already set.

        inline TrainStatus* GetMutableTrainStatus(const Function::ID& functionName)
        {
            StatusMapByFunction::iterator iter = status_by_function.find(functionName);
            CHECK(iter != status_by_function.end());
            return &(iter->second);
        }

        virtual void LogTrainStatus(std::ostream& trainer_stream);

        /*
         * The map of the derivatives value for each weights of each function. The key
         * is the name while the value is a vector of derivatives.
         */
        FOLFormulaConstraint::PerFunctionDerivative derivatives;
        FOLFormulaConstraint::PerFunctionDerivative previous_derivatives;
        // Breakdown of the single error function components.
        FOLFormulaConstraint::PerFunctionDerivative regularization_derivatives;
        FOLFormulaConstraint::PerFunctionDerivative labeled_derivatives;
#if __ACTIVATE_OPENMP_TRAINER__ > 1
        // One PerFunctionDerivative per thread, this allows parallel optimization
        // across threads.
        std::vector<FOLFormulaConstraint::PerFunctionDerivative> thread_local_constraint_derivatives;
#endif
        FOLFormulaConstraint::PerFunctionDerivative constraint_derivatives;

        // Vector of constraints
        // NOTE: in Active teaching it is filled with constraints based on their priority
        ActivatedConstraints activated_constraints;

        // The classes to use for validation. If empty all classes are used.
        std::set<Function::ID> classes_for_test;

        /*************************************************************************
         * Active Teaching
         *************************************************************************/
        virtual void MaybeActivateConstraints();

        /*************************************************************************
         * Checks
         *************************************************************************/
        /**
         * Check if the constraints part will ever be activated at any training
         * iteration.
         */
        virtual bool ConsiderConstraintsPart() const;

        /**
         * Check if the constraints part must be evaluated at this training
         * iteration.
         */
        virtual bool ConsiderConstraintsPartNow() const;

        /**
         * Determines whether train should be stopped because it reached convergence.
         */
        virtual bool ShouldStop();

        /*
         * Cross validation methods
         */
        virtual bool ShouldRunCrossvalidation() const;
        virtual void MaybeRunCrossvalidation(std::ofstream& os);
        virtual bool MaybeSaveLowestErrorModel();

        /*
         * Learning rate management for weight optimization
         */
        virtual void UpdateLearningRatesAndWeights();
        virtual void UpdateLearningRatesAndWeightsGD();
        virtual void UpdateLearningRatesAndWeightsRGD();
        virtual void UpdateLearningRatesAndWeightsRGDNBT();

        virtual void ResetLearningRates();
        virtual void ResetLearningRatesGD();
        virtual void ResetLearningRatesAndWeightsRGD();
        virtual void ResetLearningRatesAndWeightsRGDNBT();

        // Update the gradient module.
        virtual void UpdateGradientModule();
        virtual void MaybeNormalizeGradients();

        /***********************************************
         * Init/End the training sessions.
         **********************************************/
        virtual void Init();
        virtual void End(std::ofstream& os);

        /************************************************
         * Error / Derivative Error Evaluation
         ***********************************************/
        // Updates the value for error and previous_error, adjusts the learning rates.
        // If re_evaluate_constraints==true, the constraints are re-evaluated in the method,
        // otherwise the cached values in status are used for speed: constraint errors are
        // already computed when assessing the gradient.
        virtual void EvalAndUpdateError(const bool evaluate_constraints);
        virtual void EvalAndUpdateErrorByFunction(const LearnFunction& function);

        // Evaluates the value of the constraint part of the cost function on the
        // training set.
        virtual Value EvalConstraintsErrorPart();

        // Reset the gradients.
        virtual void ResetGradients();

        // Compute the i^th iteration on the k^th function.
        virtual void GetGradients();

        // Evaluates the gradient of the labeled part of cost function.
        virtual void GetLabeledErrorGradients();

        // Evaluates the gradient of the regularization part of cost function.
        virtual void GetRegularizationErrorGradients();

        // Evaluates the gradient of the constraint part of cost function.
        virtual void GetConstraintErrorGradients();

        // Helper function to accumulate the gradient by function from a source to a destination.
        void AccumulateGradientsHelper(const FOLFormulaConstraint::PerFunctionDerivative& src,
                                       FOLFormulaConstraint::PerFunctionDerivative* dest);
        // Helper function to accumulate the gradient by function from a source to a destination.
        void ResetGradientsHelper(FOLFormulaConstraint::PerFunctionDerivative* dest);

        // Print the results of constraints weight optimization
        virtual bool SaveConstraintsWeightsToStream(std::ofstream& os) const;

        // Compute and print to file the constraint error of the training set labels.
        virtual void ComputeAndSaveTrainingSetConstraintErrors(
                const Predicates& predicates, const FOLKnowledgeBase& FOL_KnowledgeBase);
        // Read the data printed by ComputeAnsSaveTrainingSetConstraintErrors.
        // Needs the constraint set to be built at the time of the call.
        virtual void ReadTrainingSetConstraintErrorsFromFile(const std::string& file);
}; // end BaseTrainer
}

#endif	/* BASE_TRAINER_H */

