/*
 * train_runner_helper.h
 *
 *  Created on: Dec 24, 2015
 *      Author: michi
 *  Utilities to perform train and model selection.
 *  These utilities are not intended to be a real library, or be externally used.
 *  They just where organizing common code called from the mains of the executables
 *  of the Regularization package.
 */

#ifndef TRAIN_RUNNER_HELPER_H_
#define TRAIN_RUNNER_HELPER_H_

#include <string>
#include <vector>
#include <map>
#include "data/dataset.h"
#include "data/examples.h"
#include "data/FOL_knowledge_base.h"
#include "data/predicates.h"
#include "train/options.h"
#include "train/trainer.h"
#include "utils/gtl_utils.h"


namespace Regularization {
class BaseClassifier;

namespace TrainRunnerHelper {
struct Data {
    Predicates predicates;
    Dataset training_data;
    Examples training_examples;
    FOLKnowledgeBase FOL_KnowledgeBase;
    TrainOptions options;
    Dataset* validation_data;
    ScopedPtr<Examples> validation_examples;
    Dataset* test_data;
    ScopedPtr<Examples> test_examples;
    Data();
    ~Data();
};

void LoadData(Data* data);

void GetCrossvalidationParams(const Data& data,
							  std::vector<std::map<std::string,Value>>* lambdas_labeled_per_predicate,
                              std::vector<Value>* lambdas_labeled,
                              std::vector<Value>* lambdas_regularization,
                              std::vector<Value>* lambdas_constraint);

std::map<std::string,Value> LoadFromFileRegularizers(std::string filename, const Data& data, const bool clear);
std::map<std::string,Value> LoadFromStreamRegularizers(std::istream& is, const Data& data, const bool clear);
BaseClassifier* RunTrain(
        const Data& data, std::string *output_summary, TrainOptions* best_options);
void RunConstraintVerification(const Data& data, const TrainOptions& options, const BaseClassifier* classifier);
void RunCollectiveClassificationAfterTrain(const Data& data, const TrainOptions& best_options,
        const BaseClassifier* best_classifier, std::string* output_summary);
}  // end TrainRunnerHelper
}  // end Regularization

#endif  /* TRAIN_RUNNER_HELPER_H_ */
