/*
 * trainer.cc
 *
 *  Created on: May 8, 2009
 *      Author: michi
 */

#if __ACTIVATE_OPENMP_TRAINER__ > 0
#include <omp.h>
#endif

#include "train/trainer.h"

#include <cmath>
#include <deque>
#include <iomanip>  // for setprecision
#include <limits>
#include <sstream>

#include "classifier/collective_classifier.h"
#include "classifier/test_utils/test_utils.h"
#include "constraints/constraints_factory.h"
#include "data/dataset.h"
#include "train/loss/loss_function.h"
#include "train/options.h"
#include "utils/general.h"
#include "utils/gflags/gflags/gflags.h"
#include "utils/file_utils.h"
#include "utils/gtl_utils.h"  // ScopedPtr
#include "utils/string_utils.h"
#include "utils/stl_utils.h"


// DECLARE_uint64(active_threads);

DECLARE_string(test_type);
DEFINE_bool(always_rgd_backtrack_on_sign_change, true,
            "If using RGD, the variant irgd_plus using backtracking only on "
            "higher error is enabled by setting this flag to false.");
DEFINE_bool(save_crossvalidation_roc_curves, false,
            "Save the roc curves during crossvalidation.");

DEFINE_bool(compute_and_set_aggregate_target, false,
            "The degree of satisfaction on the training data is computed for each "
            "constraint and then enforced during training.");
DEFINE_string(load_aggregate_target, "",
            "Read from file the degree of satisfaction on the training data.");
DECLARE_bool(normalize_constraints_by_cardinality);
DECLARE_string(restrict_test_to_classes);

using namespace std;

namespace Regularization {

/* static */
const Value Trainer::TrainStatus::ConstraintTrainingSetErrorNoValue = std::numeric_limits<Value>::lowest();

/**
 * TrainParameters Constructor
 */
Trainer::TrainParameters::TrainParameters(
        const ConstraintsSet& constraints_set_,
        const TrainOptions::ConstraintsWeights& initial_constraints_weights_,
        const LossFunction& labeled_loss_function_,
        const LossFunction& constraint_loss_function_,
		const Value lambda_labeled_,
		const std::map<std::string,Value> lambda_labeled_predicate_,
        const Value lambda_regularization_,
        const Value lambda_constraints_,
        const Value learning_rate_,
        const Value learning_rate_for_constraints_,
        const Value increase_learning_rate_,
        const Value decrease_learning_rate_,
        const Value min_learning_rate_,
        const Value max_learning_rate_,
        const int max_iterations_,
        const Value min_gradient_,
        const Value min_total_error_,
        const Value min_delta_error_,
        const int iteration_start_constraints_,
        const TrainOptions::LEARNING_TYPE learning_type_,
        const bool normalize_gradient_,
        const int iterations_x_add_constraints_,
        const Dataset* dataset_,
        const Examples* examples_,
        const Dataset* crossvalidation_dataset_,    // used only if not empty
        const Examples* crossvalidation_examples_,  // used only if not empty
        const int crossvalidation_iterations_,
        const string& metric_,
        const bool useMicroStatistics_,
        const double stochastic_portion_,
		const bool predicate_lambda_,
        const bool save_lowest_error_model_,
        const string& output_dir_) :
        constraints_set(constraints_set_),
        initial_constraints_weights(initial_constraints_weights_),
        labeled_loss_function(labeled_loss_function_),
        constraint_loss_function(constraint_loss_function_),
        lambda_labeled(lambda_labeled_),
		lambda_labeled_predicate(lambda_labeled_predicate_),
        lambda_regularization(lambda_regularization_),
        lambda_constraints(lambda_constraints_),
        initial_learning_rate(learning_rate_),
        initial_learning_rate_for_constraints(learning_rate_for_constraints_),
        increase_learning_rate(increase_learning_rate_),
        decrease_learning_rate(decrease_learning_rate_),
        min_learning_rate(min_learning_rate_),
        max_learning_rate(max_learning_rate_),
        max_iterations(max_iterations_),
        min_gradient(min_gradient_),
        min_total_error(min_total_error_),
        min_delta_error(min_delta_error_),
        iteration_start_constraints(iteration_start_constraints_),
        iteration(0),
        learning_type(learning_type_),
        normalize_gradient(normalize_gradient_),
        iterations_x_add_constraints(iterations_x_add_constraints_),
        dataset(dataset_),
        examples(examples_),
        crossvalidation_dataset(crossvalidation_dataset_),
        crossvalidation_examples(crossvalidation_examples_),
        crossvalidation_iterations(crossvalidation_iterations_),
        metric(metric_),
        useMicroStatistics(useMicroStatistics_),
        stochastic_portion(stochastic_portion_),
		predicate_lambda(predicate_lambda_),
        save_lowest_error_model(save_lowest_error_model_),
        output_dir(output_dir_) {
    // Cache the constraints internally. The pointers are owned externally.
    this->CheckSettings();
}

std::string Trainer::TrainParameters::ToString() const {
    std::ostringstream os;
    this->SaveToStream(os);
    return os.str();
}

bool Trainer::TrainParameters::SaveToStream(ostream& os) const {
    os << " initial_constraints_weights:"
       << StringUtils::MapToString(initial_constraints_weights, ",", ":", "")
       << " labeled_loss_function:" << labeled_loss_function.Name()
       << " constraint_loss_function:" << constraint_loss_function.Name()
       << " lambda_regularization:" << lambda_regularization
       << " lambda_constraints:" << lambda_constraints
       << " initial_learning_rate:" << initial_learning_rate
       << " initial_learning_rate_for_constraints:" << initial_learning_rate_for_constraints
       << " increase_learning_rate:" << increase_learning_rate
       << " decrease_learning_rate:" << decrease_learning_rate
       << " min_learning_rate:" << min_learning_rate
       << " max_learning_rate:" << max_learning_rate
       << " max_iterations:" << max_iterations
       << " min_gradient:" << min_gradient
       << " min_total_error:" << min_total_error
       << " min_delta_error:" << min_delta_error
       << " iteration_start_constraints:" << iteration_start_constraints
       << " learning_type:" << TrainOptions::LearningTypeToString(learning_type)
       << " normalize_gradient:" << normalize_gradient
       << " iterations_x_add_constraints:" << iterations_x_add_constraints
       << " crossvalidation_dataset:" << crossvalidation_dataset
       << " crossvalidation_iterations:" << crossvalidation_iterations
       << " metric:" << metric
       << " useMicroStatistics:" << useMicroStatistics
       << " stochastic_portion:" << stochastic_portion
	   << " predicate_lambda:" << predicate_lambda
       << " save_lowest_error_model:" << save_lowest_error_model;

	   if (predicate_lambda != true)
	   {
		  os << " lambda_labeled:" << lambda_labeled;
	   }
	   else
	   {
		   os << StringUtils::MapToString(lambda_labeled_predicate, ",", ":", "");
	   }
       os << endl;
    return true;
}

/**
 * TrainParameters Check
 */
void Trainer::TrainParameters::CheckSettings() const {
	if (predicate_lambda != true)
	{
		CHECK_GT(lambda_labeled, static_cast<Value>(0.0));
	}
	else
	{
		CHECK(!lambda_labeled_predicate.empty());
	}
    CHECK_GE(lambda_regularization, static_cast<Value>(0.0));
    CHECK_GT(initial_learning_rate, static_cast<Value>(0.0));
    CHECK_GE(increase_learning_rate, static_cast<Value>(1.0));
    CHECK_GT(decrease_learning_rate, static_cast<Value>(0.0));
    CHECK_GE(increase_learning_rate, decrease_learning_rate);
    CHECK_GE(max_iterations, 0);
    CHECK_GE(min_gradient, static_cast<Value>(0.0));
    CHECK_GE(min_total_error, static_cast<Value>(0.0));
    CHECK_GE(min_delta_error, static_cast<Value>(0.0));
    CHECK_GE(iteration_start_constraints, 0);
    CHECK_INE_RANGE(stochastic_portion, 0.0, 1.0);
    if (!constraints_set.empty()) {
        CHECK_GE(max_iterations, iteration_start_constraints);
    }
    CHECK(!output_dir.empty());
    // Check training dataset is not empty
    CHECK_NE_NULL(dataset);

    const string lt_str = TrainOptions::LearningTypeToString(learning_type);
    CHECK_NE(lt_str, string(""));
    CHECK_NE(lt_str, string("INVALID"));
}

/**
 * TrainStatus Constructors
 */
Trainer::TrainStatus::TrainStatus() {
    this->Init();
}

/**
 * TrainStatus Constructor
 */
Trainer::TrainStatus::TrainStatus(
        const Value lambda_constraints_, const Value learning_rate_) {
    this->Init();
    lambda_constraints = lambda_constraints_;
    learning_rate = learning_rate_;
}

/**
 * TrainStatus Init
 */
void Trainer::TrainStatus::Init() {
    lambda_constraints = static_cast<Value > (numeric_limits<int>::max());
    gradient_module = static_cast<Value>(0);
    learning_rate = static_cast<Value>(1);
    error = static_cast<Value> (numeric_limits<int>::max());
    previous_error = static_cast<Value>(numeric_limits<int>::max());
    old_error = static_cast<Value>(numeric_limits<int>::max());
    labeled_error = static_cast<Value>(numeric_limits<int>::max());
    previous_labeled_error = static_cast<Value>(numeric_limits<int>::max());
    regularization_error = static_cast<Value>(numeric_limits<int>::max());
    previous_regularization_error = static_cast<Value>(numeric_limits<int>::max());
    constrained_error = static_cast<Value>(0);
    previous_constrained_error = static_cast<Value>(numeric_limits<int>::max());
    iteration = static_cast<int>(0);
    iterations_x_lambda_constraints_counter = static_cast<int>(0);
    constraints_order_list_considered_elements = static_cast<int>(0);
    best_crossvalidation.first = static_cast<int>(0);
    best_crossvalidation_model = NULL;
    learning_stage = 1;
    saved_model_lowest_error = -1;
    lowest_error_model = NULL;
    time(&starttime_in_sec);
}

void Trainer::TrainStatus::ResetLowestErrorModel() {
    if (lowest_error_model) {
        delete lowest_error_model;
    }
    saved_model_lowest_error = -1;
    lowest_error_model = NULL;
}

Trainer::TrainStatus::~TrainStatus() {
    if (best_crossvalidation_model) {
        delete best_crossvalidation_model;
    }
    if (lowest_error_model) {
        delete lowest_error_model;
    }
}

Trainer::Trainer(BaseClassifier* classifier_,
                 const Predicates& predicates,
                 const FOLKnowledgeBase& FOL_KnowledgeBase,
                 const TrainOptions& options_,
                 const Dataset* training_dataset,
                 const Examples* training_examples) :
    classifier(classifier_),  // not owned
    parameters(NULL) {
  ConstraintsFactory::BuildConstraints(
              classifier, FOL_KnowledgeBase, *training_dataset, *training_examples,
              FOLFormula::LEARN, options_.GetConstraintsLossFunction(), &learn_constraint_set);

  // set the initial status
  parameters = new TrainParameters(
      learn_constraint_set,
      options_.GetConstraintWeights(), // initial_constraint_weights
      options_.GetLabeledLossFunction(),
      options_.GetConstraintsLossFunction(),
	  options_.GetLambdaLabeled(),
	  options_.GetLambdaLabeledPredicate(),
      options_.GetLambdaRegularization(),
      options_.GetLambdaConstraints(),
      options_.GetLearningRate(),
      options_.GetLearningRateForConstraints(),
      options_.GetIncreaseLearningRate(),
      options_.GetDecreaseLearningRate(),
      options_.GetMinLearningRate(),
      options_.GetMaxLearningRate(),
      options_.GetMaxIterations(),
      options_.GetMinGradientModule(),
      options_.GetTotalError(),
      options_.GetDeltaError(),
      options_.GetIterationStartConstraints(),
      options_.GetLearningType(),
      options_.GetNormalizeGradient(),
      options_.GetIterationsXAddConstraints(),
      training_dataset,
      training_examples,
      options_.GetCrossValidationDataset(), // used only if not empty
      options_.GetCrossValidationExamples(),
      options_.GetCrossValidationIterations(),
      options_.GetMetric(),
      options_.UseMicroStatistics(),
      options_.GetStochasticPortion(),
	  options_.GetPredicateLambdaStatus(),
      options_.GetSaveLowestTrainErrorModel(),
      options_.GetOutputDir());


  initial_status = TrainStatus(options_.GetLambdaConstraints(), options_.GetLearningRate());

  this->Init();

  // Training set aggregate data must be read or computed. Do not allow both for the moment.
  CHECK_FALSE(FLAGS_compute_and_set_aggregate_target && !FLAGS_load_aggregate_target.empty());
  if (FLAGS_compute_and_set_aggregate_target) {
      this->ComputeAndSaveTrainingSetConstraintErrors(predicates, FOL_KnowledgeBase);
  }
  if (!FLAGS_load_aggregate_target.empty()) {
      this->ReadTrainingSetConstraintErrorsFromFile(FLAGS_load_aggregate_target);
  }
}

void Trainer::ComputeAndSaveTrainingSetConstraintErrors(
        const Predicates& predicates, const FOLKnowledgeBase& FOL_KnowledgeBase) {
    CHECK(!Parameters().output_dir.empty());
    const string& trainer_path = Parameters().output_dir;
    FileUtils::MakePathOrDie(trainer_path);

    const string file = trainer_path + "/training_set_constraint_errors.dat";
    ofstream os(file.c_str());
    CHECK_WITH_MESSAGE(os.good(), " Can not open the trainer log " + file);

    // Build a collective classifier with only map functions from the example data.
    // This is used to check how much the training data respects the constraints.
    CollectiveClassifier cc(NULL, predicates, FOL_KnowledgeBase, *Parameters().dataset, Parameters().examples);
    int i = 0;
    for (ConstraintsSet::const_iterator it = Parameters().constraints_set.begin();
            it != Parameters().constraints_set.end(); ++it, ++i) {
        // Clone the constraint and replace the classifier with a collective classifier initialized only from
        // the train data.
        ScopedPtr<DatasetConstraint> c(it->second->Clone());
        c->ResetClassifier(&cc);
        const std::string& constraintName = c->GetName();  // or it->first
        const Value constraint_weight = GetStatus().GetConstraintWeight(constraintName);
        const Value constraint_error = c->Eval(constraint_weight, NULL) /
                (FLAGS_normalize_constraints_by_cardinality ? 1.0 : c->GetCardinality());
        // TODO(michi): fix the normalization that is not correct when GetCardinality() != max_constraint_value
        // (e.g. for existential quantifiers)
        GetMutableStatus()->training_set_costrained_errors[it->first] =
                Math::Max(static_cast<Value>(0) /* to avoid rounding errors */ , constraint_error);
        VMESSAGE(1, "TrainingSet error of rule " << constraintName << " = " << constraint_error);
        os << i <<  " " << constraintName << " " << constraint_error << endl;
    }
    os.close();
}

// Read the data printed by MaybeComputeAnsSaveTrainingSetConstraintErrors.
// Needs the constraint set to be built at the time of the call.
// If the relative error is low (close to 0) for a constraint, it means that
// the training set is perfectly respecting the constraints.
// If the relative error is high (close to 1), it means that the training set
// is not respecting the constraints at all.
void Trainer::ReadTrainingSetConstraintErrorsFromFile(const std::string& file) {
    std::deque<std::string> lines = FileUtils::ReadFileByLine(file);
    for (unsigned int i = 0; i < lines.size(); ++i) {
        const Value constraint_error = StringUtils::ReadLastElementOrDie<Value>(lines[i], ' ');
        const std::string::size_type start = lines[i].find(' ') + 1;
        const std::string::size_type end = lines[i].find_last_of(' ');
        const std::string constraintName = lines[i].substr(start, end - start);
        VMESSAGE(1, "TrainingSet error of rule " << constraintName << " = " << constraint_error);
        GetMutableStatus()->training_set_costrained_errors[constraintName] = constraint_error;
    }
}

/**
 * Init the trainer
 */
void Trainer::Init() {
    CHECK_NE_NULL(classifier);

    global_status = initial_status;

    // Cache the target matrix.
    // Resets the train status for the functions to learn.
    Classifier::LearnIterator iter(*classifier);
    status_by_function_vec.clear();
    status_by_function_vec.reserve(classifier->Size());
    while (iter.HasNext()) {
        const Classifier::LearnIterator::Element* el = iter.GetNext();
        const Function::ID& fid = el->first;
        const LearnFunction* lfunction = el->second;
        learn_functions.push_back(*el);

        // copy from the first TrainStatus
        status_by_function[fid] = initial_status;
        status_by_function_vec.push_back(&(status_by_function[fid]));

        // initialize the vector of learning rates
        if (Parameters().learning_type == TrainOptions::RGD) {
            status_by_function[fid].rgd_learning_rate.Init(lfunction->Size());
            status_by_function[fid].rgd_delta_weights.Init(lfunction->Size());
        } else if (Parameters().learning_type == TrainOptions::RGDNBT) {
            status_by_function[fid].rgd_learning_rate.Init(lfunction->Size());
        }
    }
    this->ResetLearningRates();

    /*
     * Set up all the scratch vectors used to perform training.
     */
    derivatives.clear();
    previous_derivatives.clear();
    regularization_derivatives.clear();
    labeled_derivatives.clear();
    constraint_derivatives.clear();
#if __ACTIVATE_OPENMP_TRAINER__ > 1
    thread_local_constraint_derivatives.resize(omp_get_num_threads());
#endif
    iter.Rewind();
    while (iter.HasNext()) {
        const Classifier::LearnIterator::Element* el = iter.GetNext();
        const LearnFunction* lfunction = el->second;
        derivatives[el->first] = Math::Vector<Value>(lfunction->Size());
        regularization_derivatives[el->first] = Math::Vector<Value>(lfunction->Size());
        labeled_derivatives[el->first] = Math::Vector<Value>(lfunction->Size());
        constraint_derivatives[el->first] = Math::Vector<Value>(lfunction->Size());
#if __ACTIVATE_OPENMP_TRAINER__ > 1
        for (int i = 0; i < omp_get_num_threads(); ++i) {
            thread_local_constraint_derivatives[i][el->first] = Math::Vector<Value>(lfunction->Size());
        }
#endif
        if (Parameters().learning_type == TrainOptions::RGD ||
            Parameters().learning_type == TrainOptions::RGDNBT) {
            previous_derivatives[el->first] = Math::Vector<Value>(lfunction->Size());
        }
    }
    for (ConstraintsSet::const_iterator it = Parameters().constraints_set.begin();
         it != Parameters().constraints_set.end(); ++it) {
        TrainOptions::ConstraintsWeights::const_iterator rt =
                Parameters().initial_constraints_weights.find(it->first);
        if (rt != Parameters().initial_constraints_weights.end())
            GetMutableStatus()->constraint_weights[it->first] = rt->second;
        else
            GetMutableStatus()->constraint_weights[it->first] = Parameters().lambda_constraints;

        GetMutableStatus()->costrained_errors[it->first] = static_cast<Value>(0);
    }

    if (!FLAGS_restrict_test_to_classes.empty()) {
        StringUtils::SplitToSetByType(FLAGS_restrict_test_to_classes, &classes_for_test, ",", true);
    }
}

/**
 * Check if the constraints part must be evaluated at this training iteration.
 */
bool Trainer::ConsiderConstraintsPartNow() const
{
    // check if it is the time to start training using constraints
    return (!Parameters().constraints_set.empty() && GetStatus().lambda_constraints > 0.0 &&
            GetStatus().iteration >= Parameters().iteration_start_constraints);
}

/**
 * Check if the constraints part must be evaluated at some training iteration.
 */
bool Trainer::ConsiderConstraintsPart() const
{
    return (!Parameters().constraints_set.empty() &&
            Parameters().max_iterations >= Parameters().iteration_start_constraints);
}

/***************************************************************************
 * Learning rates for weights optimizer
 ***************************************************************************/
void Trainer::UpdateLearningRatesAndWeights() {
    if (this->ConsiderConstraintsPartNow() &&
        GetStatus().iteration == Parameters().iteration_start_constraints) {
        // Constraints are used for the first time
        this->ResetLearningRates();
    }

    /* Gradient descent, update the weights in all the functions: when using
     * the constraints the update step must be performed after the delta-w
     * of all functions have been evaluated, since the modification of a
     * function influence the evaluation of the constraint part.
     */
    if (Parameters().learning_type == TrainOptions::RGD) {
        this->UpdateLearningRatesAndWeightsRGD();
    } else if (Parameters().learning_type == TrainOptions::RGDNBT) {
        this->UpdateLearningRatesAndWeightsRGDNBT();
    } else {  // Update the learning rates only for GD
        this->UpdateLearningRatesAndWeightsGD();
    }
}

void Trainer::UpdateLearningRatesAndWeightsGD() {
    // delta error
    Value delta_error = static_cast<Value>(0.0);

    if (GetStatus().previous_error != static_cast<Value>(0.0))
        delta_error = GetStatus().error - GetStatus().previous_error;

    // adjust the global learning rates
    if (delta_error < 0) {
        // increase
        GetMutableStatus()->learning_rate *= Parameters().increase_learning_rate;
    } else {
        // decrease
        GetMutableStatus()->learning_rate *= Parameters().decrease_learning_rate;
    }

    // This prevents the learning rate from going too high
    // used during the first phase without constraint and at the end of the
    // optimization process
    if (Parameters().max_learning_rate > static_cast<Value>(0.0)) {
        // if less than 0 => no max.
        GetMutableStatus()->learning_rate = Math::Min(
                GetStatus().learning_rate,
                Parameters().max_learning_rate);
    }

    if (Parameters().min_learning_rate > static_cast<Value>(0.0)) {
        // if less than 0, => no min.
        // This prevents the learning rate from going too low.
        GetMutableStatus()->learning_rate = Math::Max(
                GetStatus().learning_rate,
                Parameters().min_learning_rate);
    }

    // Now update the weights.
#if __ACTIVATE_OPENMP_TRAINER__ > 0
#pragma omp parallel
#endif
    {
#if __ACTIVATE_OPENMP_TRAINER__ > 0
#pragma omp for schedule(dynamic)
#endif
        for (unsigned int i = 0; i < learn_functions.size(); ++i) {
            const Function::ID& fid = learn_functions[i].first;
            LearnFunction* lfunction = learn_functions[i].second;

            // applies the global learning rate
            // MESSAGE("ID " << fid << " UPDATE1 " << derivatives[fid].ToString());
            derivatives[fid].MultiplyInPlace(GetStatus().learning_rate);

            // update the weights
            lfunction->Update(derivatives[fid]);
            // MESSAGE("ID " << fid << " UPDATE2 " << derivatives[fid].ToStringAsSparse());
            // MESSAGE("ID " << fid << " VALUES " << lfunction->Get().ToStringAsSparse());
        }
    }  // end parallel section
}

void Trainer::UpdateLearningRatesAndWeightsRGD() {
    Value sum_active_learning_rates = 0;
    Value num_active_learning_rates = 0;

    // for each function
#if __ACTIVATE_OPENMP_TRAINER__ > 0
#pragma omp parallel shared(sum_active_learning_rates,num_active_learning_rates)
#endif
    {
#if __ACTIVATE_OPENMP_TRAINER__ > 0
#pragma omp for reduction(+:sum_active_learning_rates,num_active_learning_rates) schedule(dynamic)
#endif
        for (unsigned int l = 0; l < learn_functions.size(); ++l) {
            const Function::ID& functionName = learn_functions[l].first;
            LearnFunction* lfunction = learn_functions[l].second;

            TrainStatus* status = this->GetMutableTrainStatus(functionName);

            Value delta_weight = static_cast<Value>(0);
            for (Index i = 0; i < lfunction->Size(); ++i) {
                const Value der_val = derivatives[functionName].Get(i);
                if (der_val == 0)  continue;

                const Value previous_der_val = previous_derivatives[functionName].Get(i);
                if (der_val * previous_der_val > static_cast<Value>(0.0)) {
                    // increase
                    status->rgd_learning_rate.Mult(i, Parameters().increase_learning_rate);
                    if (Parameters().max_learning_rate > static_cast<Value>(0.0) &&
                        status->rgd_learning_rate[i] > Parameters().max_learning_rate) {
                        status->rgd_learning_rate.Set(i, Parameters().max_learning_rate);
                    }

                    // computed the delta_weight: sign (D E/D w)
                    delta_weight = Math::Sign(der_val) * status->rgd_learning_rate[i];

                    // store the current weights vector for a new iteration
                    status->rgd_delta_weights.Set(i, delta_weight);
                    // update the value
                    lfunction->Update(i, delta_weight);
                } else if (der_val * previous_der_val < static_cast<Value>(0.0)) {
                    // decrease
                    status->rgd_learning_rate.Mult(i, Parameters().decrease_learning_rate);
                    if (Parameters().min_learning_rate > static_cast<Value>(0.0) &&
                            status->rgd_learning_rate[i] < Parameters().min_learning_rate) {
                        status->rgd_learning_rate.Set(i, Parameters().min_learning_rate);
                    }

                    // Whether we should restore the old weight values when the sign changes.
                    // This is always true for normal Rprop and only when the global error
                    // got worse for the Rprop+ algorithm.
                    const bool backtrack =
                            (FLAGS_always_rgd_backtrack_on_sign_change ||
                             GetStatus().error > GetStatus().previous_error);

                    // update the weights with the previous value
                    if (backtrack) {
                        lfunction->Update(i, -status->rgd_delta_weights[i]);
                    }
                    // reset the derivatives
                    derivatives[functionName].Set(i, static_cast<Value>(0));
                } else {
                    // derivatives[functionName].Get(i) * previous_derivatives[functionName].Get(i) = 0
                    // computed the delta_weight: sign (D E/D w)
                    delta_weight = Math::Sign(der_val) * status->rgd_learning_rate[i];
                    if (delta_weight != 0.0) {
                        // store the previous weight vector
                        status->rgd_delta_weights.Set(i, delta_weight);
                        // update the weights
                        lfunction->Update(i, delta_weight);
                    }
                }
                sum_active_learning_rates += status->rgd_learning_rate[i];
                ++num_active_learning_rates;
            }

            // copy the current derivatives in the previous one for new iteration
            previous_derivatives[functionName].Copy(derivatives[functionName]);
        }
    }  // end parallel section

    // update the average learning rate
    GetMutableStatus()->learning_rate = (num_active_learning_rates > 0 ?
                                         sum_active_learning_rates / num_active_learning_rates :
                                         0);
}

void Trainer::UpdateLearningRatesAndWeightsRGDNBT() {
    Value sum_active_learning_rates = 0;
    Value num_active_learning_rates = 0;

    // for each function
#if __ACTIVATE_OPENMP_TRAINER__ > 0
#pragma omp parallel shared(sum_active_learning_rates,num_active_learning_rates)
#endif
    {
#if __ACTIVATE_OPENMP_TRAINER__ > 0
#pragma omp for reduction(+:sum_active_learning_rates,num_active_learning_rates) schedule(dynamic)
#endif
        for (unsigned int l = 0; l < learn_functions.size(); ++l) {
            const Function::ID& functionName = learn_functions[l].first;
            LearnFunction* lfunction = learn_functions[l].second;

            TrainStatus* status = this->GetMutableTrainStatus(functionName);

            for (Index i = 0; i < lfunction->Size(); ++i) {
                const Value der_val = derivatives[functionName].Get(i);
                if (der_val == 0)  continue;

                const Value previous_der_val = previous_derivatives[functionName].Get(i);
                const float prod = der_val * previous_der_val;
                if (prod > static_cast<Value>(0.0)) {
                    // increase
                    status->rgd_learning_rate[i] *= Parameters().increase_learning_rate;
                    if (Parameters().max_learning_rate > static_cast<Value>(0.0) &&
                            status->rgd_learning_rate[i] > Parameters().max_learning_rate) {
                        status->rgd_learning_rate[i] = Parameters().max_learning_rate;
                    }
                } else if (prod < static_cast<Value>(0.0)) {
                    // decrease
                    status->rgd_learning_rate[i] *= Parameters().decrease_learning_rate;
                    if (Parameters().min_learning_rate > static_cast<Value>(0.0) &&
                            status->rgd_learning_rate[i] < Parameters().min_learning_rate) {
                        status->rgd_learning_rate[i] = Parameters().min_learning_rate;
                    }
                }

                sum_active_learning_rates += status->rgd_learning_rate[i];
                ++num_active_learning_rates;

                // computed the delta_weight: sign (D E/D w)
                const Value delta_weight = Math::Sign(der_val) * status->rgd_learning_rate[i];

                // update the value
                lfunction->Update(i, delta_weight);
            }

            // copy the current derivatives in the previous one for new iteration
            previous_derivatives[functionName].Copy(derivatives[functionName]);
        }
    }  // end parallel section

    // update the average learning rate
    GetMutableStatus()->learning_rate = (num_active_learning_rates > 0 ?
                                         sum_active_learning_rates / num_active_learning_rates :
                                         0);
}

void Trainer::ResetLearningRates() {
    if (Parameters().learning_type == TrainOptions::RGD) {
        this->ResetLearningRatesAndWeightsRGD();
    } else if (Parameters().learning_type == TrainOptions::RGDNBT) {
        this->ResetLearningRatesAndWeightsRGDNBT();
    } else if (Parameters().learning_type == TrainOptions::GD) {
        this->ResetLearningRatesGD();
    } else {
        FAULT("Unknown reset operation for " <<
                TrainOptions::LearningTypeToString(Parameters().learning_type));
    }
}

void Trainer::ResetLearningRatesGD() {
    const Value learning_rate_ =
            (ConsiderConstraintsPartNow() && Parameters().initial_learning_rate_for_constraints > 0.0 ?
             Parameters().initial_learning_rate_for_constraints :
             Parameters().initial_learning_rate);
    CHECK_GT(learning_rate_, static_cast<Value>(0));

    GetMutableStatus()->learning_rate = learning_rate_;
}

void Trainer::ResetLearningRatesAndWeightsRGD() {
    const Value learning_rate_ =
            (ConsiderConstraintsPartNow() && Parameters().initial_learning_rate_for_constraints > 0.0 ?
             Parameters().initial_learning_rate_for_constraints :
             Parameters().initial_learning_rate);
    CHECK_GT(learning_rate_, static_cast<Value>(0));

    // NOTE: the status map contains the status only of the learnable function
    // of the classifier
#if __ACTIVATE_OPENMP_TRAINER__ > 0
#pragma omp parallel
#endif
    {
#if __ACTIVATE_OPENMP_TRAINER__ > 0
#pragma omp for
#endif
        for (unsigned int i = 0; i < status_by_function_vec.size(); ++i) {
            status_by_function_vec[i]->rgd_learning_rate.SetAll(learning_rate_);
            status_by_function_vec[i]->rgd_delta_weights.SetAll(static_cast<Value>(0));
        }
    }  // end parallel section
}

void Trainer::ResetLearningRatesAndWeightsRGDNBT() {
    const Value learning_rate_ =
            (ConsiderConstraintsPartNow() && Parameters().initial_learning_rate_for_constraints > 0.0 ?
             Parameters().initial_learning_rate_for_constraints :
             Parameters().initial_learning_rate);
    CHECK_GT(learning_rate_, static_cast<Value>(0));

    // NOTE: the status map contains the status only of the learnable function
    // of the classifier
#if __ACTIVATE_OPENMP_TRAINER__ > 0
#pragma omp parallel
#endif
    {
#if __ACTIVATE_OPENMP_TRAINER__ > 0
#pragma omp for
#endif
        for (unsigned int i = 0; i < status_by_function_vec.size(); ++i) {
            status_by_function_vec[i]->rgd_learning_rate.SetAll(learning_rate_);
        }
    }  // end parallel section
}

/**********************************************************************
 * CHECKS
 **********************************************************************/
/**
 * Check if stop the training
 */
bool Trainer::ShouldStop() {
    if (GetStatus().iteration <= 1) {
        return false;  // training has not started yet
    }
    if (GetMutableStatus()->iteration >= Parameters().max_iterations) {
        return true;  // Always stop when reaching the max number of iterations.
    }

    if (GetStatus().gradient_module * GetStatus().learning_rate >= Parameters().min_gradient &&
        GetStatus().error > Parameters().min_total_error) {
        return false;
    }

    // If we are here gradient and/or error are very small.
    if (GetStatus().iteration < Parameters().iteration_start_constraints - 1) {
        // Gradient too small or total error to small, activating the constraints.
        GetMutableStatus()->iteration = Parameters().iteration_start_constraints - 1;
        VMESSAGE(0, "Iteration " << GetStatus().iteration << " Gradient module or Error too small: Start using constraints");
        return false;
    }

    if (activated_constraints.size() == Parameters().constraints_set.size()) {
        VMESSAGE(0, "Iteration " << GetStatus().iteration << " Gradient module or Error too small: Exiting from train");
        return true;
    }

    VMESSAGE(0, "Iteration " << GetStatus().iteration << " Gradient module or Error too small: Add more constraints");
    return false;
}


bool Trainer::ShouldRunCrossvalidation() const {
    return (Parameters().crossvalidation_iterations > 0 &&
            Parameters().crossvalidation_dataset != NULL &&
            Parameters().crossvalidation_dataset->Size() > 0 &&
            Parameters().crossvalidation_examples != NULL &&
            Parameters().crossvalidation_examples->Size() > 0 &&
            (GetStatus().iteration % Parameters().crossvalidation_iterations == 0 ||
             GetStatus().iteration == Parameters().max_iterations));
}

void Trainer::MaybeRunCrossvalidation(ofstream& os) {
    if (!this->ShouldRunCrossvalidation()) {
        return;
    }

    const TestUtils::TestType testType = TestUtils::TestTypeFromString(FLAGS_test_type);
    classifier->PrepareForCrossvalidation();

    const std::string roc_curve_file = (FLAGS_save_crossvalidation_roc_curves ?
            StringUtils::StrCat(Parameters().output_dir, "/crossvalidation_roc_curve",
                                GetStatus().iteration, ".dat") : "");

    map<string, Value> stats;
    TestUtils::RunValidation(*classifier, *(Parameters().crossvalidation_dataset),
            testType, classes_for_test, Parameters().useMicroStatistics, roc_curve_file,
            Parameters().crossvalidation_examples, &stats);
    classifier->EndCrossvalidation();

    if (stats.size() != 0) {
        os << GetStatus().iteration <<"\t";
        for(map<string, Value>::const_iterator cter = stats.begin();
            cter != stats.end(); ++cter) {
            os << cter->second <<"\t";
        }
        os << GetStatus().error <<"\n";
    }

    if (!std::Has(GetMutableStatus()->best_crossvalidation.second, Parameters().metric) ||
        GetMutableStatus()->best_crossvalidation.second[Parameters().metric] <
            stats[Parameters().metric]) {
        GetMutableStatus()->best_crossvalidation.first = GetStatus().iteration;
        GetMutableStatus()->best_crossvalidation.second = stats;

        VMESSAGE(1, "Saving best model by crossvalidation at iteration " << GetStatus().iteration);
        if (GetStatus().best_crossvalidation_model != NULL) {
            delete GetMutableStatus()->best_crossvalidation_model;
        }
        GetMutableStatus()->best_crossvalidation_model = this->classifier->Clone();
    }
}

/*
 * Save the weights of each rule
 */
bool Trainer::SaveConstraintsWeightsToStream(ofstream& os) const {
    os << "# Rule weights " << endl;
    for (map<string, Value>::const_iterator it = GetStatus().constraint_weights.begin();
         it != GetStatus().constraint_weights.end(); ++it) {
        os << "R;" <<it->first <<":" <<it->second << endl;
    }
    return true;
}

/*************************************************************************
 * Active Teaching
 *************************************************************************/
void Trainer::MaybeActivateConstraints() {
    if (activated_constraints.size() == Parameters().constraints_set.size()) {
        VMESSAGE(3, "No more constraints to add.");
        return;  // All constraints have been already activated.
    }

    if (!ConsiderConstraintsPartNow()) {
        return;
    }

    if ((Parameters().iterations_x_add_constraints > 0 &&
         (GetStatus().iteration - Parameters().iteration_start_constraints) %
         Parameters().iterations_x_add_constraints != 0)) {
        return;
    }

    VMESSAGE(1, "Adding constraint of priority: " << GetStatus().learning_stage);
    for (ConstraintsSet::const_iterator it = Parameters().constraints_set.begin();
         it != Parameters().constraints_set.end(); ++it) {
        if (it->second->GetConstraintPriority() == GetStatus().learning_stage ||
            Parameters().iterations_x_add_constraints <= 0) {
            activated_constraints.push_back(it->second);
            VPRINTLN(2, "\tActivating: " << it->first << " @" << it->second->GetConstraintPriority());

            const Value allowed_relative_error = GetStatus().GetConstraintTrainingSetError(it->second->GetName());
            if (allowed_relative_error != TrainStatus::ConstraintTrainingSetErrorNoValue) {
                CHECK_INE_RANGE(allowed_relative_error, static_cast<Value>(0.0), static_cast<Value>(1.0));
                activated_constraints.back()->SetAllowedRelativeError(allowed_relative_error);
                VPRINTLN(2, "\tReassigning " << it->first << " to AllowedRelativeError " << allowed_relative_error);
            }
        }
    }

    ++GetMutableStatus()->learning_stage;

    this->ResetLearningRates();
    GetMutableStatus()->ResetLowestErrorModel();
}

/**
 * Train the weights vector of the functions set using gradient
 * descent and constraints
 */
void Trainer::Train()
{
    CHECK_NE_NULL(classifier);
    CHECK(!Parameters().output_dir.empty());

    // file for the info of the training process
    const string& trainer_path = Parameters().output_dir;
    FileUtils::MakePathOrDie(trainer_path);

    const string train_results_file = trainer_path + "/trainer_info.dat";
    ofstream trainer_stream(train_results_file.c_str());
    CHECK_WITH_MESSAGE(trainer_stream.good(),
                       " Can not open the trainer log " + train_results_file);

    // write first line of file
  	trainer_stream << "#Iter\tTime\tGradientMod\tLearningRate\tLabeledErr\tRegularErr\tConstraintsErr\tTotalErr" << endl;


    // file for the info on cross-validation during training
    ofstream crossvalid_stream;
    if (Parameters().crossvalidation_iterations > 0) {
        const string crossvalid_results_file = trainer_path + "/crossvalidation_info.dat";
        crossvalid_stream.open(crossvalid_results_file.c_str());
        CHECK_WITH_MESSAGE(crossvalid_stream.good(),
                           " Can not open the crossvalidation log " + crossvalid_results_file);

        // write the first line
        crossvalid_stream << "Iteration\t";
        for(map<string, Value>::const_iterator cter =
                GetStatus().best_crossvalidation.second.begin();
            cter != GetStatus().best_crossvalidation.second.end(); ++cter)
            crossvalid_stream << cter->first <<"\t";
        crossvalid_stream <<"Total_Error" << endl;
    }

    time_t startTrainTime;
    time(&startTrainTime);

    #if __ACTIVATE_OPENMP_TRAIN_PROFILER__ > 0
#pragma pomp inst init
#endif

    // iterations
    for (GetMutableStatus()->iteration = 0; !this->ShouldStop(); ++GetMutableStatus()->iteration) {
#if __ACTIVATE_OPENMP_TRAIN_PROFILER__ > 0
#pragma pomp inst begin(train)
#endif
        this->MaybeActivateConstraints();
        classifier->StartTrainIteration();

        // First iteration is only to eval the model on the initial status.
        if (GetStatus().iteration > 0) {
            // Update the map containing the derivative vectors
            // for updating weights of the functions.
            this->GetGradients();
            this->UpdateLearningRatesAndWeights();
        }

        // Update the error for all functions and the global, at first iteration GetGradients
        // has not been called and constraint error must be computed as it is not available in status.
        this->EvalAndUpdateError(GetStatus().iteration == 0);

        LogTrainStatus(trainer_stream);

        this->MaybeSaveLowestErrorModel();
        this->MaybeRunCrossvalidation(crossvalid_stream);

        classifier->EndTrainIteration();
#if __ACTIVATE_OPENMP_TRAIN_PROFILER__ > 0
#pragma pomp inst end(train)
#endif
    }  // end iteration

    // End the train session (logging, cleanup, etc.).
    this->End(crossvalid_stream);

    if (Parameters().crossvalidation_dataset != NULL &&
        Parameters().crossvalidation_dataset->Size() > 0) {
        crossvalid_stream << "\nBEST@ Iteration: " <<
                GetStatus().best_crossvalidation.first;
        for(TrainStatus::ConstrainErrors::const_iterator cter =
                GetStatus().best_crossvalidation.second.begin();
            cter != GetStatus().best_crossvalidation.second.end(); ++cter) {
            crossvalid_stream <<" " << cter->first <<": " <<cter->second;
        }
        crossvalid_stream.close();
    }

    time_t endTrainTime;
    time(&endTrainTime);
    VMESSAGE(1, "Training completed. Time: " << endTrainTime - startTrainTime << " s");
    trainer_stream << "# Training Time: " << endTrainTime - startTrainTime <<" s" <<endl;
    trainer_stream.close();
}

bool Trainer::MaybeSaveLowestErrorModel() {
    if (Parameters().save_lowest_error_model &&
        (GetStatus().saved_model_lowest_error < 0 ||
         GetStatus().error < GetStatus().saved_model_lowest_error)) {
        GetMutableStatus()->saved_model_lowest_error = GetStatus().error;
        if (GetStatus().lowest_error_model != NULL) {
            delete GetMutableStatus()->lowest_error_model;
        }
        VMESSAGE(1, "Saving lowest error model at iteration " << GetStatus().iteration);
        GetMutableStatus()->lowest_error_model = this->classifier->Clone();
        return true;
    }

    return false;
}

void Trainer::LogTrainStatus(ostream& trainer_stream) {
    const std::streamsize default_ss = std::cout.precision();
    const time_t running_time = time(NULL) - GetStatus().starttime_in_sec;

    VPRINTLN(1, "\n-----------------------------------------------------------\n" <<
            "\tIteration " << GetStatus().iteration << "/" << Parameters().max_iterations <<
            "\tTime: " << std::fixed << std::setprecision(1) << running_time << resetiosflags(ios::fixed) <<
            "\tOptimization: " << TrainOptions::LearningTypeToString(Parameters().learning_type) <<
            " Constraints " << (this->ConsiderConstraintsPartNow() ? "USED " : "NOT USED ") <<
            setiosflags(ios::fixed) << std::setprecision(default_ss) <<
            "\tGradientMod: " << GetStatus().gradient_module <<
            "\tLR: " << GetStatus().learning_rate <<
            "\n\tErrors\tLabeled " << GetStatus().labeled_error <<
            "\tRegularization " << GetStatus().regularization_error <<
            "\tConstraint " << GetStatus().constrained_error <<
            "\tTotal " << GetStatus().error <<
            resetiosflags(ios::fixed) << std::flush);
    for (unsigned int i = 0; i < activated_constraints.size(); ++i) {
        const string& constraint_name = activated_constraints[i]->GetName();
        VPRINTLN(2, setiosflags(ios::fixed) <<
                "\tError " << constraint_name << " " <<
                GetStatus().GetConstraintError(constraint_name) <<
                resetiosflags(ios::fixed));
    }

    // print to file
    trainer_stream << setiosflags(ios::fixed) <<
            GetStatus().iteration << "\t" <<
            std::setprecision(1) << running_time << "\t" <<
            std::setprecision(default_ss) << GetStatus().gradient_module << "\t" <<
            GetStatus().learning_rate << "\t" <<
            GetStatus().labeled_error << "\t" <<
            GetStatus().regularization_error << "\t" <<
            GetStatus().constrained_error << "\t" <<
            GetStatus().error << "\n" <<
            resetiosflags(ios::fixed) << std::flush;
}

/**
 * End the trainer
 */
void Trainer::End(ofstream& os) {
    classifier->EndTrain();
    this->MaybeRunCrossvalidation(os);

    // Copy back to classifier the best model found.
    if (GetStatus().best_crossvalidation_model != NULL) {
        VMESSAGE(1, "Reverting back to the best crossvalidation model @" <<
                 GetStatus().best_crossvalidation.first);
        classifier->Copy(GetStatus().best_crossvalidation_model);
    } else if (GetStatus().lowest_error_model != NULL) {
        VMESSAGE(1, "Reverting back to the lowest error model @" <<
                 GetStatus().best_crossvalidation.first);
        classifier->Copy(GetStatus().lowest_error_model);
    }
}

/**
 * Computes the error for a single function.
 */
void Trainer::EvalAndUpdateErrorByFunction(const LearnFunction& function)
{
    TrainStatus* status = this->GetMutableTrainStatus(function.GetId());
    string function_name = function.GetId();
    // previous errors
    status->previous_labeled_error = status->labeled_error;
    status->previous_regularization_error = status->regularization_error;
    status->previous_error = status->error;

    // the current error on the labeled data on the regularization
    if (Parameters().predicate_lambda == true)
    {

    	map<string, Value>::const_iterator rt =  Parameters().lambda_labeled_predicate.find(function_name);
    	if (rt != Parameters().lambda_labeled_predicate.end())
       {
    	  Value lambda_labeled_function = rt->second;
    	  status->labeled_error = lambda_labeled_function *
    			  function.EvalLabeledError(
                 Parameters().dataset->GetDomainDataset(function.GetDomain()),
                 Parameters().examples,
                 Parameters().labeled_loss_function);
       }
    }
    else
    {
    	   status->labeled_error = Parameters().lambda_labeled *
            function.EvalLabeledError(
                    Parameters().dataset->GetDomainDataset(function.GetDomain()),
                    Parameters().examples,
                    Parameters().labeled_loss_function);
    }
    status->regularization_error = Parameters().lambda_regularization *
            function.EvalRegularizationError();
    status->error = status->labeled_error + status->regularization_error;
}

/**
 * Update Error for the global status, drives the single function updates
 * and update error for the lambda status
 */
void Trainer::EvalAndUpdateError(const bool evaluate_constraints)
{
    // Save the previous errors
    GetMutableStatus()->previous_labeled_error = GetStatus().labeled_error;
    GetMutableStatus()->previous_regularization_error = GetStatus().regularization_error;
    GetMutableStatus()->previous_constrained_error = GetStatus().constrained_error;
    GetMutableStatus()->previous_error = GetStatus().error;
    Value labeled_error = static_cast<Value>(0.0);
    Value regularization_error = static_cast<Value>(0.0);

    // Do not activate this, because parallelism is already enabled on the function side.
#if __ACTIVATE_OPENMP_TRAINER__ > 0
#pragma omp parallel shared(labeled_error,regularization_error)
#endif
    {
#if __ACTIVATE_OPENMP_TRAINER__ > 0
#pragma omp for reduction(+:labeled_error,regularization_error) schedule(dynamic)
#endif
        for (unsigned int i = 0; i < learn_functions.size(); ++i) {
            const Function::ID& fid = learn_functions[i].first;
            const LearnFunction& lfunction = *(learn_functions[i].second);

            // labeled and regularization parts per predicate
            this->EvalAndUpdateErrorByFunction(lfunction);

            // updates values of global status
            const TrainStatus& status = this->GetTrainStatus(fid);
            labeled_error += status.labeled_error;
            regularization_error += status.regularization_error;
        }
    }  // end of parallel region

    GetMutableStatus()->labeled_error = labeled_error;
    GetMutableStatus()->regularization_error = regularization_error;

    if (evaluate_constraints) {
        // For speed the computation of the constrain_error is done in GetConstraintErrorGradients and not
        // repeated here. The first iteration is an exception as the former method has not been called yet.
        GetMutableStatus()->constrained_error = this->EvalConstraintsErrorPart();
    }

    // Global error is the sum of the single components.
    GetMutableStatus()->error =
            GetStatus().labeled_error + GetStatus().regularization_error + GetStatus().constrained_error;
}

/**
 * Evaluate the value of the constraints error part of the cost function.
 */
Value Trainer::EvalConstraintsErrorPart() {
    const Index constraints_size = activated_constraints.size();
    if (constraints_size == 0) {
        return 0.0;
    }

    Value sum = static_cast<Value>(0.0);
#if __ACTIVATE_OPENMP_TRAINER__ > 0
#pragma omp parallel default(none) shared(sum)
#endif
    {
#if __ACTIVATE_OPENMP_TRAINER__ > 0
#pragma omp for reduction(+:sum) schedule(dynamic)
#endif
        for (Index i = 0; i < constraints_size; ++i) {
            // constraint value c on pattern x_i: phi_c(x_i)
            // Accumulates the loss L applied to phi_c(x_i):
            const string& constraintName = activated_constraints[i]->GetName();
            const Value constraint_weight = GetStatus().GetConstraintWeight(constraintName);
            const Value val = activated_constraints[i]->Eval(constraint_weight, NULL);
            sum += val;
            GetMutableStatus()->costrained_errors[constraintName] = val;
        }
    }  // end of parallel region

    return sum;
}

/****************************************************************************
 * Derivative parts
 ****************************************************************************/

// Utility function to accumulate the gradients.
void Trainer::AccumulateGradientsHelper(const FOLFormulaConstraint::PerFunctionDerivative& src, FOLFormulaConstraint::PerFunctionDerivative* dest) {
    for (unsigned int i = 0; i < learn_functions.size(); ++i) {
        const Function::ID& fid = learn_functions[i].first;
        (*dest)[fid].AddInPlace(std::FindOrDie<FOLFormulaConstraint::PerFunctionDerivative, Function::ID, Math::Vector<Value> >(src, fid));
    }
}

/**
 * Evaluate the derivative of regularization error part of the cost function.
 */
void Trainer::GetRegularizationErrorGradients() {
    CHECK_EQ(regularization_derivatives.size(), static_cast<size_t>(classifier->LearnableSize()));
    if (Parameters().lambda_regularization <= static_cast<Value>(0)) {
        return;
    }

#if __ACTIVATE_OPENMP_TRAINER__ > 0
#pragma omp parallel
#endif
    {
#if __ACTIVATE_OPENMP_TRAINER__ > 0
#pragma omp for schedule(dynamic)
#endif
        for (unsigned int i = 0; i < learn_functions.size(); ++i) {
            const Function::ID& fid = learn_functions[i].first;
            const LearnFunction* lfunction = learn_functions[i].second;
            lfunction->GetRegularizationErrorGradient(&regularization_derivatives[fid]);

            // multiply by lambda
            regularization_derivatives[fid].MultiplyInPlace(Parameters().lambda_regularization);
            derivatives[fid].AddInPlace(regularization_derivatives[fid]);
        }
    }  // end parallel section
}

namespace {
const Examples::PerFunctionExamples* GetStochasticExamples(
        const Examples::PerFunctionExamples& input, const double stochastic_portion) {
    if (stochastic_portion >= 1.0) {
        // For speed if no sampling is required, we just return as output a ptr to the same
        // dataset provided as input.
        return &input;
    }

    Examples::PerFunctionExamples* stochastic_examples = new Examples::PerFunctionExamples();
    const Index num_examples =
            Math::Max(static_cast<Index>(1),
                    static_cast<Index>(stochastic_portion * input.size()));
    for (unsigned int i = 0; i < num_examples; ++i) {
        const Index index =
                Math::Rand(static_cast<Index>(0), static_cast<Index>(input.size() - 1));
        stochastic_examples->push_back(input[index]);
    }
    return stochastic_examples;
}
}  // end namespace

/**
 * Evaluate the derivative of labeled error part of the cost function.
 */
void Trainer::GetLabeledErrorGradients() {
    CHECK_EQ(labeled_derivatives.size(), static_cast<size_t>(classifier->LearnableSize()));
    if (Parameters().predicate_lambda == true || Parameters().examples == NULL)
    {
    	for(map<string, Value>::const_iterator it = Parameters().lambda_labeled_predicate.begin(); it != Parameters().lambda_labeled_predicate.end(); it++)
    	{
    		if(it->second <= 0.0)
    		{
    			return;
    		}
    	}

    }
    else if (Parameters().lambda_labeled <= static_cast<Value>(0) || Parameters().examples == NULL)
    {
    	return;
    }// No examples or no labeled part activated.


    // Do not activate together with function-level parallelism,
    // because this function would call AccumulateGradient at the function level,
    // which is also parallelized.
#if __ACTIVATE_OPENMP_TRAINER__ > 0
#pragma omp parallel
#endif
    {
#if __ACTIVATE_OPENMP_TRAINER__ > 0
#pragma omp for schedule(dynamic)
#endif
        for (unsigned int i = 0; i < learn_functions.size(); ++i) {
            const Function::ID& fid = learn_functions[i].first;
            const LearnFunction* lfunction = learn_functions[i].second;

            const Examples::PerFunctionExamples* fexamples =
                    Parameters().examples->GetExamplesForPredicate(fid);
            if (fexamples == NULL) {
                continue;  // No labeled patterns, nothing to do here.
            }

            // Performs stochastic sampling of the training data.
            const Examples::PerFunctionExamples* fexamples_to_use =
                    GetStochasticExamples(*fexamples, Parameters().stochastic_portion);

            lfunction->GetLabeledErrorGradient(
                    Parameters().dataset->GetDomainDataset(lfunction->GetDomain()),
                    fexamples_to_use, Parameters().labeled_loss_function,
                    &labeled_derivatives[fid]);

            if (fexamples_to_use != fexamples) {
                delete fexamples_to_use;
            }

            if (Parameters().predicate_lambda == true)
            {
            	for(map<string, Value>::const_iterator it = Parameters().lambda_labeled_predicate.begin(); it != Parameters().lambda_labeled_predicate.end(); it++)
            	{
              		if(it->first == fid)
              		{
              			labeled_derivatives[fid].MultiplyInPlace(it->second);
              			derivatives[fid].AddInPlace(labeled_derivatives[fid]);
              		}
              	}
            }
            else
            {
            	labeled_derivatives[fid].MultiplyInPlace(Parameters().lambda_labeled);
            	derivatives[fid].AddInPlace(labeled_derivatives[fid]);
            }
        }
    }  // end parallel section
}

/**
 * Evaluate the gradient of constrained part of the cost function.
 */
#if __ACTIVATE_OPENMP_TRAINER__ > 1
void Trainer::GetConstraintErrorGradients() {
    if (!this->ConsiderConstraintsPartNow()) {
        return;
    }

    CHECK_EQ(thread_local_constraint_derivatives.size(), static_cast<size_t>(omp_get_num_threads()));
    /* for (int i = 0; i < omp_get_num_threads(); ++i) {
        CHECK_EQ(thread_local_constraint_derivatives[i].size(), static_cast<size_t>(classifier->LearnableSize()));
    } */
    const Index constraints_size = activated_constraints.size();
    if (constraints_size == 0) {
        return;
    }

    Value sum_constraint_values = 0;
#pragma omp parallel
    {
#pragma omp for reduction(+:sum_constraint_values) schedule(dynamic)
        for (unsigned int i = 0; i < constraints_size; ++i) {
            const string& constraintName = activated_constraints[i]->GetName();

            /* The constraint gradient map:
             * the map (name of function, vector of derivatives) contains the
             * derivative of each function of the classifier.
             * the vector contains the gradient of L(Phi_c(f)) in respect to the
             * k^th weight evaluated in the dataset,
             * i.e. (D L(Phi_c(f))/D w_k)(x_i) = (D L(Phi_c(f))/D Phi_c)(Phi_c(f(x_i))) *
             * (D Phi_c(f)/D f)(f(x_i)) * (D f/D w_k)(x_i)
             * where D is the differential operator.
             */
            const Value constraint_weight = GetStatus().GetConstraintWeight(constraintName);
            const Value constraint_value = activated_constraints[i]->Eval(
                    constraint_weight, &thread_local_constraint_derivatives[omp_get_thread_num()]);
            sum_constraint_values += constraint_value;
            GetMutableStatus()->costrained_errors[constraintName] = constraint_value;
        }
    }  // end parallel

    GetMutableStatus()->constrained_error = sum_constraint_values;

    for (int i = 0; i < omp_get_num_threads(); ++i) {
        Classifier::LearnIterator iter(*classifier);
        while (iter.HasNext()) {
            const Classifier::LearnIterator::Element* el = iter.GetNext();
            const Function::ID& fid = el->first;
            constraint_derivatives[fid].AddInPlace(thread_local_constraint_derivatives[i][fid]);
        }
    }

    // add the constraints parts to the derivatives vector of Math::Vector
#pragma omp parallel
    {
#pragma omp for schedule(dynamic)
        this->AccumulateGradientsHelper(constraint_derivatives, derivatives);
    }  // end parallel section
}
#else
void Trainer::GetConstraintErrorGradients() {
    if (!this->ConsiderConstraintsPartNow()) {
        return;
    }

    CHECK_EQ(constraint_derivatives.size(), static_cast<size_t>(classifier->LearnableSize()));

    const Index constraints_size = activated_constraints.size();
    if (constraints_size == 0) {
        return;
    }

    Value sum_constraint_values = 0;
    // TODO(michi): make this parallel, constraint_derivatives is shared making this hard
    // to parallelize.
    for (unsigned int i = 0; i < constraints_size; ++i) {
        const string& constraintName = activated_constraints[i]->GetName();

        /* The constraint gradient map:
         * the map (name of function, vector of derivatives) contains the
         * derivative of each function of the classifier.
         * the vector contains the gradient of L(Phi_c(f)) in respect to the
         * k^th weight evaluated in the dataset,
         * i.e. (D L(Phi_c(f))/D w_k)(x_i) = (D L(Phi_c(f))/D Phi_c)(Phi_c(f(x_i))) *
         * (D Phi_c(f)/D f)(f(x_i)) * (D f/D w_k)(x_i)
         * where D is the differential operator.
         */
        const Value constraint_weight = GetStatus().GetConstraintWeight(constraintName);
        const Value constraint_value = activated_constraints[i]->Eval(constraint_weight, &constraint_derivatives);
        sum_constraint_values += constraint_value;
        GetMutableStatus()->costrained_errors[constraintName] = constraint_value;
    }

    GetMutableStatus()->constrained_error = sum_constraint_values;
    this->AccumulateGradientsHelper(constraint_derivatives, &derivatives);
}
#endif

void Trainer::UpdateGradientModule() {
    Value module = static_cast<Value>(0);
#if __ACTIVATE_OPENMP_TRAINER__ > 0
#pragma omp parallel shared(module)
#endif
    {
#if __ACTIVATE_OPENMP_TRAINER__ > 0
#pragma omp for reduction(+:module) schedule(dynamic)
#endif
        for (unsigned int i = 0; i < learn_functions.size(); ++i) {
            const Function::ID& fid = learn_functions[i].first;
            module += derivatives[fid].Norm2();
        }
    }  // end parallel section

    GetMutableStatus()->gradient_module = module;
}

void Trainer::ResetGradientsHelper(FOLFormulaConstraint::PerFunctionDerivative* dest) {
    for (unsigned int i = 0; i < learn_functions.size(); ++i) {
        const Function::ID& functionName = learn_functions[i].first;
        // Reset the derivatives vector for the k-th function
        (*dest)[functionName].SetAll(static_cast<Value>(0.0));
    }
}

/*
 * Reset all the gradients before starting a new computation.
 */
void Trainer::ResetGradients() {
    // Consistency checks.
    /* for (unsigned int i = 0; i < learn_functions.size(); ++i) {
        const Function::ID& functionName = learn_functions[i].first;
        const LearnFunction* lfunction = learn_functions[i].second;
        CHECK_EQ(lfunction->Size(), static_cast<Index>(derivatives[functionName].Size()));
        CHECK_EQ(lfunction->Size(), static_cast<Index>(regularization_derivatives[functionName].Size()));
        CHECK_EQ(lfunction->Size(), static_cast<Index>(labeled_derivatives[functionName].Size()));
        CHECK_EQ(lfunction->Size(), static_cast<Index>(constraint_derivatives[functionName].Size()));
    } */

#if __ACTIVATE_OPENMP_TRAINER__ > 0
#pragma omp parallel
#endif
    {
#if __ACTIVATE_OPENMP_TRAINER__ > 0
#pragma omp for schedule(dynamic)
#endif
        for (unsigned int i = 0; i < learn_functions.size(); ++i) {
            const Function::ID& functionName = learn_functions[i].first;
            // Reset the derivatives vector for the k-th function
            derivatives[functionName].SetAll(static_cast<Value>(0.0));
            regularization_derivatives[functionName].SetAll(static_cast<Value>(0.0));
            labeled_derivatives[functionName].SetAll(static_cast<Value>(0.0));
            constraint_derivatives[functionName].SetAll(static_cast<Value>(0.0));
#if __ACTIVATE_OPENMP_TRAINER__ > 1
            for (unsigned int j = 0; j < thread_local_constraint_derivatives.size(); ++j) {
                thread_local_constraint_derivatives[j][functionName].SetAll(static_cast<Value>(0.0));
            }
#endif
        }
    }  // end parallel section
}

void Trainer::MaybeNormalizeGradients() {
    if (!Parameters().normalize_gradient) {
        return;
    }

#if __ACTIVATE_OPENMP_TRAINER__ > 0
#pragma omp parallel
#endif
    {
#if __ACTIVATE_OPENMP_TRAINER__ > 0
#pragma omp for schedule(dynamic)
#endif
        for (unsigned int i = 0; i < learn_functions.size(); ++i) {
            const Function::ID& fid = learn_functions[i].first;
            derivatives[fid].NormalizeInPlace();
        }
    }  // end parallel section
}

/**
 * Compute the i^th iteration on the k^th function.
 */
void Trainer::GetGradients() {
    CHECK_EQ(static_cast<unsigned int>(derivatives.size()), classifier->LearnableSize());

    // Cleanup the previous gradients.
    this->ResetGradients();

    // A) REGULARIZATION ERROR PART
    this->GetRegularizationErrorGradients();

    // B) LABELED ERROR PART
    this->GetLabeledErrorGradients();
    // MESSAGE("L " << derivatives["DIS"].ToStringAsSparse());

    // C) CONSTRAINED ERROR PART
    this->GetConstraintErrorGradients();
    // MESSAGE("C " << derivatives["DIS"].ToStringAsSparse());

    // Finalize the gradient.
    this->MaybeNormalizeGradients();
    this->UpdateGradientModule();
}

}  // end Regularization
