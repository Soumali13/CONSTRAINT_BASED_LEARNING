/*
 * options.h
 */

#ifndef OPTIONS_H
#define OPTIONS_H

#include <map>
#include <string>
#include "data/basic_data_types.h"
#include "utils/stl_utils.h"
#include "classifier/functions/function.h"


namespace Regularization {
class Dataset;
class Examples;
class LossFunction;
class Predicates;


class TrainOptions {
public:
    // GD: gradient descent
    // RGD: resilient back-propagation
    // RGDNBT: resilient back-propagation without back-tracking
    typedef enum
    {
        GD, RGD, RGDNBT, INVALID
    } LEARNING_TYPE;

    static std::string LearningTypeToString(const LEARNING_TYPE lt);

    /**
     * Select the learning type from string
     **/
    static LEARNING_TYPE SelectLearningType(const std::string& learning_type);

    // NP: no pattern. No active learning is performed
    // RP: random patterns
    // WP: worst matching patterns
    // BP: best matching patterns
    // UP: best defined patterns
    typedef enum
    {
        NP, RP, WP, BP, UP, IP
    } ACTIVE_LEARNING_TYPE;

    typedef std::map<std::string, Value> ConstraintsWeights;
    typedef std::map<std::string,Value> Lambdas_labeled_predicate;

    // Gram Matrices Files
    struct GramMatrixFile {
        std::string filename;
        bool binary;
        GramMatrixFile() : binary(false) { }
        GramMatrixFile(const std::string& filename_, const bool binary_);
    };
    typedef std::map<std::string, GramMatrixFile> DomainToGramMatrixFilename;

    /******************************************************************
     * Constructors
     ******************************************************************/

    TrainOptions();

    // Destructor
    ~TrainOptions();
    void Clear();
    void CheckOptions();
    void Copy(const TrainOptions& options);

    /**********************************
     * Functions to get options values
     **********************************/
    inline bool GetNormalizeGradient() const {
        return normalize_gradient;
    }
    inline const DomainToGramMatrixFilename& GetGramMatricesFilesMap() const
    {
        return gram_matrices_files_map;
    }
    inline bool SaveGramMatrices() const
    {
        return save_gram_matrix;
    }
    inline bool OnlineGramMatrix() const
    {
        return online_gram_matrix;
    }
    inline const Dataset* GetCrossValidationDataset() const
    {
        return crossvalidation_dataset;
    }
    inline const Examples* GetCrossValidationExamples() const
    {
        return crossvalidation_examples;
    }
    inline const LossFunction& GetLabeledLossFunction() const
    {
        return *labeled_loss_function;
    }
    inline const LossFunction& GetConstraintsLossFunction() const
    {
        return *constraints_loss_function;
    }
    inline Value GetLambdaLabeled() const
    {
        return this->lambda_labeled;
    }
    inline Lambdas_labeled_predicate GetLambdaLabeledPredicate() const
    {
    	return this->lambdas_labeled_predicate;
    }
    inline Value GetLambdaRegularization() const
    {
        return this->lambda_regularization;
    }
    inline Value GetLambdaConstraints() const
    {
        return this->lambda_constraints;
    }
    inline Value GetSecondPassLambdaConstraints() const
    {
        return this->second_pass_lambda_constraints;
    }
    inline Value GetLearningRate() const
    {
        return this->learning_rate;
    }
    inline Value GetSecondPassLearningRate() const
    {
        return this->second_pass_learning_rate;
    }
    inline Value GetLearningRateForConstraints() const
    {
        return this->learning_rate_for_constraints;
    }
    inline Value GetIncreaseLearningRate() const
    {
        return this->increase_learning_rate;
    }
    inline Value GetDecreaseLearningRate() const
    {
        return this->decrease_learning_rate;
    }
    inline Value GetMinLearningRate() const
    {
        return this->min_learning_rate;
    }
    inline Value GetMaxLearningRate() const
    {
        return this->max_learning_rate;
    }
    inline int GetMaxIterations() const
    {
        return this->max_iterations;
    }
    inline int GetSecondPassMaxIterations() const
    {
        return this->second_pass_max_iterations;
    }
    inline Value GetMinGradientModule() const
    {
        return this->min_gradient_module;
    }
    inline Value GetTotalError() const
    {
        return this->min_total_error;
    }
    inline Value GetDeltaError() const
    {
        return this->min_delta_error;
    }
    inline int GetIterationStartConstraints() const
    {
        return this->iteration_start_constraints;
    }
    inline const LEARNING_TYPE& GetLearningType() const
    {
        return this->learning_type;
    }
    inline int GetIterationsXAddConstraints() const
    {
        return this->iterations_x_add_constraints;
    }
    inline int GetCrossValidationIterations() const
    {
        return this->crossvalidation_iterations;
    }
    inline const std::string& GetOutputDir() const
    {
        return this->output_dir;
    }
    inline const ConstraintsWeights& GetConstraintWeights() const
    {
        return this->constraintsWeights;
    }
    inline const std::string& GetKernelType() const
    {
        return this->kernel_type;
    }
    inline const std::string& GetKernelParameters() const
    {
        return this->kernelParameters;
    }
    inline Value GetDefaultSigmaGaussianKernel() const
    {
        return this->sigmaGaussianKernel;
    }

    inline Value GetACoefficentKernel() const
    {
        return this->aCoefficentKernel;
    }
    inline Value GetBCoefficentKernel() const
    {
        return this->bCoefficentKernel;
    }
    inline Value GetPCoefficientKernel() const
    {
        return this->pCoefficentKernel;
    }
    inline const std::string& GetFunctionType(const std::string& id) const
    {
        FunctionTypes::const_iterator iter = function_types.find(id);
        if (iter != function_types.end()) {
            return iter->second;
        }
        return this->function_type;
    }
    inline Value GetBalanceWeight(const std::string& id) const
    {
        return std::Find(balance_map, id, static_cast<Value>(1));
    }
    inline const std::string& GetMetric() const
    {
        return metric;
    }
    inline bool UseMicroStatistics() const
    {
        return micro_statistics;
    }
    inline int GetNeuralNetworkNumUnits(const std::string& id) const {
        return std::Find(nn_num_units, id, nn_num_units_default);
    }
    inline int GetNeuralNetworkNumLayers() const {
        return nn_num_layers;
    }
    inline std::string GetNeuralNetworkHiddenLayerActivation() const {
        return nn_hidden_layer_activation;
    }
    inline std::string GetNeuralNetworkOutputLayerActivation() const {
        return nn_output_layer_activation;
    }

    inline bool GetNeuralNetworkPreBuiltInputs() const {
        return nn_pre_built_inputs;
    }
    inline double GetNeuralNetworkDropoutThr() const {
        return nn_dropout_thr;
    }
    inline double GetNeuralNetworkInputDropoutThr() const {
        return nn_input_dropout_thr;
    }
    inline double GetNeuralNetworkWeightNormThr() const {
        return nn_weight_norm_thr;
    }
    inline double GetStochasticPortion() const {
        return stochastic_portion;
    }
    inline bool GetSaveLowestTrainErrorModel() const
    {
        return this->save_lowest_error_model;
    }

    /****************************************
     * Functions to set/load options values
     ***************************************/
    inline void SetCrossValidation(
            const Dataset* crossvalidation_dataset_, const Examples* crossvalidation_examples_)
    {
        crossvalidation_dataset = crossvalidation_dataset_;
        crossvalidation_examples = crossvalidation_examples_;
    }

    inline void SetOutputDir(const std::string& output_dir_)
    {
        output_dir = output_dir_;
    }
    inline bool GetPredicateLambdaStatus() const
    {
    	return predicate_lambda;
    }

    inline void SetPredicateLambdaStatus(bool& predicate_lambda_flag)
     {
     	predicate_lambda = predicate_lambda_flag;
     }
    void SetModelOptionsconst(Value lambda_labeled_,
            Value lambda_regularization_,
            Value lambda_constraints_,
            const std::string& output_dir_);

    void SetModelOptionsvar(Lambdas_labeled_predicate lambdas_labeled_predicate_,
                Value lambda_regularization_,
                Value lambda_constraints_,
                const std::string& output_dir_);

    std::map<std::string,Value> BuildLambdasPerPredicate(const Predicates& predicates);
    void SetIterations(
            const Value iteration_start_constraints_, const Value max_iterations_);
    void SetLearningRate(const Value learning_rate_);

    /******************
     * Save Functions
     ******************/
    bool SaveToStream(std::ostream& os) const;
    void Save(const std::string& filename) const;
    std::string ToString() const;

    // Load entire model
    bool Load(const std::string& filename);

private:
    // Learning type
    LEARNING_TYPE learning_type;
    // Normalize gradient before descent pass (applied regardless of learning_type).
    bool normalize_gradient;

    // Stop conditions
    int max_iterations;
    int second_pass_max_iterations;
    Value min_gradient_module;
    Value min_total_error;
    Value min_delta_error;

    // Lambda
    Value lambda_labeled;
    Lambdas_labeled_predicate lambdas_labeled_predicate;
    Value lambda_regularization;
    Value lambda_constraints;
    Value second_pass_lambda_constraints;


    // Active Teaching
    int iterations_x_add_constraints;

    // Learning Rate
    Value learning_rate;
    Value second_pass_learning_rate;
    Value learning_rate_for_constraints;
    Value increase_learning_rate;
    Value decrease_learning_rate;

    // Min/Max Learning Rate
    Value min_learning_rate;
    Value max_learning_rate;

    // Constraints
    int iteration_start_constraints;

    // Labeled Loss Function
    LossFunction* labeled_loss_function;
    std::string labeled_loss_type;
    Value labeled_loss_p1;
    Value labeled_loss_p2;
    Value labeled_loss_p3;

    // Constraints Loss Function
    LossFunction* constraints_loss_function;
    std::string constraints_loss_type;
    Value constraints_loss_p1;
    Value constraints_loss_p2;
    Value constraints_loss_p3;

    // CrossValidation during training
    const Dataset* crossvalidation_dataset;
    const Examples* crossvalidation_examples;
    int crossvalidation_iterations;
    std::string metric;
    bool micro_statistics;

    // Kernel
    std::string kernel_type;
    std::string kernelParameters;
    Value sigmaGaussianKernel;
    Value aCoefficentKernel;
    Value bCoefficentKernel;
    Value pCoefficentKernel;

    DomainToGramMatrixFilename gram_matrices_files_map;

    // Function used to approximate the predicates (NN, KM, etc.)
    std::string function_type;
    typedef std::map<std::string, std::string> FunctionTypes;
    FunctionTypes function_types;

    bool save_gram_matrix;
    bool online_gram_matrix;
    std::map<std::string, Value> balance_map;


    // Rule weights
    ConstraintsWeights constraintsWeights;

    // Output directory
    std::string output_dir;

    // NN options
    std::map<std::string, int> nn_num_units;  // hidden units by function id
    int nn_num_units_default;
    int nn_num_layers;
    std::string nn_hidden_layer_activation;
    std::string nn_output_layer_activation;
    bool nn_pre_built_inputs;
    double nn_dropout_thr;
    double nn_input_dropout_thr;
    double nn_weight_norm_thr;
    double stochastic_portion;  // if 1 all patterns always used in training, no stochastic
    bool predicate_lambda;
    bool save_lowest_error_model;

    // Should not be called, this is not copyable.
    TrainOptions& operator=(const TrainOptions& other);
    TrainOptions(const TrainOptions&) { }
}; // end TrainOptions

}  // end namespace Regularization
#endif /* OPTIONS_H */

