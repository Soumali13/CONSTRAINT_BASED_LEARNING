/*
 * constraints_factory.cc
 *
 *  Created on: Mar 21, 2014
 *      Author: michi
 */

#include "constraints/constraints_factory.h"
#include "constraints/FOL_formula_constraint.h"
#include "data/FOL_knowledge_base.h"
#include "data/examples.h"
#include "data/dataset.h"
#include "train/trainer.h"  // for Trainer::ConstraintsSet


using namespace Regularization;

/*
 * Build the set of constraints that must be learned or verified.
 */
/* static */
void ConstraintsFactory::BuildConstraints(const BaseClassifier* classifier,
        const FOLKnowledgeBase& FOL_KnowledgeBase,
        const Dataset& dataset, const Examples& examples,
        const FOLFormula::RULE_TYPE constraint_type  /* LEARN or VERIFY */,
        const LossFunction& constraint_loss_function,
        Trainer::ConstraintsSet* constraint_set) {
    for (int i = 0; i < FOL_KnowledgeBase.Size(); ++i) {
        const FOLFormula& FOLformula = FOL_KnowledgeBase.Get(i);
        if (FOLformula.GetRuleType() == constraint_type) {
            (*constraint_set)[FOLformula.GetName()] = new FOLFormulaConstraint(
                    FOLformula, dataset, classifier, examples, constraint_loss_function);
        }
    }
}
