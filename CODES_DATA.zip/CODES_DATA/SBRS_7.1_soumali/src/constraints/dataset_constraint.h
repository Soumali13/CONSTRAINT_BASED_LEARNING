#ifndef DATASET_CONSTRAINT_H
#define DATASET_CONSTRAINT_H

#include <map>
#include <unordered_map>
#include <string>

#include "classifier/functions/function.h"
#include "data/basic_data_types.h"
#include "utils/math/math_vector.h"


namespace Regularization
{

class Dataset;
class Examples;
class BaseClassifier;

/**
 *  Virtual class, single implementations derive from this one.
 */
class DatasetConstraint {
public:
    DatasetConstraint(const Dataset& dataset_, const BaseClassifier* classifier_) :
        dataset(dataset_), classifier(classifier_) { }
    virtual DatasetConstraint* Clone() const = 0;

    // Destructor
    virtual ~DatasetConstraint() { }

    /*********************************************************
     * EVAL
     *********************************************************/

    // Check if the constraint involve the function id
    virtual bool InvolvesId(const Function::ID& id) const = 0;

    typedef std::unordered_map<Function::ID, Math::Vector<Value> > PerFunctionDerivative;
    // Compute the constraint value and its derivative is constraint_derivatives in not NULL.
    // For efficiency the derivative should be accumulated into constraint_derivatives
    // re-scaling it accordingly to mult.
    virtual Value Eval(const Value mult, PerFunctionDerivative* constraint_derivatives) = 0;

    // Get the name of the constraint
    virtual const std::string& GetName() const = 0;

    // Get the priority for the constraint
    virtual unsigned int GetConstraintPriority() const = 0;

    virtual void ResetClassifier(const BaseClassifier* new_classifier) {
        this->classifier = new_classifier;
    }

    virtual LogicCardinalityIndex GetCardinality() const = 0;

    // Normally the output_cardinality is also the target, as the constraint
    // should hold true for each output configuration.
    // However, in some special cases this is not the desired behavior and
    // this setter can be use to manually select the satisfaction degree.
    virtual void SetAllowedRelativeError(const Value allowed_relative_error_) = 0;

    virtual std::string ToString() const = 0;

protected:
    const Dataset& dataset;
    const BaseClassifier* classifier;
}; // end DatasetConstraint

} // end namespace Regularization

#endif /* DATASET_CONSTRAINT_H */
