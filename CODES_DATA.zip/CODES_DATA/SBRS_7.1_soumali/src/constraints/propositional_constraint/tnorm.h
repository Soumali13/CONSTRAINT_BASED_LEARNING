#ifndef __CONSTRAINTS_TNORM_H__
#define __CONSTRAINTS_TNORM_H__

#include <string>
#include <vector>

#include "data/basic_data_types.h"
#include "utils/general.h"


namespace Regularization {
class LearnFunction;

// Generic TNorm implementation.
class TNorm {
public:
    TNorm() {}
    virtual ~TNorm() { }

    ///////////////////////////
    // Virtual interface
    virtual TNorm* Clone() const = 0;
    virtual std::string ToString() const = 0;
    virtual Value AND(const std::vector<Value>& values) const = 0;
    virtual Value ANDDerivative(const std::vector<Value>& values,
                                const unsigned int index) const = 0;
    // Computes the derivatives with respect to each one of the input values.
    virtual void ANDDerivatives(const std::vector<Value>& values, std::vector<Value>* ovalues) const = 0;
    virtual void ORDerivatives(const std::vector<Value>& values, std::vector<Value>* ovalues) const = 0;
    ///////////////////////////

    virtual Value NOT(const Value value) const {
        // CHECK_IN_RANGE(value, static_cast<Value>(0), static_cast<Value>(1));
        return 1 - value; }
    virtual Value NOTDerivative(const Value value) const { return -1; }

    virtual Value OR(const std::vector<Value>& values) const {
        // Apply DeMorgan.
        std::vector<Value> nvalues(values.size());
        this->NegateValues(values, &nvalues);
        return this->NOT(this->AND(nvalues));
    }
    virtual Value ORDerivative(const std::vector<Value>& values,
                               const unsigned int index) const {
        std::vector<Value> nvalues(values.size());
        this->NegateValues(values, &nvalues);
               // for the external 1 -
        return NOTDerivative(0 /* any value works, assuming this is constant,
                                  expensive and correct is to pass
                                  AND(NegateValues(values), index) */ ) *
               // for the value by value 1 -
               NOTDerivative(0 /* any value works, assuming this is constant,
                                  expensive and correct is to pass
                                  AND(NegateValues(values), index) */ ) *
                             this->ANDDerivative(nvalues, index);
    }

    // Default is A=>B implemented as NOT A OR B
    virtual Value Residuum(const Value l, const Value r) const {
        std::vector<Value> values(2);
        values[0] = this->NOT(l);
        values[1] = r;
        return this->OR(values);
    }

    virtual Value ResiduumDerivative(const Value l, const Value r, const bool ld) const {
        std::vector<Value> values(2);
        values[0] = this->NOT(l);
        values[1] = r;
        return (ld ? this->NOTDerivative(0) : 1) * this->ORDerivative(values, ld);
    }

protected:
    virtual void NegateValues(const std::vector<Value>& values,
                              std::vector<Value>* nvalues) const;
};  // end TNorm
/////////////////////////////////////////

/////////////////////////////////////////
class MinimumTNorm : public TNorm {
public:
    MinimumTNorm() {}
    virtual ~MinimumTNorm() { }
    virtual TNorm* Clone() const { return new MinimumTNorm; };
    virtual std::string ToString() const { return "MINIMUM_TNORM"; }

    virtual Value AND(const std::vector<Value>& values) const;

    virtual Value ANDDerivative(const std::vector<Value>& values,
                                const unsigned int index) const;
    virtual void ANDDerivatives(const std::vector<Value>& values, std::vector<Value>* ovalues) const;
    virtual Value OR(const std::vector<Value>& values) const;
    virtual Value ORDerivative(const std::vector<Value>& values,
                                const unsigned int index) const;
    virtual void ORDerivatives(const std::vector<Value>& values, std::vector<Value>* ovalues) const;
    virtual Value Residuum(const Value l, const Value r) const {
        if (l <= r)  return 1;
        return r;
    }

    virtual Value ResiduumDerivative(const Value l, const Value r, const bool ld) const {
        if (l <= r)  return 0;
        return (ld ? 0 : 1);
    }
};  // end MinimumTNorm
/////////////////////////////////////////

/////////////////////////////////////////
class ProductTNorm : public TNorm {
public:
    ProductTNorm() {}
    virtual ~ProductTNorm() { }
    virtual TNorm* Clone() const { return new ProductTNorm; };
    virtual std::string ToString() const { return "PRODUCT_TNORM"; }

    virtual Value AND(const std::vector<Value>& values) const;
    virtual Value ANDDerivative(const std::vector<Value>& values,
                                const unsigned int index) const;
    // Computing der_j = \prod _{i=0}_{N} v[i] / v_j, dynamic programming is used to compute this
    // without doing divisions that are 12x-50x slower than multiplications, while preserving O(2n)
    // complexity.
    virtual void ANDDerivatives(const std::vector<Value>& values, std::vector<Value>* ovalues) const;
    // Could be done by the default, but this is faster as it avoid allocating
    // the value vector.
    virtual Value OR(const std::vector<Value>& values) const;
    // Could be done by the default, but this is faster as it avoid allocating
    // the value vector.
    virtual Value ORDerivative(const std::vector<Value>& values,
                               const unsigned int index) const;
    virtual void ORDerivatives(const std::vector<Value>& values, std::vector<Value>* ovalues) const;
    virtual Value Residuum(const Value l, const Value r) const;
    virtual Value ResiduumDerivative(const Value l, const Value r, const bool ld) const;
};  // end ProductTNorm
/////////////////////////////////////////

/////////////////////////////////////////
class LukasiewiczTNorm : public TNorm {
public:
    LukasiewiczTNorm() {}
    virtual ~LukasiewiczTNorm() { }
    virtual TNorm* Clone() const { return new LukasiewiczTNorm; };
    virtual std::string ToString() const { return "LUKASIEWICZ_TNORM"; }

    virtual Value AND(const std::vector<Value>& values) const;
    virtual Value ANDDerivative(const std::vector<Value>& values,
                                const unsigned int /* index */) const;
    virtual void ANDDerivatives(const std::vector<Value>& values, std::vector<Value>* ovalues) const;
    virtual Value OR(const std::vector<Value>& values) const;
    virtual Value ORDerivative(const std::vector<Value>& values,
                               const unsigned int /* index */) const;
    virtual void ORDerivatives(const std::vector<Value>& values, std::vector<Value>* ovalues) const;
    virtual Value Residuum(const Value l, const Value r) const {
        return (l < r ? 1 : 1 - l + r);
    }
    virtual Value ResiduumDerivative(const Value l, const Value r, const bool ld) const {
        if (l < r)  return 0;
        return (ld ? -1 : 1);
    }
};  // end LukasiewiczTNorm
/////////////////////////////////////////

/////////////////////////////////////////
class WeakLukasiewiczTNorm : public LukasiewiczTNorm {
public:
    WeakLukasiewiczTNorm() {}
    virtual ~WeakLukasiewiczTNorm() { }
    virtual TNorm* Clone() const { return new WeakLukasiewiczTNorm; };
    virtual std::string ToString() const { return "WEAK_LUKASIEWICZ_TNORM"; }

    virtual Value AND(const std::vector<Value>& values) const;
    virtual Value ANDDerivative(const std::vector<Value>& values,
                                const unsigned int index) const;
    virtual void ANDDerivatives(const std::vector<Value>& values, std::vector<Value>* ovalues) const;
};  // end WeakLukasiewiczTNorm
/////////////////////////////////////////

/////////////////////////////////////////
class TNormFactory {
public:
    typedef enum
    {
        PRODUCT_TNORM = 0,
        MINIMUM_TNORM = 1,
        LUKASIEWICZ_TNORM = 2,
        WEAK_LUKASIEWICZ_TNORM = 3,
        INVALID = 4
    } TYPE;

    static TNorm* Build(const TYPE norm);
    static TYPE TypeFromString(const std::string& norm_str);
    static std::string TypeToString(const TYPE norm);
    static TNorm* BuildFromString(const std::string& norm_str);
    inline static std::string ToString(const TNorm* tnorm) { return tnorm->ToString(); }
};  // end TNormFactory
/////////////////////////////////////////

}  // end Regularization

#endif  // __CONSTRAINTS_TNORM_H__
