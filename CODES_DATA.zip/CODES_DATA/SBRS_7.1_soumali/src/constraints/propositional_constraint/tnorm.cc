/*
 * tnorm.cc
 *
 *  Created on: Aug 27, 2017
 *      Author: michi
 */

#include "constraints/propositional_constraint/tnorm.h"


namespace Regularization {

void TNorm::NegateValues(const std::vector<Value>& values,
        std::vector<Value>* nvalues) const {
    nvalues->resize(values.size());
    for (unsigned int i = 0; i < values.size(); ++i) {
        (*nvalues)[i] = this->NOT(values[i]);
    }
}

Value MinimumTNorm::AND(const std::vector<Value>& values) const {
    Value min = values[0];
    for (unsigned int i = 1; i < values.size(); ++i) {
        if (values[i] < min) {
            min = values[i];
        }
    }
    return min;
}

Value MinimumTNorm::ANDDerivative(const std::vector<Value>& values,
        const unsigned int index) const {
    const Value min = values[index];
    for (unsigned int i = 0; i < values.size(); ++i) {
        if (i != index && values[i] < min) {
            return 0;
        }
    }
    return 1;
}

void MinimumTNorm::ANDDerivatives(const std::vector<Value>& values, std::vector<Value>* ovalues) const {
    DCHECK_EQ(2, ovalues->size(), values.size());
    std::fill(ovalues->begin(), ovalues->end(), 0);
    Index min_index = 0;
    Value min = values[0];
    for (unsigned int i = 1; i < values.size(); ++i) {
        if (values[i] < min) {
            min_index = i;
            min = values[i];
        }
    }
    (*ovalues)[min_index] = 1;
}

Value MinimumTNorm::OR(const std::vector<Value>& values) const {
    Value max = values[0];
    for (unsigned int i = 1; i < values.size(); ++i) {
        if (values[i] > max) {
            max = values[i];
        }
    }
    return max;
}

Value MinimumTNorm::ORDerivative(const std::vector<Value>& values,
        const unsigned int index) const {
    const Value max = values[index];
    for (unsigned int i = 0; i < values.size(); ++i) {
        if (i != index && values[i] > max) {
            return 0;
        }
    }
    return 1;
}
void MinimumTNorm::ORDerivatives(const std::vector<Value>& values, std::vector<Value>* ovalues) const {
    DCHECK_EQ(2, ovalues->size(), values.size());
    std::fill(ovalues->begin(), ovalues->end(), 0);
    Index max_index = 0;
    Value max = values[0];
    for (unsigned int i = 1; i < values.size(); ++i) {
        if (values[i] > max) {
            max_index = i;
            max = values[i];
        }
    }
    (*ovalues)[max_index] = 1;
}

Value ProductTNorm::AND(const std::vector<Value>& values) const {
    Value prod = 1;
    for (unsigned int i = 0; i < values.size(); ++i) {
        // CHECK_IN_RANGE(values[i], static_cast<Value>(0), static_cast<Value>(1));
        prod *= values[i];
    }
    return prod;
}

Value ProductTNorm::ANDDerivative(const std::vector<Value>& values,
        const unsigned int index) const {
    // Could be written as AND(values) / values[index] but it would require one division.
    Value prod = 1;
    for (unsigned int i = 0; i < values.size(); ++i) {
        if (i != index) {
            prod *= values[i];
        }
    }
    return prod;
}

// Computing der_j = \prod _{i=0}_{N} v[i] / v_j, dynamic programming is used to compute this
// without doing divisions that are 12x-50x slower than multiplications, while preserving O(2n)
// complexity.
void ProductTNorm::ANDDerivatives(const std::vector<Value>& values, std::vector<Value>* ovalues) const {
    DCHECK_EQ(2, ovalues->size(), values.size());
    Value prod = 1;
    for (unsigned int i = 0; i < values.size() - 1; ++i) {
        prod *= values[i];
        (*ovalues)[i + 1] = prod; // O[i] = \prod_{i=0}_{i-1} v[i]
    }
    prod = 1;
    for (unsigned int i = values.size() - 1; i > 0; --i) {
        prod *= values[i];
        (*ovalues)[i - 1] *= prod; // O[i] = \prod_{i=0}_{i-1} v[i] * \prod_{i=i+1}_{n-1} v[i]
    }
}

// Could be done by the default, but this is faster as it avoid allocating
// the value vector.
Value ProductTNorm::OR(const std::vector<Value>& values) const {
    Value prod = 1;
    for (unsigned int i = 0; i < values.size(); ++i) {
        // CHECK_IN_RANGE(values[i], static_cast<Value>(0), static_cast<Value>(1));
        prod *= 1 - values[i];
    }
    return 1 - prod;
}

// Could be done by the default, but this is faster as it avoid allocating
// the value vector.
Value ProductTNorm::ORDerivative(const std::vector<Value>& values,
        const unsigned int index) const {
    Value prod = 1;
    for (unsigned int i = 0; i < values.size(); ++i) {
        if (i != index) {
            // CHECK_IN_RANGE(values[i], static_cast<Value>(0), static_cast<Value>(1));
            prod *= 1 - values[i];
        }
    }
    // No sign change because there one minus for the external (1 - ...)and the minus from the
    // single (1 - values).
    return prod;
}

void ProductTNorm::ORDerivatives(const std::vector<Value>& values, std::vector<Value>* ovalues) const {
    DCHECK_EQ(2, ovalues->size(), values.size());
    Value prod = 1;
    for (unsigned int i = 0; i < values.size() - 1; ++i) {
        prod *= 1 - values[i];
        (*ovalues)[i + 1] = prod;  // O[i] = \prod_{i=0}_{i-1} v[i]
    }
    prod = 1;
    for (unsigned int i = values.size() - 1; i > 0; --i) {
        prod *= 1 - values[i];
        (*ovalues)[i - 1] *= prod;  // O[i] = \prod_{i=0}_{i-1} v[i] * \prod_{i=i+1}_{n-1} v[i]
    }
    // No sign change because there one minus for the external (1 - ...)and the minus from the
    // single (1 - values).
}

Value ProductTNorm::Residuum(const Value l, const Value r) const {
    if (l < r)  return 1;
    const Value l_limited = (l > 0.00001 ? l : 0.00001);
    return r / l_limited;
}

Value ProductTNorm::ResiduumDerivative(const Value l, const Value r, const bool ld) const {
    if (l < r)  return 0;
    const Value l_limited = (l > 0.00001 ? l : 0.00001);
    if (ld)  return -0.5 * r / (l_limited * l_limited);
    return 1 / l_limited;
}

Value LukasiewiczTNorm::AND(const std::vector<Value>& values) const {
    Value sum = static_cast<Value>(1) - values.size();
    for (unsigned int i = 0; i < values.size(); ++i) {
        sum += values[i];
    }
    return (sum > 0 ? sum : 0);
}

Value LukasiewiczTNorm::ANDDerivative(const std::vector<Value>& values,
        const unsigned int /* index */) const {
    Value sum = 0;
    for (unsigned int i = 0; i < values.size(); ++i) {
        sum += values[i];
    }
    return (sum > 0 ? 1 : 0);
    // More elegant but it requires one extra virtual call.
    // return (this->AND(values) > 0 ? 1 : 0);
}

void LukasiewiczTNorm::ANDDerivatives(const std::vector<Value>& values, std::vector<Value>* ovalues) const {
    DCHECK_EQ(2, ovalues->size(), values.size());
    std::fill(ovalues->begin(), ovalues->end(), this->AND(values) > 0 ? 1 : 0);
}

Value LukasiewiczTNorm::OR(const std::vector<Value>& values) const {
    // Faster implementation than using demorgan.
    Value sum = 0;
    for (unsigned int i = 0; i < values.size(); ++i) {
        // CHECK_IN_RANGE(values[i], static_cast<Value>(0), static_cast<Value>(1));
        sum += values[i];
    }
    return (sum > 1 ? 1 : sum);
}

Value LukasiewiczTNorm::ORDerivative(const std::vector<Value>& values,
        const unsigned int /* index */) const {
    Value sum = 0;
    for (unsigned int i = 0; i < values.size(); ++i) {
        sum += values[i];
    }
    return (sum > 1 ? 0 : 1);
    // More elegant but it requires one extra virtual call.
    // return (this->OR(values) < 1 ? 1 : 0);
}

void LukasiewiczTNorm::ORDerivatives(const std::vector<Value>& values, std::vector<Value>* ovalues) const {
    DCHECK_EQ(2, ovalues->size(), values.size());
    std::fill(ovalues->begin(), ovalues->end(), this->OR(values) > 1 ? 0 : 1);
}

Value WeakLukasiewiczTNorm::AND(const std::vector<Value>& values) const {
    Value min = values[0];
    for (unsigned int i = 1; i < values.size(); ++i) {
        if (values[i] < min)
            min = values[i];
    }
    return min;
}

Value WeakLukasiewiczTNorm::ANDDerivative(const std::vector<Value>& values,
        const unsigned int index) const {
    const Value min = values[index];
    for (unsigned int i = 0; i < values.size(); ++i) {
        if (i != index && values[i] < min)  return 0;
    }
    return 1;
}

void WeakLukasiewiczTNorm::ANDDerivatives(const std::vector<Value>& values, std::vector<Value>* ovalues) const {
    DCHECK_EQ(2, ovalues->size(), values.size());
    std::fill(ovalues->begin(), ovalues->end(), 0);
    Index min_index = 0;
    Value min = values[0];
    for (unsigned int i = 1; i < values.size(); ++i) {
        if (values[i] < min) {
            min_index = i;
            min = values[i];
        }
    }
    (*ovalues)[min_index] = 1;
}

/* static */
TNorm* TNormFactory::Build(const TYPE norm) {
    switch (norm) {
    case PRODUCT_TNORM:
        return new ProductTNorm;
    case MINIMUM_TNORM:
        return new MinimumTNorm;
    case LUKASIEWICZ_TNORM:
        return new LukasiewiczTNorm;
    case WEAK_LUKASIEWICZ_TNORM:
        return new WeakLukasiewiczTNorm;
    default:
        FAULT("Invalid Tnorm requested.");
    }
    // We should never get here.
    return NULL;
}

/* static */
TNormFactory::TYPE TNormFactory::TypeFromString(const std::string& norm_str) {
    if (norm_str == "PRODUCT_TNORM")
        return PRODUCT_TNORM;
    if (norm_str == "MINIMUM_TNORM")
        return MINIMUM_TNORM;
    if (norm_str == "LUKASIEWICZ_TNORM")
        return LUKASIEWICZ_TNORM;
    if (norm_str == "WEAK_LUKASIEWICZ_TNORM")
        return WEAK_LUKASIEWICZ_TNORM;
    WARN("Invalid Tnorm requested: " << norm_str);
    return INVALID;
}

/* static */
TNorm* TNormFactory::BuildFromString(const std::string& norm_str) {
    const TYPE type = TNormFactory::TypeFromString(norm_str);
    return TNormFactory::Build(type);
}

/* static */
std::string TNormFactory::TypeToString(const TYPE norm) {
    switch (norm) {
    case PRODUCT_TNORM:
        return "PRODUCT_TNORM";
    case MINIMUM_TNORM:
        return "MINIMUM_TNORM";
    case LUKASIEWICZ_TNORM:
        return "LUKASIEWICZ_TNORM";
    case WEAK_LUKASIEWICZ_TNORM:
        return "WEAK_LUKASIEWICZ_TNORM";
    default:
        return "INVALID";
    }
    // We should never get here.
    return "";
}

}  // end Regularization
