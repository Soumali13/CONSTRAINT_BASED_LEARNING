#include "constraints/propositional_constraint/propositional_constraint.h"

#include <sstream>

#include "classifier/functions/given_function.h"
#include "classifier/functions/learn_function/learn_function.h"
#include "classifier/functions/learn_function/squashing.h"
#include "utils/gflags/gflags/gflags.h"
#include "utils/string_utils.h"


DECLARE_bool(apply_squashing_function_on_function_output);

namespace Regularization {

PropositionalFormulaConstraint::PropositionalFormulaConstraint() :
                logic_connective(INVALID), tnorm(NULL),
                formula_output(0), function(NULL), size(0) {
}

PropositionalFormulaConstraint& PropositionalFormulaConstraint::operator=(
        const PropositionalFormulaConstraint& formula) {
    if (this == &formula)  return *this;  // no auto-assignment.

    logic_connective = formula.logic_connective;
    tnorm = (formula.tnorm != NULL ? formula.tnorm->Clone() : NULL);
    formula_output = formula.formula_output;
    subformula_outputs = formula.subformula_outputs;
    subformula_output_derivatives = formula.subformula_output_derivatives;

    function = formula.function;
    variables = formula.variables;
    variables_as_string = formula.variables_as_string;
    size = formula.size;
    function_ids = formula.function_ids;
    function_ids_vec = formula.function_ids_vec;
    variable_set = formula.variable_set;

    subformulas.clear();
    subformulas.reserve(formula.subformulas.size());
    for (unsigned int i = 0; i < formula.subformulas.size(); ++i)
        subformulas.push_back(formula.subformulas[i]);

    if (!FLAGS_apply_squashing_function_on_function_output) {
        // If squashing was not applied on the functions, we need to apply it here.
        SquashingFunction::BuildMapFromFlags(function_ids_vec, &squashing_functions);
    }
    return *this;
}

PropositionalFormulaConstraint::PropositionalFormulaConstraint(
        const PropositionalFormulaConstraint& formula) :
                logic_connective(formula.logic_connective),
                subformulas(formula.subformulas),
                tnorm(formula.tnorm != NULL ? formula.tnorm->Clone() : NULL),
                formula_output(formula.formula_output),
                subformula_outputs(formula.subformula_outputs),
                subformula_output_derivatives(formula.subformula_output_derivatives),
                function(formula.function),
                variables(formula.variables),
                variables_as_string(formula.variables_as_string),
                size(formula.size),
                function_ids(formula.function_ids),
                function_ids_vec(formula.function_ids_vec),
                variable_set(formula.variable_set) {
    if (!FLAGS_apply_squashing_function_on_function_output) {
        SquashingFunction::BuildMapFromFlags(function_ids_vec, &squashing_functions);
    }
}

// Initializes the simplest formula which is composed by a single literal or atom.
PropositionalFormulaConstraint::PropositionalFormulaConstraint(
        const Function* function_,
        const std::vector<std::string>& variables_,
        const std::string& logic_connective_str,
        const TNorm* tnorm_) :
                logic_connective(PropositionalFormulaConstraint::FromString(logic_connective_str)),
                tnorm(tnorm_ != NULL ? tnorm_->Clone() : NULL),
                formula_output(0),
                function(function_), variables(variables_),
                variables_as_string(StringUtils::ContainerToString(variables, "_", "")),
                size(1) {
    CHECK_NE_NULL(function);
    CHECK_EQ(static_cast<Index>(variables.size()), function->GetArity());
    CHECK(logic_connective == NOT || logic_connective == NONE);

    subformula_outputs.resize(1);
    subformula_output_derivatives.resize(1);

    function_ids.insert(function->GetId());
    function_ids_vec.push_back(function->GetId());

    variable_set.insert(variables);

    if (!FLAGS_apply_squashing_function_on_function_output) {
        SquashingFunction::BuildMapFromFlags(function_ids_vec, &squashing_functions);
    }
}

// Initializes the recursive step where a formula is the composition of any other formula.
PropositionalFormulaConstraint::PropositionalFormulaConstraint(
        const std::vector<PropositionalFormulaConstraint>& formulas_,
        const std::string& logic_connective_str,
        const TNorm* tnorm_) :
                logic_connective(PropositionalFormulaConstraint::FromString(logic_connective_str)),
                subformulas(formulas_),
                tnorm(tnorm_ != NULL ? tnorm_->Clone() : NULL),
                formula_output(0),
                function(NULL) {
    switch (logic_connective) {
    case NOT:
    case NONE:
        CHECK_EQ(static_cast<int>(subformulas.size()), 1);
        size += subformulas[0].size;
        subformula_outputs.resize(1);
        subformula_output_derivatives.resize(1);
        break;

    case RESIDUUM:
        CHECK_EQ(static_cast<int>(subformulas.size()), 2);
        size += subformulas[0].size + subformulas[1].size;
        subformula_outputs.resize(2);
        subformula_output_derivatives.resize(2);
        break;

    case AND:
    case OR:
        CHECK_GE(static_cast<int>(subformulas.size()), 2);
        for (unsigned int i = 0; i < subformulas.size(); ++i) {
            size += subformulas[i].size;
        }
        subformula_outputs.resize(subformulas.size());
        subformula_output_derivatives.resize(subformulas.size());
        break;

    default:
        FAULT("Invalid Logic Connective " << ToString(logic_connective) <<
              " for propositional constraint " << this->ToString());
    }

    for (unsigned int i = 0; i < subformulas.size(); ++i) {
        FunctionIDs::const_iterator iter = subformulas[i].function_ids.begin();
        for (; iter != subformulas[i].function_ids.end(); ++iter) {
            function_ids.insert(*iter);
        }
        FormulaVariableSet::const_iterator iter1 = subformulas[i].variable_set.begin();
        for (; iter1 != subformulas[i].variable_set.end(); ++iter1) {
            variable_set.insert(*iter1);
        }
    }
    // Copy the set into the vector
    function_ids_vec.reserve(function_ids.size());
    for (FunctionIDs::const_iterator iter = function_ids.begin();
         iter != function_ids.end(); ++iter) {
        function_ids_vec.push_back(*iter);
    }

    if (!FLAGS_apply_squashing_function_on_function_output) {
        SquashingFunction::BuildMapFromFlags(function_ids_vec, &squashing_functions);
    }
}


PropositionalFormulaConstraint::~PropositionalFormulaConstraint() {
    if (tnorm != NULL) {
        delete tnorm;
    }
}

Value PropositionalFormulaConstraint::Eval(const VariablesToPatternMap& patterns) {
    if (function != NULL) {
        VariablesToPatternMap::const_iterator iter = patterns.find(variables_as_string);
        if (iter == patterns.end()) {
            FAULT("Could not resolve variables " << StringUtils::ContainerToString(variables, " ") <<
                " in the provided map");
        }
        const Pattern* pattern = iter->second;
        Value value = 0;
        // TODO(michi): find a better way to deal with NULL patterns, which can occur when evaluating
        // a given function on an unknown point for which its default value should be returned.
        if (pattern == NULL) {
            const GivenFunction* gf = dynamic_cast<const GivenFunction*>(function);
            CHECK_NE_NULL_WITH_MESSAGE(gf, "No pattern found for function that is not GIVEN");
            value = gf->GetDefaultValue();
        } else {
            const SquashingFunction* squashing_function = this->GetSquashingFunction(function->GetId());
            value = (squashing_function == NULL ?
                    function->Eval(*pattern) : squashing_function->LIMIT(function->Eval(*pattern)));
        }

        formula_output = (logic_connective == NOT ? tnorm->NOT(value) : value);
    } else if (logic_connective == NOT) {
        subformula_outputs[0] = subformulas[0].Eval(patterns);
        formula_output = tnorm->NOT(subformula_outputs[0]);
    } else if (logic_connective == RESIDUUM) {
        subformula_outputs[0] = subformulas[0].Eval(patterns);
        subformula_outputs[1] = subformulas[1].Eval(patterns);
        // MESSAGE("RES " << tnorm->Residuum(subformulas[0].Eval(patterns), subformulas[1].Eval(patterns)));
        formula_output = tnorm->Residuum(subformula_outputs[0], subformula_outputs[1]);
    } else {
        for (unsigned int i = 0; i < subformulas.size(); ++i) {
            subformula_outputs[i] = subformulas[i].Eval(patterns);
        }
        if (logic_connective == AND) {
            // MESSAGE("AND " << tnorm->AND(values));
            formula_output = tnorm->AND(subformula_outputs);
        } else if (logic_connective == OR) {
            // MESSAGE("OR " << tnorm->OR(values));
            formula_output = tnorm->OR(subformula_outputs);
        } else {
            FAULT("Invalid connective " << logic_connective << " we should never get here!");
        }
    }
    return formula_output;
}

// This assumes that Eval has been already computed on the same grounding.
bool PropositionalFormulaConstraint::AccumulateGradient(
        const VariablesToPatternMap& patterns,
        const LearnFunction& derivationFunction,
        const Value weight,
        Math::Vector<Value>* derivative) /* const */ {
    if (weight == 0 ||  // can happen when recursively calling this over subformulas.
        !this->InvolvesId(derivationFunction.GetId())) {
        return false;
    }

    if (function != NULL) {  // This should mean that function==derivationFunction
        // CHECK_EQ(function->GetId(), derivationFunction.GetId());

        // VariablesToPatternMap::const_iterator iter = patterns.find(variables);
        VariablesToPatternMap::const_iterator iter = patterns.find(variables_as_string);
        if (iter == patterns.end()) {
            FAULT("Could not resolve variables " << StringUtils::ContainerToString(variables, " ") <<
                  " in the provided grounding map.");
        }
        const Pattern* pattern = iter->second;

        const SquashingFunction* squashing_function = this->GetSquashingFunction(function->GetId());
        const Value der_weight =
                (logic_connective == NOT ? tnorm->NOTDerivative(this->formula_output) : 1) * weight *
                (squashing_function != NULL ?
                 squashing_function->LIMIT_DERIVATIVE(this->formula_output) : 1.0f);
        return derivationFunction.AccumulateGradient(*pattern, der_weight, derivative);
    }

    bool ret = false;
    if (logic_connective == NOT) {
        ret = subformulas[0].AccumulateGradient(
                patterns, derivationFunction, tnorm->NOTDerivative(subformula_outputs[0]) * weight,
                derivative);
    } else if (logic_connective == RESIDUUM) {
        subformula_output_derivatives[0] =
                tnorm->ResiduumDerivative(subformula_outputs[0], subformula_outputs[1], true);
        subformula_output_derivatives[1] =
                tnorm->ResiduumDerivative(subformula_outputs[0], subformula_outputs[1], false);
        ret |= subformulas[0].AccumulateGradient(
                patterns, derivationFunction, subformula_output_derivatives[0] * weight, derivative);
        ret |= subformulas[1].AccumulateGradient(
                patterns, derivationFunction, subformula_output_derivatives[1] * weight, derivative);
        return ret;
    } else {
        if (logic_connective == AND) {
            tnorm->ANDDerivatives(subformula_outputs, &subformula_output_derivatives);
        } else if (logic_connective == OR) {
            tnorm->ORDerivatives(subformula_outputs, &subformula_output_derivatives);
        } else {
            FAULT("Invalid connective " << logic_connective << " we should never get here!");
        }

        for (unsigned int i = 0; i < subformulas.size(); ++i) {
            ret |= subformulas[i].AccumulateGradient(
                    patterns, derivationFunction, subformula_output_derivatives[i] * weight, derivative);
        }
    }

    return ret;
}

std::string PropositionalFormulaConstraint::ToString() const {
    std::ostringstream s;
    s << "[";
    const std::string logic_connective_str =
            (logic_connective == NONE ? "" : ToString(logic_connective) + " ");
    if (function != NULL) {
        if (logic_connective == NOT) {
            s << logic_connective_str << " ";
        }
        s << function->GetId() << "("
          << StringUtils::VectorToString(variables, ",", "") << ")";
    } else if (logic_connective == NOT) {
        CHECK_EQ(static_cast<int>(subformulas.size()), 1);
        s << logic_connective_str << subformulas[0].ToString();
    } else {
        CHECK_GE(static_cast<int>(subformulas.size()), 2);
        s << subformulas[0].ToString();
        for (unsigned int i = 1; i < subformulas.size(); ++i) {
            s << " " << logic_connective_str << subformulas[i].ToString();
        }
    }
    s << "]";
    return s.str();
}

std::string PropositionalFormulaConstraint::GroundedToString(
        const VariablesToPatternMap& patterns) const {
    std::ostringstream s;
    s << "[";
    if (function != NULL) {
        // VariablesToPatternMap::const_iterator iter = patterns.find(variables);
        VariablesToPatternMap::const_iterator iter = patterns.find(variables_as_string);
        if (iter == patterns.end()) {
            FAULT("Could not resolve variables " << StringUtils::ContainerToString(variables, " ") <<
                  " in the provided map");
        }
        const Pattern* pattern = iter->second;
        if (logic_connective == NOT) {
            s << ToString(logic_connective) << " ";
        }
        s << function->GetId() << "(" << pattern->GetName() << ")";
    } else if (logic_connective == NOT) {
        s << ToString(logic_connective) << subformulas[0].GroundedToString(patterns);
    } else {
        s << subformulas[0].GroundedToString(patterns);
        for (unsigned int i = 1; i < subformulas.size(); ++i) {
            s << " " << ToString(logic_connective) << " " << subformulas[i].GroundedToString(patterns);
        }
    }
    s << "]";
    return s.str();
}

std::string PropositionalFormulaConstraint::GroundedToStringWithEvalValues(
        const VariablesToPatternMap& patterns) {
    std::ostringstream s;
    s << "[";
    if (function != NULL) {
        VariablesToPatternMap::const_iterator iter = patterns.find(variables_as_string);
        if (iter == patterns.end()) {
            FAULT("Could not resolve variables " << StringUtils::ContainerToString(variables, " ") <<
                  " in the provided map");
        }
        const Pattern* pattern = iter->second;
        if (logic_connective == NOT) {
            s << ToString(logic_connective) << " ";
        }

        s << function->GetId() << "(" << pattern->GetName() << ")=" << formula_output;
    } else if (logic_connective == NOT) {
        s << ToString(logic_connective) << subformulas[0].GroundedToStringWithEvalValues(patterns); // << "=" << formula_output;
    } else {
        s << subformulas[0].GroundedToStringWithEvalValues(patterns)<< "=" << subformula_outputs[0];
        for (unsigned int i = 1; i < subformulas.size(); ++i) {
            s << " " << ToString(logic_connective) << " " << subformulas[i].GroundedToStringWithEvalValues(patterns); // << "=" << subformula_outputs[i];
        }
    }
    s << "]=" << formula_output;
    return s.str();
}
}  // end Regularization
