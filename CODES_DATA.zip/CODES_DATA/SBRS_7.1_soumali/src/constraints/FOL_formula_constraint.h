/*
 * File:   FOL_formula_constraint.h
 * Author: claudio
 *
 * Created on May 20, 2011, 11:49 AM
 */

#ifndef FOL_FORMULA_CONSTRAINT_H
#define	FOL_FORMULA_CONSTRAINT_H

#include <map>
// #include <unordered_map>  // Because missing support for hash<int128> on some systems.
#include <string>
#include <vector>
#include <utility>

#include "data/basic_data_types.h"
#include "constraints/dataset_constraint.h"
#include "constraints/propositional_constraint/propositional_constraint.h"
#include "data/FOL_formula.h"
#include "utils/containers.h"
#include "utils/math/math_vector.h"


namespace Regularization
{
class BaseClassifier;
class LossFunction;
class Dataset;
class Examples;

class FOLFormulaConstraint : public DatasetConstraint {
public:
    /*
     * The multimap contains the predicates (literals) involved in the constraint.
     * The key of the map is the name of the predicate while the value is
     * the correspondent predicate. Note: A FOL formula can contain more than one
     * literal with same name.
     */
    typedef std::multimap<std::string, const FOLFormula::Literal*> PredicateToLiteralsMultiMap;

    // Constructor, gets the FOLformula and builds the constraint using the functions,
    // dataset and examples.
    FOLFormulaConstraint(
            const FOLFormula& FOLformula_,
            const Dataset& dataset_,
            const BaseClassifier* classifier_,
            const Examples& examples_,
            const LossFunction& constraint_loss_function_);
    virtual DatasetConstraint* Clone() const;

    /*
     * Destructor
     */
    virtual ~FOLFormulaConstraint() { }

    // Check if the constraint involve the function id
    virtual bool InvolvesId(const Function::ID& id) const;

    // Compute the constraint value and its derivative is constraint_derivatives in not NULL.
    // For efficiency the derivative should be accumulated into constraint_derivatives
    // rescaling it accordingly to mult.
    virtual Value Eval(const Value mult, PerFunctionDerivative* constraint_derivatives);

    // Get the name of the constraint (print the FOL formula)
    virtual const std::string& GetName() const;

    virtual LogicCardinalityIndex GetCardinality() const { return cardinality_contributions; }

    virtual std::string ToString() const;

    // Get the priority for the constraint
    virtual unsigned int GetConstraintPriority() const;

    // Normally the constraint should hold true for each output configuration and the
    // satisfaction of the constrain should be full ()
    // However, in some special cases this is not the desired behaviour and
    // this setter can be use to manually select the satisfaction degree that is allowed
    // with no penalty.
    virtual void SetAllowedRelativeError(const Value allowed_relative_error_);

    virtual void ResetClassifier(const BaseClassifier* new_classifier);

private:
    // Set the parameters for the constraint. Move back to private?
    void Setup();

    // Build the constraint
    bool BuildPropositionalConstraint();
    bool BuildPropositionalConstraintInternal(
            const FOLFormula::PropositionalFormula& propositional_formula,
            PropositionalFormulaConstraint* constraint);

    // Decide if save candidates for given predicate optimization
    inline bool doOptimization() const {
        return givenLiteral.IsValid();
    }

    // Reset Temp Structures for quantified L1 optimization
    void Reset(bool reset_derivatives);
    void UpdateIntermediatePropositionalValuesHelper(
            const Value value,
            const Value max_value,
            const PerFunctionDerivative* derivative_values,  // null if not computed.
            const unsigned int level);
    void UpdateIntermediatePropositionalValues(
            const LogicCardinalityIndex cardinalityIndex, const Value value,
            const PerFunctionDerivative* derivative_values);  // null if not computed.
    void ForwardUpdateIntermediatePropositionalValues(
            const LogicCardinalityIndex cardinalityIndex,
            const LogicCardinalityIndex new_cardinalityIndex,
            const bool compute_derivatives);

    // Build the formula Pattern to give in input to the constraint runEval.
    void BuildFormulaPatterns(const LogicCardinalityIndex cardinalityIndex,
            PropositionalFormulaConstraint::VariablesToPatternMap* variables_to_pattern);

    // Compute the prebuilt formula patterns and store them in
    // this->prebuiltformulaPatterns. Only up to FLAGS_prebuild_constraint_patterns_size
    // patterns will be stored (trade off memory/speed).
    void ComputePreBuildFormulaPatterns();

    // Debug methods to get the variable indexes and pattern names at a given cardinality.
    std::vector<LogicCardinalityIndex> GetPatternsAtCardinality(
            const LogicCardinalityIndex cardinalityIndex);
    std::vector<std::string> GetPatternNamesAtCardinality(
            const LogicCardinalityIndex cardinalityIndex);

    // DROP
    // Compute the exact output cardinality for given-optimized formulas.
    // For non-pptimzed formula the default value is already correctly computed.
    // void MaybeAdjustOutputContributions();

    // Map storing the prebuilt formula patterns by cardinality, it may be empty,
    // in that case the patterns will be built on the fly.
    typedef std::map<LogicCardinalityIndex, PropositionalFormulaConstraint::VariablesToPatternMap>
        Cardinality2FormulaPatternsMap;
    Cardinality2FormulaPatternsMap prebuiltformulaPatterns;

    // The FOL Formula
    const FOLFormula& fol_formula;

    // These are used only to compute the cardinality skips during setup.
    // We still store them top allow cloning the constraint.
    const Examples& examples;

    // The constraint that represents the quantifier-free portion (CNF) of the formula
    PropositionalFormulaConstraint propositional_formula_constraint;

    // The vector is used to compute when a variable has completed a loop.
    // i.e. a variable has already taken all values in the domain.
    // This is the product of all variable cardinalities on the right side of the current variable.
    // variablesRightContextCardinality[0] = 1
    // ...
    // variablesRightContextCardinality[i] = \prod_{j=0}^{i-1} DomainCardinality_of_i-th_var
    // ...
    // variablesRightContextCardinality[quantifiedVariablesSize] = cardinality
    std::vector<LogicCardinalityIndex> variablesRightContextCardinality;

    // Vector with the cardinality of each variable
    std::vector<LogicCardinalityIndex> variablesCardinality;

    // The constraint cardinality.
    // Examples:
    // forall x forall y ... => |X||Y|
    // exists_n x forall y ... => |X||Y|
    // forall z exists_n x forall y ... => |Z||X||Y|
    LogicCardinalityIndex cardinality;

    // This determines how many total configurations will be computed to eval the constraint over the dataset.
    // This equals cardinality unless there is a given-optimization.
    // This is a rough estimate of the cost of running this constraint over the dataset.
    LogicCardinalityIndex cardinality_contributions;

    // The desired level of satisfiability of the constraint.
    // This is typically computed directly by the constraint assuming that it
    // should hold true in its output configurations (that can be a subset of the
    // total configurations when using a exists_N on the outer variable level).
    // If the default is not what desired, it can be overwritten to modify the target.
    Value allowed_relative_error;

    // optimization: given predicate optimization
    // The map of the indexes used for given predicate optimization.
    // The key of the map is the index of the current pattern while the value
    // is the next pattern index that must be evaluated.
    typedef std::map<LogicCardinalityIndex, LogicCardinalityIndex> CardinalitySkips;
    CardinalitySkips cardinality_skips;

    // if not NULL optimization is enabled. Please note that a simple check on
    // cardinality_skips.size() is not correct as there could be no valid
    // instantiation of a variable in a domain but stil do the optimization
    // (which would entirely skip a rule in that case).
    const FOLFormula::Literal givenLiteral;

    // Non const, these are copied and then reversed in order.
    FOLFormula::QuantifiedVariables quantified_variables;
    // The variables in their initial order (human-read from left-to-right).
    const FOLFormula::QuantifiedVariables quantified_variables_initial_order;

    // Map variable to position, like x->0 y->1 ...
    std::map<std::string, int> variable_name_to_position;
    // As above but as a vector, it maybe faster to search here for a small number of variables.
    std::vector<std::pair<std::string, int> > variable_name_to_position_vec;

    const Index quantified_variable_size;

    // loss function for constraint
    const LossFunction& constraint_loss_function;

    // Struct that define a pair between the value of the constraint for a specific configuration
    // of the grounded variables and the correspondent derivative for each function.
    // Overloading of operator function permits to order the vector of this elements with a specific sorting.
    struct IntermediatePropositionalValues {
        Value value;
        Value max_value;  // max value obtainable if all evaluations are perfectly true (value==1).

        // Map functionID->derivativeVector.
        PerFunctionDerivative der;

        inline void Copy(const IntermediatePropositionalValues& val) {
            value = val.value;
            der = val.der;
        }
        inline IntermediatePropositionalValues() :
            value(0), max_value(0) {
        }
        inline IntermediatePropositionalValues(const Value value_, const Value max_value_) :
            value(value_), max_value(max_value_)  {
        }
        inline IntermediatePropositionalValues(const Value value_, const Value max_value_, const PerFunctionDerivative& der_) :
            value(value_), max_value(max_value_), der(der_) {
        }
        inline friend void swap(IntermediatePropositionalValues& a, IntermediatePropositionalValues& b) {
            std::swap(a.value, b.value);
            std::swap(a.max_value, b.max_value);
            std::swap(a.der, b.der);
        }
    };

    struct IntermediatePropositionalValuesComparator {
        inline bool operator()(const IntermediatePropositionalValues* a, const IntermediatePropositionalValues* b) {
            return a->value > b->value;  // a->value < b->value for loss applied inside.
        }
    };
    // Derivative and value placeholder for all entries relative to one variable. One entry is
    // needed for exist and forall quantifiers, more than one element needed for existN quantifiers.
    class PerVariableIntermediatePropositionalValues {
    private:
        std::vector<IntermediatePropositionalValues> elements;  // size=N > 1 for existsN only
        typedef std::vector<IntermediatePropositionalValues*> IntermediatePropositionalValuesContainer;
        typedef std::PrereservedPriorityQueue<IntermediatePropositionalValues*,
                IntermediatePropositionalValuesComparator> IntermediatePropositionalValuesQueue;
        // Rearranges the pointers to elements, so that sum of values can be performed on elements
        IntermediatePropositionalValuesQueue elements_queue;  // for existsN only
        PerFunctionDerivative sum_derivatives;  // computed if SumDerivatives() is called
        int valid_elements;
        int N;  // equal to the overall maximum number of elements.

        Value SumValues() const;
        Value SumMaxValues() const;
        PerFunctionDerivative* const SumDerivatives();
    public:
        PerVariableIntermediatePropositionalValues(
                const int N_, const IntermediatePropositionalValues& el);
        inline Value GetValue() const {
            // CHECK_GT(valid_elements, 0);
            if (N == 1)  return elements[0].value;  // for speed we threat it as special case.
            return SumValues();
        }

        inline Value GetMaxValue() const {
            // CHECK_GT(valid_elements, 0);
            if (N == 1)  return elements[0].max_value;  // for speed we threat it as special case.
            return SumMaxValues();
        }

        inline PerFunctionDerivative* GetDerivative() {
            // CHECK_GT(valid_elements, 0);
            if (N == 1)  return &(elements[0].der);  // for speed we threat it as special case.
            return SumDerivatives();
        }

        void Reset(const bool reset_derivatives);
        inline Value GetTopValue() const {  // Not used
            if (N == 1)  return elements[0].value;
            return elements_queue.top()->value;
        }

        // Called only for N==1
        void Add(const Value value_, const Value max_value_, const PerFunctionDerivative* der_);
        static void CopyElementHelper(const Value value_, const Value max_value_, const PerFunctionDerivative* der_,
                                      IntermediatePropositionalValues* dest);
        // Called also for N==1 (exists)
        void Set(const Value value_, const Value max_value_, const PerFunctionDerivative* der_);
    };

    // One per level. intermediate_propositional_values_derivatives[i] is the intermediate
    // derivative up to the i-th quantifier.
    // intermediate_propositional_values_derivatives[i][j] is the j-th
    // element, for exists and forall only j=0 is needed, for exists_n 0<j<n
    std::vector<PerVariableIntermediatePropositionalValues> intermediate_propositional_values;

    // Derivative at the propositional level, before quantifier aggregation.
    PerFunctionDerivative lower_level_intermediate_propositional_derivative;
}; // end FOLFormulaConstraint

} // end Regularization
#endif	/* FOL_FORMULA_CONSTRAINT_H */

