/*
 * FOL_formula_constraint.cc
 *
 *  Created on: 22/mar/2011
 *      Author: claudio
 */

#include "constraints/FOL_formula_constraint.h"

#include <algorithm>
#include <limits>
#include <string>
#include <utility>

#include "classifier/classifier.h"
#include "classifier/functions/function.h"
#include "constraints/propositional_constraint/propositional_constraint.h"
#include "data/dataset.h"
#include "data/examples.h"
#include "data/FOL_formula.h"
#include "train/loss/loss_function.h"
#include "utils/gflags/gflags/gflags.h"
#include "utils/stl_utils.h"


DEFINE_bool(normalize_constraints_by_cardinality, false,
        "Normalize each constraint by its cardinality.");

DEFINE_int32(prebuild_constraint_patterns_size, 2000,
        "How many patterns can be prebuilt, this trades memory for speed.");

using namespace std;
using namespace Regularization;

FOLFormulaConstraint::PerVariableIntermediatePropositionalValues::PerVariableIntermediatePropositionalValues(
        const int N_, const FOLFormulaConstraint::IntermediatePropositionalValues& el) :
        elements_queue(N_), valid_elements(0), N(N_) {
    CHECK_GT(N, 0);
    elements.reserve(N);
    for (int i = 0; i < N; ++i) {
        elements.push_back(el);
    }
}

Value FOLFormulaConstraint::PerVariableIntermediatePropositionalValues::SumValues() const {
    // The sum can always be computed on elements as elements_queue just points
    // to the single cells of elements
    Value sum = 0;
    for (int i = 0; i < valid_elements; ++i) {
        sum += elements[i].value;
    }
    return sum;
}

Value FOLFormulaConstraint::PerVariableIntermediatePropositionalValues::SumMaxValues() const {
    // The sum can always be computed on elements as elements_queue just points
    // to the single cells of elements
    Value sum = 0;
    for (int i = 0; i < valid_elements; ++i) {
        sum += elements[i].max_value;
    }
    return sum;
}

FOLFormulaConstraint::PerFunctionDerivative* const
FOLFormulaConstraint::PerVariableIntermediatePropositionalValues::SumDerivatives() {
    for (PerFunctionDerivative::iterator iter = sum_derivatives.begin();
         iter != sum_derivatives.end(); ++iter) {
        iter->second.SetAll(0);
    }

    for (int i = 0; i < valid_elements; ++i) {
        for (PerFunctionDerivative::const_iterator iter1 = elements[i].der.begin();
             iter1 != elements[i].der.end(); ++iter1) {
            if (sum_derivatives.find(iter1->first) == sum_derivatives.end())
                sum_derivatives[iter1->first].Copy(iter1->second);
            else
                sum_derivatives[iter1->first].AddInPlace(iter1->second);
        }
    }
    return &sum_derivatives;
}

// Called for forall, just aggregate the stats.
void FOLFormulaConstraint::PerVariableIntermediatePropositionalValues::Add(
        const Value value_, const Value max_value, const PerFunctionDerivative* der_) {
    CHECK_EQ(N, 1);  // for max speed we only support N=1 (all that we need for this operation).
    elements[0].value += value_;
    elements[0].max_value += max_value;
    if (der_ != NULL) {
        for (PerFunctionDerivative::const_iterator iter = der_->begin(); iter != der_->end(); ++iter) {
            elements[0].der[iter->first].AddInPlace(iter->second);
        }
    }
    valid_elements = 1;
}

/* static */
void FOLFormulaConstraint::PerVariableIntermediatePropositionalValues::CopyElementHelper(
        const Value value_, const Value max_value_, const PerFunctionDerivative* der_,
        FOLFormulaConstraint::IntermediatePropositionalValues* dest) {
    dest->value = value_;
    dest->max_value = max_value_;
    if (der_ != NULL) {
        for (PerFunctionDerivative::const_iterator iter = dest->der.begin();
                iter != dest->der.end(); ++iter) {
            PerFunctionDerivative::const_iterator iter1 = der_->find(iter->first);
            if (iter1 != der_->end())
                dest->der[iter->first].Copy(iter1->second);
            else
                dest->der[iter->first].SetAll(0);
        }
    }
}

// Called also for N==1 (exists)
void FOLFormulaConstraint::PerVariableIntermediatePropositionalValues::Set(
        const Value value_, const Value max_value_, const PerFunctionDerivative* der_) {
    if (N == 1) {  // special case for speed.
        // value is before-loss, so larger is better.
        if (valid_elements == 0 || value_ > elements[0].value) {
            CopyElementHelper(value_, max_value_, der_, &elements[0]);
            valid_elements = 1;
        }
    } else {
        if (valid_elements < N) {
            // using the allocated space in elements but accessing them via elements_queue
            CopyElementHelper(value_, max_value_, der_, &elements[valid_elements]);
            elements_queue.push(&elements[valid_elements]);
            ++valid_elements;
        } else if (value_ > elements_queue.top()->value) {
            IntermediatePropositionalValues* el = elements_queue.top();
            elements_queue.pop();
            CopyElementHelper(value_, max_value_, der_, el);
            elements_queue.push(el);
        }
    }
}

void FOLFormulaConstraint::PerVariableIntermediatePropositionalValues::Reset(
        const bool reset_derivatives) {
    for (int i = 0; i < valid_elements; ++i) {
        elements[i].value = 0;
        elements[i].max_value = 0;
        if (reset_derivatives) {
            for (PerFunctionDerivative::iterator iter = elements[i].der.begin();
                 iter != elements[i].der.end(); ++iter) {
                iter->second.SetAll(0);
            }
        }
    }

    // No clear() available, so we just build a new fresh container.
    elements_queue = IntermediatePropositionalValuesQueue(this->N);
    valid_elements = 0;
}

// Constructor
FOLFormulaConstraint::FOLFormulaConstraint(
        const FOLFormula& FOLformula_,
        const Dataset& dataset_,
        const BaseClassifier* classifier_,
        const Examples& examples_,  /* examples are needed just to compute the cardinality skips */
        const LossFunction& constraint_loss_function_) :
            DatasetConstraint(dataset_, classifier_),
            fol_formula(FOLformula_),
            examples(examples_),
            cardinality(0),
            cardinality_contributions(0),
            allowed_relative_error(0),
            givenLiteral(fol_formula.GetGivenLiteral()),
            quantified_variables_initial_order(fol_formula.GetQuantifiedVariables()),
            quantified_variable_size(fol_formula.GetQuantifiedVariables().size()),
            constraint_loss_function(constraint_loss_function_) {
    this->Setup();
}

DatasetConstraint* FOLFormulaConstraint::Clone() const {
    return new FOLFormulaConstraint(fol_formula, dataset, classifier, examples, constraint_loss_function);
}

void FOLFormulaConstraint::SetAllowedRelativeError(const Value allowed_relative_error_) {
    allowed_relative_error = allowed_relative_error_;
    CHECK_INE_RANGE(allowed_relative_error, static_cast<Value>(0.0), static_cast<Value>(1.0));
}

void FOLFormulaConstraint::ResetClassifier(const BaseClassifier* new_classifier) {
    DatasetConstraint::ResetClassifier(new_classifier);
    this->Setup();
}

// Get the name of the constraint (print the FOL formula)
const std::string& FOLFormulaConstraint::GetName() const
{
    return this->fol_formula.GetName();
}

std::string FOLFormulaConstraint::ToString() const {
    return this->fol_formula.ToString(false);
}


// Get the priority for the constraint
unsigned int FOLFormulaConstraint::GetConstraintPriority() const {
    return this->fol_formula.GetPriority();
}

bool FOLFormulaConstraint::BuildPropositionalConstraintInternal(
        const FOLFormula::PropositionalFormula& propositional_formula,
        PropositionalFormulaConstraint* constraint) {
    const FOLFormula::Literal& literal = propositional_formula.GetLiteral();
    const std::string& logic_connective = propositional_formula.GetLogicConnective();
    const std::vector<FOLFormula::PropositionalFormula>& subformulas =
            propositional_formula.GetSubFormulas();

    // tnorm will be owned by the constraint.
    const TNorm* tnorm = TNormFactory::Build(fol_formula.GetPropositionalNormType());
    CHECK_NE_NULL(tnorm);

    if (literal.IsValid()) {
        CHECK(subformulas.empty());  // atom it should have no subformulas
        CHECK(logic_connective == "NOT" ||
              logic_connective.empty());  // single atom can be negated but no other op

        *constraint = PropositionalFormulaConstraint(
                &(classifier->GetFunctionByIDOrDie(literal.GetId())),
                literal.GetPredicateVariables(),
                logic_connective, tnorm);
    } else {
        CHECK_WITH_MESSAGE(!logic_connective.empty(), "Can not read formula " + propositional_formula.ToString());
        if (logic_connective == "NOT") {
            CHECK_EQ(static_cast<int>(subformulas.size()), 1);
        } else {
            CHECK_GE(static_cast<int>(subformulas.size()), 2);
        }

        std::vector<PropositionalFormulaConstraint> subconstraints(subformulas.size());
        for (unsigned int i = 0; i < subformulas.size(); ++i) {
            BuildPropositionalConstraintInternal(subformulas[i], &subconstraints[i]);
        }
        *constraint = PropositionalFormulaConstraint(
                subconstraints, logic_connective, tnorm);
    }
    return true;
}

/*
 * Build the constraint depending on type of norm
 */
bool FOLFormulaConstraint::BuildPropositionalConstraint() {
    return BuildPropositionalConstraintInternal(
            this->fol_formula.GetPropositionalFormula(), &propositional_formula_constraint);
}

/*
 * Check if the constraint involve the function id
 */
bool FOLFormulaConstraint::InvolvesId(const Function::ID& id) const
{
    return fol_formula.InvolvesLiteral(id);
}

// Compute the prebuilt formula patterns and store them in
// this->prebuiltformulaPatterns. Only up to FLAGS_prebuild_constraint_patterns_size
// patterns will be stored (trade off memory/speed).
void FOLFormulaConstraint::ComputePreBuildFormulaPatterns() {
    int added = 0;
    LogicCardinalityIndex i = 0;
    if (this->doOptimization()) {
        i = cardinality_skips[0];  // which is always set.
    }
    for (; i < cardinality && added < FLAGS_prebuild_constraint_patterns_size; ++i) {
        PropositionalFormulaConstraint::VariablesToPatternMap variables_to_pattern;
        this->BuildFormulaPatterns(i, &variables_to_pattern);
        prebuiltformulaPatterns[i] = variables_to_pattern;
        ++added;
        if (this->doOptimization()) {
            CardinalitySkips::const_iterator iter = cardinality_skips.find(i);
            if (iter != cardinality_skips.end()) {
                i = iter->second - 1;  // -1 because ++i at the end of the loop.
            }
        }
    }
}

/*
 * Set the parameters for the constraint
 */
void FOLFormulaConstraint::Setup() {
    CHECK(this->BuildPropositionalConstraint());

    // Reverse the order of the vector of the variables. Inner most variables first, also all the
    // consequently build vectors like variablesRightContextCardinality will follow this reversed order.
    quantified_variables = quantified_variables_initial_order;
    std::reverse(quantified_variables.begin(), quantified_variables.end());
    variablesCardinality.clear();
    variablesRightContextCardinality.clear();
    variablesRightContextCardinality.reserve(quantified_variable_size + 1);  // last entry == cardinality
    cardinality = 1;
    cardinality_contributions = 1;
    // output_cardinality = 1;  // DROP
    variablesRightContextCardinality.push_back(1);  // last variable changes at each iteration
    int pos = 0;
    variable_name_to_position.clear();
    variable_name_to_position_vec.clear();
    for (FOLFormula::QuantifiedVariables::const_iterator it = quantified_variables.begin();
         it != quantified_variables.end(); ++it, ++pos) {
        // Store a map and vector to retrieve the variable index given its name
        variable_name_to_position[it->name] = pos;
        variable_name_to_position_vec.push_back(std::make_pair(it->name, pos));

        const FOLFormula::QUANTIFIER quantifier = it->quantifier;

        // compute the cardinality of the domain of the variable check if the
        // value of the cardinality is equal to the max representable number
        const LogicCardinalityIndex domainCardinality =
                dataset.GetSizeForDomain(fol_formula.GetVariableDomain(it->name));

        CHECK_GT_WITH_MESSAGE(
                (numeric_limits<LogicCardinalityIndex>::max() / cardinality), domainCardinality,
                "FOL formula cardinality overtakes the maximum representable value! "
                "Formula: " + fol_formula.ToString());
        cardinality *= domainCardinality;
        variablesCardinality.push_back(domainCardinality);
        variablesRightContextCardinality.push_back(cardinality);
        if (quantifier == FOLFormula::exists_N) {
            if (it->quantifier_num > 1.0) {
                cardinality_contributions *= it->quantifier_num;
            } else {  // a double value indicates the portion of domain for which the exists should hold.
                cardinality_contributions *= it->quantifier_num * domainCardinality;
            }
            // output_cardinality = it->quantifier_num;  // DROP
        } else if (quantifier == FOLFormula::forall) {
            cardinality_contributions *= domainCardinality;
            // output_cardinality *= domainCardinality;  // DROP
        } /* else if (quantifier == FOLFormula::exists) {  // nothing to do
            cardinality_contributions *= 1;
        } */

        if ((fol_formula.GetQuantifierNormType() == FOLFormula::LINF && !fol_formula.IsUniversallyQuantified()) ||
             fol_formula.GetQuantifierNormType() == FOLFormula::L1 ||
             fol_formula.GetQuantifierNormType() == FOLFormula::L2) {
            // check the consistency of the cardinality of the exists_N quantifier
            if (quantifier == FOLFormula::exists_N &&
                ((it->quantifier_num > 1.0 && it->quantifier_num > domainCardinality) ||
                 it->quantifier_num <= 0.0f)) {
                FAULT("Error: check the value of N " << it->quantifier_num <<
                      " for exists_N quantifier it is above the limit of domain cardinality " << domainCardinality);
            }
        }
    }

    // default, maybe changed after if optimization is enabled.
    cardinality_contributions = cardinality;

    if (givenLiteral.IsValid()) {
        // get information of given predicate
        const string& id = givenLiteral.GetId();
        // get the examples for the predicate
        const Examples::PerFunctionExamples* given_function_examples = examples.GetExamplesForPredicate(id);
        // Map index->num_entries_should_be_considered.
        map<LogicCardinalityIndex, LogicCardinalityIndex> index2interval;

        if (given_function_examples != NULL) {
            cardinality_contributions = 0;
            for (Examples::PerFunctionExamples::const_iterator it = given_function_examples->begin();
                 it != given_function_examples->end(); ++it) {
                const Examples::Example* example = (*it);
                const Value target = example->value;
                if (target <= static_cast<Value>(0)) {
                    continue;
                }

                vector<string> example_patterns;
                StringUtils::SplitToVector(example->pattern, &example_patterns, "_", false);
                CHECK_LE(static_cast<Index>(example_patterns.size()), quantified_variable_size);

                LogicCardinalityIndex index = 0;
                // Strong Assumption! Given predicate should (left-right fashion) depend only on the left most
                // (outer) quantified variables!
                for (unsigned int i = 0; i < example_patterns.size(); ++i) {
                    // Removed for speed.
                    index += dataset.GetPatternIndexInDomain(example_patterns[i]) *
                            variablesRightContextCardinality[quantified_variable_size - 1 - i];
                }
                const LogicCardinalityIndex interval =
                        variablesRightContextCardinality[quantified_variable_size - example_patterns.size()];
                index2interval[index] = interval;
                cardinality_contributions += interval;
            }
        }

        // If no examples for the predicate, one single giant skip is provided:
        // cardinality_skips[0] = cardinality;
        // First skip 0->0 if first element should not be skipped.
        std::map<LogicCardinalityIndex, LogicCardinalityIndex>::const_iterator iter = index2interval.begin();
        LogicCardinalityIndex end_interval = 0;
        cardinality_skips.clear();
        for (; iter != index2interval.end(); ++iter) {
            cardinality_skips[end_interval] = iter->first;
            end_interval = iter->first + iter->second - 1;
        }
        cardinality_skips[end_interval] = cardinality;
    }

    // Prebuild the formula patterns if requested.
    if (FLAGS_prebuild_constraint_patterns_size > 0) {
        ComputePreBuildFormulaPatterns();
    }

    if (classifier == NULL)
        return;

    PerFunctionDerivative derivativeMap;
    const vector<Function::ID>& function_ids = propositional_formula_constraint.GetIds();
    for (unsigned int f = 0; f < function_ids.size(); ++f) {
        const Function::ID& id = function_ids[f];
        if (classifier->IsLearnFunction(id)) {
            const Function& function = classifier->GetFunctionByIDOrDie(id);
            derivativeMap[id].Init(function.Size());
        }
    }
    lower_level_intermediate_propositional_derivative = derivativeMap;

    intermediate_propositional_values.clear();
    intermediate_propositional_values.reserve(quantified_variable_size);
    for (Index h = 0; h < quantified_variable_size; ++h) {
        const LogicCardinalityIndex domainCardinality =
                dataset.GetSizeForDomain(fol_formula.GetVariableDomain(quantified_variables[h].name));
        const int size = (quantified_variables[h].quantifier == FOLFormula::exists_N ?
                           (quantified_variables[h].quantifier_num > 1.0f ?
                            static_cast<int>(quantified_variables[h].quantifier_num) :
                            quantified_variables[h].quantifier_num * domainCardinality)
                          : 1);
        CHECK_GT_WITH_MESSAGE(size, 0, "Wrong exists_N, it should hold that N>0")
        intermediate_propositional_values.push_back(PerVariableIntermediatePropositionalValues(
                size, IntermediatePropositionalValues(0, 0, derivativeMap)));
    }
}

void FOLFormulaConstraint::Reset(bool reset_derivatives) {
    for (Index j = 0; j < quantified_variable_size; ++j) {
        intermediate_propositional_values[j].Reset(reset_derivatives);
    }
}


std::vector<LogicCardinalityIndex>
FOLFormulaConstraint::GetPatternsAtCardinality(const LogicCardinalityIndex cardinalityIndex) {
    std::vector<LogicCardinalityIndex> ret(quantified_variable_size);
    LogicCardinalityIndex left_cardinalityIndex = cardinalityIndex;

    for (int j = static_cast<int>(quantified_variable_size) - 1; j >= 0; --j) {  // cast needed because Index is unsigned
        ret[j] = left_cardinalityIndex / variablesRightContextCardinality[j];
        left_cardinalityIndex = left_cardinalityIndex % variablesRightContextCardinality[j];
    }
    return ret;
}

std::vector<std::string>
FOLFormulaConstraint::GetPatternNamesAtCardinality(const LogicCardinalityIndex cardinalityIndex) {
    std::vector<std::string> ret(quantified_variable_size);
    LogicCardinalityIndex left_cardinalityIndex = cardinalityIndex;

    for (int j = static_cast<int>(quantified_variable_size) - 1; j >= 0; --j) {  // cast needed because Index is unsigned
        const LogicCardinalityIndex index = left_cardinalityIndex / variablesRightContextCardinality[j];
        const std::string& domain = fol_formula.GetVariableDomain(quantified_variables[j].name);
        ret[j] = dataset.GetByDomain(domain, index)->GetName();

        left_cardinalityIndex = left_cardinalityIndex % variablesRightContextCardinality[j];
    }
    return ret;
}

// Build the formula Pattern to give in input to the constraint runEval
void FOLFormulaConstraint::BuildFormulaPatterns(
        const LogicCardinalityIndex cardinalityIndex,
        PropositionalFormulaConstraint::VariablesToPatternMap* variables_to_patterns) {
    // Storing the pairs <variable_cardinality, variable_position> positionally by quantifier.
    std::vector<LogicCardinalityIndex> variablesIndexesVector(quantified_variable_size);
    LogicCardinalityIndex left_cardinalityIndex = cardinalityIndex;

    for (int j = static_cast<int>(quantified_variable_size) - 1; j >= 0; --j) {  // cast needed because Index is unsigned
        variablesIndexesVector[j] = left_cardinalityIndex / variablesRightContextCardinality[j];
        left_cardinalityIndex = left_cardinalityIndex % variablesRightContextCardinality[j];
    }
    CHECK_LT(left_cardinalityIndex, variablesCardinality[0]);

    // std::vector<std::string> unary_predicate_variables(1);
    for (unsigned int j = 0; j < quantified_variable_size; ++j) {
        const std::string& domain = fol_formula.GetVariableDomain(quantified_variables[j].name);
        // unary_predicate_variables[0] = quantified_variables[j].name;
        // (*variables_to_patterns)[unary_predicate_variables] =
        (*variables_to_patterns)[quantified_variables[j].name] =
                dataset.GetByDomain(domain, variablesIndexesVector[j]);
    }
    const PropositionalFormulaConstraint::FormulaVariableSet& variables =
            propositional_formula_constraint.GetVariableSet();
    for (PropositionalFormulaConstraint::FormulaVariableSet::const_iterator iter = variables.begin();
         iter != variables.end(); ++iter) {
        const std::vector<std::string>& predicate_variables = *iter;
        if (predicate_variables.size() <= 1)  continue;  // unary predicates have been processed above

        // for each variable of the literal, get the correspondent pattern
        string pattern_name;
        string domain_name;
        for (unsigned int k = 0; k < predicate_variables.size(); ++k) {
            int pos = 0;
            if(!std::Find(variable_name_to_position_vec, predicate_variables[k], 0, &pos)) {
                FAULT("Variable " << predicate_variables[k] << " not found!");
            }
            if (!pattern_name.empty()) {
                pattern_name += "_";
                domain_name += "_";
            }
            const std::string& domain = fol_formula.GetVariableDomain(quantified_variables[pos].name);
            const Pattern* partial_pattern = dataset.GetByDomain(domain, variablesIndexesVector[pos]);
            if (partial_pattern == NULL) {
                FAULT("Unknown pattern n:" << variablesIndexesVector[pos] << " in domain " << domain);
            }
            pattern_name += partial_pattern->GetName();
            domain_name += domain;
        }
        const Dataset* per_domain_dataset = dataset.GetDomainDataset(domain_name);
        if (per_domain_dataset == NULL) {
            FAULT("Can not find domain " << domain_name);
        }
        const Pattern* pattern = (per_domain_dataset != NULL ?
                per_domain_dataset->GetByName(pattern_name) : NULL);
        // Pattern may be NULL for a given function, when the pattern was not added as an example.
        // (*variables_to_patterns)[predicate_variables] = pattern;
        (*variables_to_patterns)[StringUtils::ContainerToString(predicate_variables, "_", "")] =
                pattern;
    }
}

/* namespace {
// Debug utility function.
void PerFunctionDerivativePrinter(const FOLFormulaConstraint::PerFunctionDerivative& der) {
    for (FOLFormulaConstraint::PerFunctionDerivative::const_iterator iter = der.begin(); iter != der.end(); ++iter) {
        MESSAGE(iter->first << " => " << iter->second.ToStringAsSparse());
    }
}
}; */

void FOLFormulaConstraint::UpdateIntermediatePropositionalValuesHelper(
        const Value value, const Value max_value, const PerFunctionDerivative* derivative_values,
        const unsigned int level) {
    const FOLFormula::QUANTIFIER quantifier = quantified_variables[level].quantifier;
    if (quantifier == FOLFormula::forall) {
        // Forall: just forward the value after loss, it will be recursively aggregated.
        intermediate_propositional_values[level].Add(value, max_value, derivative_values);
    } else {
        intermediate_propositional_values[level].Set(value, max_value, derivative_values);
    }
}

void FOLFormulaConstraint::UpdateIntermediatePropositionalValues(
        const LogicCardinalityIndex cardinalityIndex,
        const Value value, const PerFunctionDerivative* derivative_values) {
    Value intermediate_value = value;
    Value intermediate_max_value = 1;
    const PerFunctionDerivative* intermediate_derivative = derivative_values;
    for (int j = 0; j < static_cast<int>(quantified_variable_size); ++j) {
        if ((cardinalityIndex + 1) % variablesRightContextCardinality[j] != 0) {
            // We are not at the end of the domain.
            continue;
        }
        UpdateIntermediatePropositionalValuesHelper(
                intermediate_value, intermediate_max_value, intermediate_derivative, j);
        if (j > 0) {  // Just moved to the next variable, remove the data for the previous variable.
            intermediate_propositional_values[j - 1].Reset(derivative_values != NULL);
        }

        if (intermediate_derivative != NULL) {
            intermediate_derivative = intermediate_propositional_values[j].GetDerivative();
        }
        intermediate_value = intermediate_propositional_values[j].GetValue();
        intermediate_max_value = intermediate_propositional_values[j].GetMaxValue();
    }
}

namespace {
inline int GetOuterChangedVariable(const LogicCardinalityIndex cardinalityIndex,
                                   const LogicCardinalityIndex new_cardinalityIndex,
                                   const Index quantified_variable_size,
                                   const std::vector<LogicCardinalityIndex>& variablesRightContextCardinality) {
    int v = static_cast<int>(quantified_variable_size) - 1;  // quantifiedVariablesSize can be unsigned!
    CHECK_GE(v, 0);
    for (; v >= 0; --v) {
        const LogicCardinalityIndex index = cardinalityIndex / variablesRightContextCardinality[v];
        const LogicCardinalityIndex new_index = new_cardinalityIndex / variablesRightContextCardinality[v];
        if (index != new_index) {
            break;  // We found the most external variable that has changed! v is its index.
        }
    }
    return v;
}
}  // end namespace

void FOLFormulaConstraint::ForwardUpdateIntermediatePropositionalValues(
        const LogicCardinalityIndex cardinalityIndex,
        const LogicCardinalityIndex new_cardinalityIndex,
        const bool compute_derivatives) {
    CHECK_LT(cardinalityIndex, new_cardinalityIndex);
    const int v = GetOuterChangedVariable(cardinalityIndex, new_cardinalityIndex,
                                          quantified_variable_size, variablesRightContextCardinality);

    for (int j = 0; j < v; ++j) {
        UpdateIntermediatePropositionalValuesHelper(
                intermediate_propositional_values[j].GetValue(),
                intermediate_propositional_values[j].GetMaxValue(),
                (compute_derivatives ? intermediate_propositional_values[j].GetDerivative() : NULL),
                j + 1);
        intermediate_propositional_values[j].Reset(compute_derivatives);
    }

}

/****************************************************************
 *  EVAL CONSTRAINT / EVAL GRADIENT CONSTRAINT
 ***************************************************************/
Value FOLFormulaConstraint::Eval(const Value mult, PerFunctionDerivative* constraint_derivatives) {
    CHECK_GT(cardinality, static_cast<LogicCardinalityIndex>(0));

    // do not read loss_constraint value and compute eval and gradient.
    if (constraint_derivatives != NULL && classifier == NULL) {
        FAULT("Missing the classifier to compute the gradient");
    }

    this->Reset(constraint_derivatives != NULL);

    // switch between prebuilt and locally built.
    PropositionalFormulaConstraint::VariablesToPatternMap variables_to_pattern;
    const PropositionalFormulaConstraint::VariablesToPatternMap* variables_to_pattern_used = NULL;

    LogicCardinalityIndex i = 0;
    if (this->doOptimization()) {
        i = cardinality_skips[0];  // which is always set.
    }

    const vector<Function::ID>& function_ids = propositional_formula_constraint.GetIds();

    for (; i < cardinality; ++i) {
        if (!prebuiltformulaPatterns.empty()) {
            Cardinality2FormulaPatternsMap::const_iterator iter = prebuiltformulaPatterns.find(i);
            if (iter != prebuiltformulaPatterns.end()) {
                variables_to_pattern_used = &iter->second;
            } else {
                this->BuildFormulaPatterns(i, &variables_to_pattern);
                variables_to_pattern_used = &variables_to_pattern;
            }
        } else {
            this->BuildFormulaPatterns(i, &variables_to_pattern);
            variables_to_pattern_used = &variables_to_pattern;
        }

        // Constraint value for one grounding.
        const Value value = propositional_formula_constraint.Eval(*variables_to_pattern_used);

        if (constraint_derivatives != NULL &&
            value != 1.0  /* assuming that if value==1 the gradient is null everywhere */) {
            for (unsigned int f = 0; f < function_ids.size(); ++f) {
                const Function::ID& id = function_ids[f];
                if (classifier->IsLearnFunction(id)) {
                    lower_level_intermediate_propositional_derivative[function_ids[f]].SetAll(0);
                }
            }

            for (unsigned int f = 0; f < function_ids.size(); ++f) {
                const Function::ID& id = function_ids[f];
                if (!classifier->IsLearnFunction(id)) {
                    continue;  // No Gradient computation for non-learn functions.
                }

                const LearnFunction& function = classifier->GetLearnFunctionByIDOrDie(id);
                // compute the derivative of Phi_c(f)(x) in respect to the f evaluated in f(x_i)
                // i.e. (D Phi_c(f)/D f)(f(x_i)), where D is the differential operator.
                propositional_formula_constraint.AccumulateGradient(
                        *variables_to_pattern_used, function, 1.0,
                        &(lower_level_intermediate_propositional_derivative[id]));
            }

            // Aggregator.
            this->UpdateIntermediatePropositionalValues(
                    i, value, &lower_level_intermediate_propositional_derivative);
            /* for (unsigned int f = 0; f < function_ids.size(); ++f) {
                lower_level_intermediate_propositional_derivative[function_ids[f]].SetAll(0);
            } */  // NEEDED???
        } else {
            // Aggregator.
            this->UpdateIntermediatePropositionalValues(i, value, NULL);
        }

        if (this->doOptimization()) {
            CardinalitySkips::const_iterator iter = cardinality_skips.find(i);
            if (iter != cardinality_skips.end()) {
                this->ForwardUpdateIntermediatePropositionalValues(
                        i, iter->second, constraint_derivatives != NULL);
                i = iter->second - 1;  // -1 because ++i at the end of the loop.
            }
        }
    }

    const Value constraint_value = intermediate_propositional_values.back().GetValue();
    const Value constraint_max_value = intermediate_propositional_values.back().GetMaxValue();
    CHECK_INE_RANGE(this->allowed_relative_error, static_cast<Value>(0.0), static_cast<Value>(1.0));
    const Value constraint_target = constraint_max_value * (1.0 - this->allowed_relative_error);
    const Value loss_constraint_value = constraint_loss_function.Eval(
            constraint_value, constraint_target);
    // MESSAGE("CONSTAINT " << this->GetName() << " VALUE " << constraint_value << " TARGET " << constraint_max_value << "=>" << constraint_target << " LOSS " << loss_constraint_value);
    const Value multiplier = mult * fol_formula.GetLambda() *
            (FLAGS_normalize_constraints_by_cardinality ? 1.0 / constraint_max_value : 1.0);
    if (constraint_derivatives != NULL && loss_constraint_value != 0.0) {
        const Value loss_constraint_der =
                constraint_loss_function.EvalDerivative(constraint_value, constraint_target);
        if (loss_constraint_der != 0.0) {
            PerFunctionDerivative* der = intermediate_propositional_values.back().GetDerivative();
            for (PerFunctionDerivative::iterator iter = der->begin(); iter != der->end(); ++iter) {
                const Function::ID& fid = iter->first;
                Math::Vector<Value>* function_der = &(iter->second);
                function_der->MultiplyInPlace(multiplier * loss_constraint_der);
                PerFunctionDerivative::iterator iter2 = constraint_derivatives->find(fid);
                CHECK_WITH_MESSAGE (iter2 != constraint_derivatives->end(),
                                    "Did not find constraint derivative for function " + fid +
                                    "in constraint " + this->ToString());  // should never happen
                iter2->second.AddInPlace(*function_der);
            }
        }
    }
    return multiplier * loss_constraint_value;
}

// DROP
/* void FOLFormulaConstraint::MaybeAdjustOutputContributions() {
    if (!this->doOptimization())  return;  // the precomputed output_cardinality is correct.

    output_cardinality = 1;
    LogicCardinalityIndex i = cardinality_skips[0];  // which is always set.

    for (; i < cardinality; ++i) {
        CardinalitySkips::const_iterator iter = cardinality_skips.find(i);
        if (iter != cardinality_skips.end()) {
            const int v = GetOuterChangedVariable(cardinalityIndex, new_cardinalityIndex,
                                                  quantified_variable_size, variablesRightContextCardinality);
            if (quantified_variables[v].quantifier == FOLFormula::forall) {
                ++output_cardinality;
            } else if (quantified_variables[v].quantifier == FOLFormula::exists_N) {
                output_cardinality = Math::Min(output_cardinality, quantified_variables[v].quantifier_num);
            } else {  // exists
                output_cardinality = 1;
            }
        }
    }
} */
