/*
 * string_utils.cc
 *
 *  Created on: May 6, 2009
 *      Author: michi
 */

#include "utils/string_utils.h"

#include <cctype>   // for isspace
#include <cstdlib>  // for rand
#include <deque>
#include <fstream>
#include <iostream>
#include <stack>
#include <vector>

using namespace std;

namespace StringUtils {
// Return true if the string after being space trimmed space starts with char c.
bool StartsWith(const string& str, const char c, const bool trim_spaces) {
    if (trim_spaces) {
        CHECK(!isspace(c));  // non-sense operation requested in this case.
    }
    unsigned int i = 0;
    while (trim_spaces && i < str.length() && isspace(str[i])) {
        ++i;
    }

    return (i < str.length() && str[i] == c);
}

// Return true if the string after being space trimmed space starts with char c.
bool StartsWith(const string& str, const string& prefix, const bool trim_spaces) {
    unsigned int i = 0;
    while (trim_spaces && i < str.length() && isspace(str[i])) {
        ++i;
    }
    if (i == str.length() && prefix.length() > 0) return false;

    for (unsigned int j = 0; i < str.length() && j < prefix.length(); ++j, ++i) {
        if (prefix[j] != str[i]) {
            return false;
        }
    }
    return true;
}
template<>
bool ReadElement<string>(const string& token, string* key)
{
    *key = token;
    return true;
}

void SplitToVector(const string& input,
                   vector<string>* vec,
                   const string& sep,
                   bool skipNullStrings)
{
    unsigned int pos = 0;
    vec->clear();

    while (pos < input.length()) {
        size_t next_pos = input.find(sep, pos);
        if (next_pos == string::npos)
            next_pos = input.length();

        if (!skipNullStrings || next_pos - pos > 0) {
            // CHECK_LT((size_t)pos, input.length());
            // CHECK_LE((size_t)next_pos, input.length());
            const string token = input.substr(pos, next_pos - pos);
            vec->push_back(token);
        }

        pos = next_pos + sep.length();
    }
}

void SplitToVector(const string& input,
                   vector<string>* vec,
                   const char sep,
                   bool skipNullStrings) {
    unsigned int pos = 0;
    vec->clear();
    const int num_tokens = StringUtils::CharCounter(input, sep) + 1;
    vec->reserve(num_tokens);
    while (pos < input.length()) {
        size_t next_pos = input.find(sep, pos);
        if (next_pos == string::npos)
            next_pos = input.length();

        if (!skipNullStrings || next_pos - pos > 0) {
            // CHECK_LT((size_t)pos, input.length());
            // CHECK_LE((size_t)next_pos, input.length());
            const string token = input.substr(pos, next_pos - pos);
            vec->push_back(token);
        }

        pos = next_pos + 1;
    }
}

void SplitToDeque(const string& input,
                   deque<string>* vec,
                   const char sep,
                   bool skipNullStrings) {
    unsigned int pos = 0;
    vec->clear();
    while (pos < input.length()) {
        size_t next_pos = input.find(sep, pos);
        if (next_pos == string::npos)
            next_pos = input.length();

        if (!skipNullStrings || next_pos - pos > 0) {
            // CHECK_LT((size_t)pos, input.length());
            // CHECK_LE((size_t)next_pos, input.length());
            const string token = input.substr(pos, next_pos - pos);
            vec->push_back(token);
        }

        pos = next_pos + 1;
    }
}

void SplitToDeque(char* const input, const char sep, deque<char*>* output) {
    unsigned int prec_pos = 0;
    for (unsigned int pos = 0; input[pos] != '\0'; ++pos) {
        if (input[pos] == sep) {
            input[pos] = '\0';
            output->push_back(&(input[prec_pos]));
            prec_pos = pos;
        }
    }
}

bool IsAlphaNumericOrInSet(const string& input, const string& symbols)
{
    for (unsigned int i = 0; i < input.size(); i++)
    {
        if (!isupper(input[i]) &&  // capital letters [A-Z]
            !islower(input[i]) &&  // small capitol letters [a-z]
            !isdigit(input[i]) &&  // number (0-9)
            symbols.find(input[i]) == string::npos) {  // not other allowed symbol
            return false;
        }
    }

    return true;
}

bool IsAlphaNumeric(const string& input)
{
    for (unsigned int i = 0; i < input.size(); i++)
    {
        if (!isupper(input[i]) &&  // capital letters [A-Z]
            !islower(input[i]) &&  // small capitol letters [a-z]
            !isdigit(input[i])) {  // number (0-9)
            return false;
        }
    }

    return true;
}

int CharCounter(const string& input, const char symbol)
{
    size_t count = 0;
    size_t pos = 0;
    while ((pos = input.find_first_of(symbol, pos)) != string::npos)
    {
        ++pos;
        ++count;
    }

    return count;
}

int CharsCounter(const string& input, const string& symbols) {
    size_t count = 0;
    for (unsigned int i = 0; i < input.length(); ++i) {
        if (symbols.find(input[i]) != string::npos) {
            ++count;
        }
    }
    return count;
}

int SubstringCounter(const string& input, const string& symbol)
{
    size_t count = 0;
    size_t pos = 0;
    while ((pos = input.find_first_of(symbol, pos)) != string::npos)
    {
        ++pos;
        ++count;
    }

    return count;
}

bool HasChar(const string& input, const char c) {
    for (unsigned int i = 0; i < input.length(); ++i)
        if (input[i] == c)
            return true;
    return false;
}

bool HasChars(const string& input, const string& chars) {
    for (unsigned int i = 0; i < input.length(); ++i)
        if (chars.find(input[i]) != string::npos)
            return true;
    return false;

}


string ReShuffleStringsOfFile(const string& input_filename,
                                   const string& output_filename,
                                   const string& output_dir) {
    ifstream ifs(input_filename.c_str());

    if (!ifs.is_open())
    {
        WARN("Could not open the file " << input_filename);
    }

    vector<string> dataVector;
    string line;

    while (!ifs.eof())
    {
        line.clear();
        getline(ifs, line);

        // skip empty lines and carriage return
        if (line.empty() || line.size() == 1)
            continue;

        // skip comment line
        if (line.find('#') == 0)
            continue;

        dataVector.push_back(line);
    }

    for (unsigned int l = 0; l < dataVector.size(); ++l)
    {
        int j = rand() % dataVector.size();
        int i = rand() % dataVector.size();

        if (i == j)
            i = rand() % dataVector.size();

        string temp = dataVector[j];
        dataVector[j] = dataVector[i];
        dataVector[i] = temp;
    }

    const string ofilename = output_dir + "/" + output_filename;
    ofstream os(ofilename.c_str());

    if (!os.is_open())
    {
        WARN("Could not open the file " << ofilename);
    }

    for (unsigned int i = 0; i < dataVector.size(); ++i)
    {
        os << dataVector[i] << endl;
    }

    return ofilename;
}

void Replace(const char in, const char out, string* s) {
    for (unsigned int i = 0; i < s->length(); ++i) {
        if ((*s)[i] == in) {
            (*s)[i] = out;
        }
    }
}

string Replace(const char in, const char out, const string& s) {
    string s1 = s;
    Replace(in, out, &s1);
    return s1;
}

void Replace(const string& in, const string& out, string* s) {
    *s = Replace(in, out, *s);
}

string Replace(const string& in, const string& out, const string& s) {
    string s1 = s;
    string::size_type index = s1.find(in, 0);
    while (index != string::npos) {
        s1.replace(index, in.length(), out);
        index = s1.find(in, index + out.length());  // skip out that was just replaced
    }
    return s1;
}

void Delete(const char in, string* s) {
    string s1;
    for (unsigned int i = 0; i < s->length(); ++i) {
        if ((*s)[i] != in)  s1 += (*s)[i];
    }

    *s = s1;
}

bool RemoveDuplicatedSpaces(string* s) {
    unsigned int pos = 0;
    for (unsigned int i = 0; i < s->length(); ++i) {
        if (pos != i) {
            (*s)[pos] = (*s)[i];
        }
        ++pos;
        int num_spaces = 0;
        while (i + num_spaces < s->length() && isspace((*s)[i + num_spaces])) {
            ++num_spaces;
        }
        if (num_spaces > 1) {
            i += num_spaces - 1;  // -1 because another ++ at the end of loop
        }
    }
    if (pos == s->length())  return false;

    s->resize(pos);
    return true;
}

string RemoveDuplicatedSpaces(const string& s) {
    string s1;
    s1.reserve(s.length());
    for (unsigned int i = 0; i < s.length(); ++i) {
        s1.append(1, s[i]);
        while (i < s.length() && isspace(s[i]))  ++i;
    }
    return s1;
}

string RemoveSpacesAtStartAndEndOfString(const string& s) {
    if (s.empty())  return "";

    bool shortened = false;
    unsigned int start = 0;
    while (start < s.length() && isspace(s[start])) {
        shortened = true;
        ++start;
    }
    if (start == s.length())  return "";

    unsigned int end = s.length() - 1;
    while (end >= 0 && isspace(s[end])) {
        shortened = true;
        if (end == 0)  return "";  // avoid unsigned int to flip to complement.
        --end;
    }
    if (!shortened)  return s;
    return s.substr(start, end - start + 1);
}

bool RemoveSpacesAtStartAndEndOfString(string* s) {
    if (s->empty())  return false;

    bool shortened = false;
    unsigned int start = 0;
    while (start < s->length() && isspace((*s)[start])) {
        shortened = true;
        ++start;
    }
    if (start == s->length()) {
        s->clear();
        return true;
    }

    unsigned int end = s->length() - 1;
    while (end >= 0 && isspace((*s)[end])) {
        shortened = true;
        if (end == 0) {  // avoid unsigned int to flip to complement.
            s->clear();
            return true;
        }
        --end;
    }
    if (!shortened)  return false;
    *s = s->substr(start, end - start + 1);
    return true;
}

/* Consume a string reading it element by element, inefficient for the many string copies but handy
 * Usage
 * string s = "ciao,ciao1,pippo";
 * while (!s.empty() && (string token = ConsumeString(',', &s))) {
 *   ...
 * }
 * Or can be used to read one token removing it from the remain string
 * string token = ConsumeString(' ', &s);
 */
std::string ConsumeString(const char separator, std::string* s) {
    std::string::size_type pos = s->find(separator);
    if (pos == std::string::npos) {
        *s = "";
        return *s;
    }
    std::string token = (pos > 0 ? s->substr(0, pos) : std::string(""));
    *s = (pos < s->length() ? s->substr(pos) : std::string(""));
    return token;
}

} // end StringUtils namespace
