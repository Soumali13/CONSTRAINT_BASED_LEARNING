/*
 * utils/general.h
 *
 *  Created on: May 6, 2009
 *      Author: michi
 */

#ifndef GENERAL_H
#define GENERAL_H

#include <ctime>
#include <iostream>
#include <sstream>
#include <string>
// For FLAGS_verbosity. It trades compile time for speed in evaluating conditional logging expressions.
#include "utils/gflags/gflags/gflags.h"


DECLARE_int32(verbose);

// Default debug level, can be changed only at compile time as -D__DEBUG_LEVEL__=N
// This allows to insert DCHECKs with one single int comparison penalty (e.g. 1 cpu clock).
#ifndef __DEBUG_LEVEL__
#define __DEBUG_LEVEL__ 0
#endif

// The verbosity level can be changed via --verbosity=N.
// Inlined to minimize the impact of logging into performance, especially when running at a low verbosity level
// when no output is actually generated.
inline int GetVerboseLevel() { return FLAGS_verbose; }

// do not move it to system.h to avoid circular dependencies.
void Exit(const int error_num = 1);

namespace Logging {
// Please do not call this directly. Use the logging macros below.
// TODO(michi): this is visible in the header because called by the logging and checks.
//              Fix this.
void __PrintToLogStreams(const std::string& s);

// Reset the logging streams. This should not called directly.
// Only exception is when programmatically changing the file logging location,
// which needs to re-initalize the file stream.
void ResetLogStreams();
}  // end namespace Logging

// Fatal error, abort.
// ******************************************************************* //
// Template versions, these could be used directly. They are safer than their
// macro-based counterparts because of strong type checking.
// The only issue with them is that the __FILE__ and __LINE__ variables will
// refer to the function code and not the caller as needed to easily debug the
// error. So, we stick to the old macro-based version for direct calls in the
// code.
template<typename T>
inline void __CHECK(const T& s, const std::string& function_name,
        const std::string& file_name, int line_number,
        const std::string& message = "") {
    if (!s) {
        std::ostringstream os;
        os << "Error: in function " << function_name
           << ", file " << file_name << " line " << line_number
           << std::string(": ") << s << std::string(" evals to false ")
           << (message.empty() ? std::string() : message)
           << std::endl;
        Logging::__PrintToLogStreams(os.str()) ;
        Exit();
    }
}

template<typename T>
inline void __CHECK_FALSE(const T& s, const std::string& function_name,
        const std::string& file_name, int line_number,
        const std::string& message = "") {
    if (s) {
        std::ostringstream os;
        os << "Error: in function " << function_name
           << ", file " << file_name << " line " << line_number
           << std::string(": ") << s << std::string(" evals to true ")
           << (message.empty() ? std::string() : message)
           << std::endl;
        Logging::__PrintToLogStreams(os.str()) ;
        Exit();
    }
}

template<typename T>
inline void __CHECK_GT(const T& a, const T& b, const std::string& function_name,
        const std::string& file_name, int line_number,
        const std::string& message = "") {
    if (a <= b)
    {
        std::ostringstream os;
        os << "Error: in function " << function_name
           << ", file " << file_name << " line " << line_number
           << " a>b which is " << a << ">" << b
           << " does not hold " << (message.empty() ? std::string() : message)
           << std::endl;
        Logging::__PrintToLogStreams(os.str());
        Exit();
    }
}

template<typename T>
inline void __CHECK_LT(const T& a, const T& b, const std::string& function_name,
        const std::string& file_name, int line_number,
        const std::string& message = "") {
    if (a >= b)
    {
        std::ostringstream os;
        os << "Error: in function " << function_name
           << ", file " << file_name << " line " << line_number
           << " a<b which is " << a << "<" << b
           << " does not hold" << (message.empty() ? std::string() : message)
           << std::endl;
        Logging::__PrintToLogStreams(os.str());
        Exit();
    }
}

template<typename T>
inline void __CHECK_GE(const T& a, const T& b, const std::string& function_name,
        const std::string& file_name, int line_number,
        const std::string& message = "") {
    if (a < b)
    {
        std::ostringstream os;
        os << "Error: in function " << function_name
           << ", file " << file_name << " line " << line_number
           << " a>=b which is " << a << ">=" << b
           << " does not hold " << (message.empty() ? std::string() : message)
           << std::endl;
        Logging::__PrintToLogStreams(os.str());
        Exit();
    }
}

template<typename T>
inline void __CHECK_LE(const T& a, const T& b, const std::string& function_name,
        const std::string& file_name, int line_number,
        const std::string& message = "") {
    if (a > b)
    {
        std::ostringstream os;
        os << "Error: in function " << function_name
           << ", file " << file_name << " line " << line_number
           << " a<=b which is " << a << "<=" << b
           << " does not hold " << (message.empty() ? std::string() : message)
           << std::endl;
        Logging::__PrintToLogStreams(os.str());
        Exit();
    }
}

template<typename T>
inline void __CHECK_EQ(const T& a, const T& b, const std::string& function_name,
        const std::string& file_name, int line_number,
        const std::string& message = "") {
    if (a != b)
    {
        std::ostringstream os;
        os << "Error: in function " << function_name
           << ", file " << file_name << " line " << line_number
           << " a==b which is " << a << "==" << b
           << " does not hold " << (message.empty() ? std::string() : message)
           << std::endl;
        Logging::__PrintToLogStreams(os.str());
        Exit();
    }
}

template<typename T>
inline void __CHECK_NE(const T& a, const T& b, const std::string& function_name,
        const std::string& file_name, int line_number,
        const std::string& message = "") {
    if (a == b)
    {
        std::ostringstream os;
        os << "Error: in function " << function_name
           << ", file " << file_name << " line " << line_number
           << " a!=b which is " << a << "!=" << b
           << " does not hold " << (message.empty() ? std::string() : message)
           << std::endl;
        Logging::__PrintToLogStreams(os.str());
        Exit();
    }
}

template<typename T>
inline void __CHECK_NE_NULL(const T& a, const std::string& function_name,
        const std::string& file_name, int line_number,
        const std::string& message = "") {
    if (a == NULL)
    {
        std::ostringstream os;
        os << "Error: in function " << function_name
           << ", file " << file_name << " line " << line_number
           << " a!=NULL which is does not hold as a is == NULL. "
           << (message.empty() ? std::string() : message)
           << std::endl;
        Logging::__PrintToLogStreams(os.str());
        Exit();
    }
}

template<typename T>
inline void __CHECK_EQ_NULL(const T& a, const std::string& function_name,
        const std::string& file_name, int line_number,
        const std::string& message = "") {
    if (a != NULL)
    {
        std::ostringstream os;
        os << "Error: in function " << function_name
           << ", file " << file_name << " line " << line_number
           << " a==NULL which is does not hold as a is != NULL. "
           << (message.empty() ? std::string() : message)
           << std::endl;
        Logging::__PrintToLogStreams(os.str());
        Exit();
    }
}

template<typename T>
inline void __CHECK_IN_RANGE(const T& a, const T& b, const T& c, const std::string& function_name,
        const std::string& file_name, int line_number,
        const std::string& message = "") {
    if (a <= b || a >= c)
    {
        std::ostringstream os;
        os << "Error: in function " << function_name
           << ", file " << file_name << " line " << line_number
           << " b < a < c which is " << b << "<" << a << "<" << c
           << " does not hold " << (message.empty() ? std::string() : message)
           << std::endl;
        Logging::__PrintToLogStreams(os.str());
        Exit();
    }
}

template<typename T>
inline void __CHECK_INE_RANGE(const T& a, const T& b, const T& c, const std::string& function_name,
        const std::string& file_name, int line_number,
        const std::string& message = "") {
    if (a < b || a > c)
    {
        std::ostringstream os;
        os << "Error: in function " << function_name
           << ", file " << file_name << " line " << line_number
           << " b <= a <= c which is " << b << "<=" << a << "<=" << c
           << " does not hold " << (message.empty() ? std::string() : message)
           << std::endl;
        Logging::__PrintToLogStreams(os.str());
        Exit();
    }
}

// The internal functions are called via a macro to allow accessing to the
// file, function and line number. Switch to those as soon as the type errors
// have been fixed.
#define CHECK(s) { __CHECK((s), __PRETTY_FUNCTION__, __FILE__, __LINE__); }
#define DCHECK(level, s) { if (level <= __DEBUG_LEVEL__)  __CHECK((s), __PRETTY_FUNCTION__, __FILE__, __LINE__); }

// Like CHECK and DCHECk but more explicit in their meaning.
#define CHECK_TRUE(s) { __CHECK((s), __PRETTY_FUNCTION__, __FILE__, __LINE__); }
#define DCHECK_TRUE(level, s) { if (level <= __DEBUG_LEVEL__)  __CHECK((s), __PRETTY_FUNCTION__, __FILE__, __LINE__); }

// Checks that the condition is false.
#define CHECK_FALSE(s) { __CHECK_FALSE((s), __PRETTY_FUNCTION__, __FILE__, __LINE__); }
#define DCHECK_FALSE(level, s) { if (level <= __DEBUG_LEVEL__)  __CHECK_FALSE((s), __PRETTY_FUNCTION__, __FILE__, __LINE__); }

#define CHECK_EQ(a,b) { __CHECK_EQ((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__); }
#define DCHECK_EQ(level, a,b) { if (level <= __DEBUG_LEVEL__)  __CHECK_EQ((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__); }

#define CHECK_NE(a,b) { __CHECK_NE((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__); }
#define DCHECK_NE(level, a,b) { if (level <= __DEBUG_LEVEL__)  __CHECK_NE((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__); }

#define CHECK_NE_NULL(a) { __CHECK_NE_NULL((a), __PRETTY_FUNCTION__, __FILE__, __LINE__); }
#define DCHECK_NE_NULL(level, a) { if (level <= __DEBUG_LEVEL__)  __CHECK_NE_NULL((a), __PRETTY_FUNCTION__, __FILE__, __LINE__); }

#define CHECK_EQ_NULL(a) { __CHECK_EQ_NULL((a), __PRETTY_FUNCTION__, __FILE__, __LINE__); }
#define DCHECK_EQ_NULL(level, a) { if (level <= __DEBUG_LEVEL__)  __CHECK_EQ_NULL((a), __PRETTY_FUNCTION__, __FILE__, __LINE__); }

#define CHECK_GT(a,b) { __CHECK_GT((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__); }
#define DCHECK_GT(level, a,b) { if (level <= __DEBUG_LEVEL__)  __CHECK_GT((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__); }

#define CHECK_LT(a,b) { __CHECK_LT((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__); }
#define DCHECK_LT(level, a,b) { if (level <= __DEBUG_LEVEL__)  __CHECK_LT((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__); }

#define CHECK_GE(a,b) { __CHECK_GE((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__); }
#define DCHECK_GE(level, a,b) { if (level <= __DEBUG_LEVEL__)  __CHECK_GE((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__); }

#define CHECK_LE(a,b) { __CHECK_LE((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__); }
#define DCHECK_LE(level, a,b) { if (level <= __DEBUG_LEVEL__)  __CHECK_LE((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__); }

#define CHECK_IN_RANGE(a,b,c) { __CHECK_IN_RANGE((a), (b), (c), __PRETTY_FUNCTION__, __FILE__, __LINE__); }
#define DCHECK_IN_RANGE(level, a,b,c) { if (level <= __DEBUG_LEVEL__)  __CHECK_IN_RANGE((a), (b), (c), __PRETTY_FUNCTION__, __FILE__, __LINE__); }

#define CHECK_INE_RANGE(a,b,c) { __CHECK_INE_RANGE((a), (b), (c), __PRETTY_FUNCTION__, __FILE__, __LINE__); }
#define DCHECK_INE_RANGE(level, a,b,c) { if (level <= __DEBUG_LEVEL__)  __CHECK_INE_RANGE((a), (b), (c), __PRETTY_FUNCTION__, __FILE__, __LINE__); }

#define CHECK_WITH_MESSAGE(s, p) { __CHECK((s), __PRETTY_FUNCTION__, __FILE__, __LINE__, p); }
#define DCHECK_WITH_MESSAGE(level, s, p) { if (level <= __DEBUG_LEVEL__)  __CHECK((s), __PRETTY_FUNCTION__, __FILE__, __LINE__, p); }

#define CHECK_TRUE_WITH_MESSAGE(s, p) { __CHECK_TRUE((s), __PRETTY_FUNCTION__, __FILE__, __LINE__, p); }
#define DCHECK_TRUE_WITH_MESSAGE(level, s, p) { if (level <= __DEBUG_LEVEL__)  __CHECK_TRUE((s), __PRETTY_FUNCTION__, __FILE__, __LINE__, p); }

#define CHECK_FALSE_WITH_MESSAGE(s, p) { __CHECK_FALSE((s), __PRETTY_FUNCTION__, __FILE__, __LINE__, p); }
#define DCHECK_FALSE_WITH_MESSAGE(level, s, p) { if (level <= __DEBUG_LEVEL__)  __CHECK_FALSE((s), __PRETTY_FUNCTION__, __FILE__, __LINE__, p); }

#define CHECK_EQ_WITH_MESSAGE(a,b,p) { __CHECK_EQ((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__, p); }
#define DCHECK_EQ_WITH_MESSAGE(level, a,b,p) { if (level <= __DEBUG_LEVEL__)  __CHECK_EQ((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__, p); }

#define CHECK_NE_WITH_MESSAGE(a,b,p) { __CHECK_NE((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__, p); }
#define DCHECK_NE_WITH_MESSAGE(level, a,b,p) { if (level <= __DEBUG_LEVEL__)  ((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__, p); }

#define CHECK_GT_WITH_MESSAGE(a,b,p) { __CHECK_GT((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__, p); }
#define DCHECK_GT_WITH_MESSAGE(level, a,b,p) { if (level <= __DEBUG_LEVEL__)  __CHECK_GT((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__, p); }

#define CHECK_LT_WITH_MESSAGE(a,b,p) { __CHECK_LT((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__, p); }
#define DCHECK_LT_WITH_MESSAGE(level, a,b,p) { if (level <= __DEBUG_LEVEL__)  __CHECK_LT((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__, p); }

#define CHECK_GE_WITH_MESSAGE(a,b,p) { __CHECK_GE((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__, p); }
#define DCHECK_GE_WITH_MESSAGE(level, a,b,p) { if (level <= __DEBUG_LEVEL__)  __CHECK_GE((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__, p); }

#define CHECK_LE_WITH_MESSAGE(a,b,p) { __CHECK_LE((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__, p); }
#define DCHECK_LE_WITH_MESSAGE(level, a,b,p) { if (level <= __DEBUG_LEVEL__)  __CHECK_LE((a), (b), __PRETTY_FUNCTION__, __FILE__, __LINE__, p); }

#define CHECK_NE_NULL_WITH_MESSAGE(a,p) { __CHECK_NE_NULL((a), __PRETTY_FUNCTION__, __FILE__, __LINE__, p); }
#define DCHECK_NE_NULL_WITH_MESSAGE(level, a,p) { if (level <= __DEBUG_LEVEL__)  __CHECK_NE_NULL((a), __PRETTY_FUNCTION__, __FILE__, __LINE__, p); }


// ******************************************************************* //
// Fatal error, abort.
// ******************************************************************* //
#define FAULT(s) { std::ostringstream os;                         \
  os << "Error: in function "                                     \
     << __PRETTY_FUNCTION__ << ", file " << __FILE__ << " line "  \
     << __LINE__ << ": " << s << std::endl;                       \
  Logging::__PrintToLogStreams(os.str()); Exit(); }

// ******************************************************************* //
// Print a warning
// ******************************************************************* //
#define WARN(s) { std::ostringstream os;                       \
  os << "Warning: in function " << __PRETTY_FUNCTION__         \
     << ", file " << __FILE__ << " line " << __LINE__ << ": "  \
     << s << std::endl;                                        \
     Logging::__PrintToLogStreams(os.str()); }

// ******************************************************************* //
// Print a message
// ******************************************************************* //
#define MESSAGE(s) { std::ostringstream os;                      \
  os << "Message at time:" << std::time(NULL)                    \
     << " in file " << __FILE__ << " line " << __LINE__ << ": "  \
     << s << std::endl;                                          \
     Logging::__PrintToLogStreams(os.str()); }

// ******************************************************************* //
// Print a message if the verbose level is high enough.
// ******************************************************************* //
#define VMESSAGE(level, s) { if (level <= GetVerboseLevel()) {   \
  std::ostringstream os;                                                \
  os << "Message at time:" << std::time(NULL)                           \
     <<  " in file " << __FILE__ << " line " << __LINE__ << ": " << s   \
     << std::endl;                                                      \
     Logging::__PrintToLogStreams(os.str()); } }

// ******************************************************************* //
// Print this to the logs (no new line is inserted)
// ******************************************************************* //
#define PRINT(s) { std::ostringstream os; os << s; Logging::__PrintToLogStreams(os.str()); }

// ******************************************************************* //
// Print this to the logs (a new line is inserted)
// ******************************************************************* //
#define PRINTLN(s) { std::ostringstream os; os << s << std::endl; Logging::__PrintToLogStreams(os.str()); }

// ******************************************************************* //
// Print this to the logs (no new line is inserted)
// ******************************************************************* //
#define VPRINT(level, s) {  if (level <= GetVerboseLevel()) { \
  std::ostringstream os; os << s;                                    \
  Logging::__PrintToLogStreams(os.str()); } }

#define VPRINTLN(level, s) {  if (level <= GetVerboseLevel()) { \
  std::ostringstream os; os << s << std::endl;                         \
  Logging::__PrintToLogStreams(os.str()); } }

#define DPRINT(level, s) {  if (level <= __DEBUG_LEVEL__) { \
  std::ostringstream os; os << s;                                  \
  Logging::__PrintToLogStreams(os.str()); } }

#define DPRINTLN(level, s) {  if (level <= __DEBUG_LEVEL__) { \
  std::ostringstream os; os << s << std::endl;                       \
  Logging::__PrintToLogStreams(os.str());}

#endif /* GENERAL_H */
