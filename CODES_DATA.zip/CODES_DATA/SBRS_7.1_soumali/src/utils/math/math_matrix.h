#ifndef MATH_MATRIX_H_
#define MATH_MATRIX_H_

#include "utils/math/math_vector.h"

/*
 * Classes to perform Matrix and SparseMatrix Operations.
 * An example of usage:
Math::Matrix<float> matrix(10, 10);  // creates a 10x10 matrix
matrix.Rand(0, 10);  // randomize it values
matrix.Print();  // print it
matrix.Save(string("matrix_save"));  // save it

Math::Matrix<float> matrix1;  // empty matrix
matrix1.Load("matrix_save");  // load it
matrix1.TransposeInPlace();   // transpose it in place
matrix1.Print();

Math::Matrix<float>* matrix2 = matrix1.Multiply(matrix); // matrix1*matrix
matrix2->Print();
delete matrix2;
 */

namespace Math
{

typedef unsigned long DefaultMatrixIndex;
// Base Matrix definitions. This abstract class provides the generic
// interface for a matrix. It should not be instantiated directly
// but through one of its derived classes.

template < typename I = DefaultMatrixIndex, typename T = double >
class BaseMatrix
{
    private:
        virtual bool SaveToStream(std::ostream& os) const = 0;

    public:
        virtual void Clear() = 0;
        // For efficiency let's not declare those in the virtual interface,
        // so that they can be inlined. May be reconsider this is a second moment
        // if inheritance is used somehow.
        // virtual void Set(I i1, I i2, T val) = 0;
        // virtual bool Get(I i1, I i2, T* value) const = 0;
        // virtual T Get(I i1, I i2) const = 0;
        // virtual unsigned long Size() const = 0;

        virtual ~BaseMatrix()
        {
        }
        virtual bool Load(const std::string& filename) = 0;
        virtual bool LoadBinary(const std::string& filename) = 0;
        virtual bool Save(const std::string& filename) const;
        virtual void Print() const;
        virtual T GetMaxRowSum() const = 0;
};

template <typename I, typename T>
bool BaseMatrix<I, T>::Save(const std::string& filename) const
{
    std::ofstream ofs(filename.c_str());

    if (!ofs.is_open())
    {
        WARN("Could not open the file " << filename);
        return false;
    }

    return this->SaveToStream(ofs);
}

template <typename I, typename T>
void BaseMatrix<I, T>::Print() const
{
    this->SaveToStream(std::cout);
}

// A standard dense Matrix. Provides all basic functionalities
// plus the implementation of basic matrix operations like transposition,
// sum, product, etc.

template <typename I = DefaultMatrixIndex, typename T = double>
class Matrix : public BaseMatrix<I, T>
{
    private:
        // The number of rows of the matrix (its y dimension)
        I ysize;
        // The number of columns of the matrix (its x dimension)
        I xsize;
        I size; // xsize * ysize, cached for speed
        // The data in the cells
        T** data;
        // is in LU form
        bool is_lu;

    public:
        // Constructors.

        Matrix() : ysize(0), xsize(0), size(0), data(NULL), is_lu(false)
        {
        }

        Matrix(I ysize_, I xsize_) :
            ysize(0), xsize(0), size(0), data(NULL), is_lu(false)
        {
            Init(ysize_, xsize_);
        }

        virtual ~Matrix()
        {
            this->Clear();
        }

        Matrix(const Matrix<I, T>& matrix) :
            ysize(0), xsize(0), size(0), data(NULL), is_lu(false)
        {
            this->Copy(matrix);
        }

        static Matrix<I, T>* IdentityMatrixFactory(const I size)
        {
            Matrix<I, T>* identity = new Matrix<I, T > (size, size);
            I i;

            for (i = 0; i < size; ++i)
                identity->Set(i, i, static_cast<T> (1.0));

            return identity;
        }

        bool IsLU() const
        {
            return is_lu;
        }

        void SetIsLU(bool is_lu_)
        {
            is_lu = is_lu_;
        }

        virtual void Copy(const Matrix<I, T>& matrix)
        {
            this->Init(matrix.GetYSize(), matrix.GetXSize());
            I i, j;

            for (i = 0; i < ysize; ++i)
                for (j = 0; j < xsize; ++j)
                    data[i][j] = matrix.Get(i, j);

            is_lu = matrix.IsLU();
        }
        // Initialization and reset methods.
        friend void swap(Matrix<I, T>& a, Matrix<I, T>& b) {
            using std::swap;
            swap(a.ysize, b.ysize);
            swap(a.xsize, b.xsize);
            swap(a.data,  b.data);
            swap(a.is_lu, b.is_lu);
        }

        virtual void Clear() {
            if (data != NULL) {
                for (I i = 0; i < ysize; ++i)
                    if (data[i] != NULL)
                        delete[] data[i];
                delete[] data;
            }

            xsize = static_cast<I>(0);
            ysize = static_cast<I>(0);
            size = static_cast<I>(0);
            data = NULL;
            is_lu = false;
        }

        // Reset the matrix and reinit it to the new specified sizes.
        // All values are initialized to 0.
        virtual void Init(const I ysize_, const I xsize_)
        {
            this->Clear();
            xsize = xsize_;
            ysize = ysize_;
            size = xsize * ysize;
            is_lu = false;

            /* {x,y}size is unsigned if
            if (ysize < 0 || xsize < 0)
            {
                WARN("Can not generate a matrix with size " << ysize << "x" << xsize);
                return;
            } */

            // if one dimension is zero, the other should be zero as well.
            if (ysize == 0)
                CHECK_EQ(xsize, static_cast<I> (0));

            if (xsize == 0)
                CHECK_EQ(ysize, static_cast<I> (0));

            if (xsize > static_cast<I>(0) && ysize > static_cast<I>(0))
            {
                data = new T*[ysize];
                I i;

                for (i = 0; i < ysize; ++i)
                {
                    data[i] = new T[xsize];
                    memset(data[i], 0, sizeof (T) * xsize);
                }
            }
        }
        // Creates a random matrix with values between min and max.

        virtual void Rand(T min, T max)
        {
            Math::RandSeed();
            I i, j;

            for (i = 0; i < ysize; ++i)
                for (j = 0; j < xsize; ++j)
                    data[i][j] = Math::Rand(min, max);
        }

        // Accessors and Mutators. Some are non-virtual and inlined for max speed.

        inline I GetXSize() const
        {
            return xsize;
        }

        inline I GetYSize() const
        {
            return ysize;
        }

        inline I Size() const
        {
            return size;
            /* CHECK_GE(xsize, 0);
            CHECK_GE(ysize, 0); */ // removed safety checks for speed.
            // return static_cast<unsigned long>(xsize * ysize);
        }

        inline void Set(const I i1, const I i2, T val)
        {
            data[i1][i2] = val;
        }

        virtual void SetAll(const T val)
        {
            for (I i = 0; i < ysize; ++i)
            {
                if (val == static_cast<T> (0)) // do it fast when possible
                {
                    memset(data[i], 0, xsize * sizeof (T));
                }

                else
                {
                    for (I j = 0; j < xsize; ++j)
                        data[i][j] = val;
                }
            }
        }

        virtual T GetMaxRowSum() const {
            T max_sum = std::numeric_limits<T>::min();
            for (I i = 0; i < ysize; ++i) {
                T sum = 0;
                for (I j = 0; j < xsize; ++j)
                    sum += data[i][j];
                if (sum > max_sum)
                    max_sum = sum;
            }
            return max_sum;
        }

        virtual void SetRow(const I i1, const Math::Vector<T>& row)
        {
            for (I i = 0; i < row.Size(); ++i)
                data[i1][i] = row.Get(i);
        }

        virtual void SetRow(const I i1, const std::vector<T>& row)
        {
            for (I i = 0; i < static_cast<I>(row.size()); ++i)
                data[i1][i] = row[i];
        }

        // Inlined for speed. Make them virtual if needed to use inheritance
        // with this class.

        inline void Add(const I i1, const I i2, const T val)
        {
            data[i1][i2] += val;
        }

        inline T Get(const I i1, const I i2) const
        {
            return data[i1][i2];
        }

        inline bool Get(const I i1, const I i2, T* value) const
        {
            // Safe version of get, returns false if the indexes are not valid.
            if (i1 >= ysize || i2 >= xsize)
                return false;

            *value = data[i1][i2];
            return true;
        }
        // end Inlined.

        virtual const T* Get(const I i) const
        {
            return data[i];
        }

        virtual T* GetMutable(const I i)
        {
            return data[i];
        }

        // Like Get(i) but returns a copy of the row.

        virtual const Vector<T>* GetRow(const I r) const
        {
            const I x_size = this->GetXSize();
            Vector<T>* V = new Vector<T > (x_size);
            I c;

            for (c = 0; c < x_size; ++c)
                V->Set(c, this->Get(r, c));

            return V;
        }

        // Like Get(i) but returns a copy of the row.

        virtual bool GetRow(const I r, Math::Vector<T>* row) const
        {
            const I x_size = this->GetXSize();
            if (row->Size() != x_size)
                row->Init(x_size);

            for (I c = 0; c < x_size; ++c)
                row->Set(c,  data[r][c]);

            return true;
        }

        // Returns a copy of the column.

        virtual const Vector<T>* GetColumn(const I c) const
        {
            I y_size = this->GetYSize();
            Vector<T>* V = new Vector<T > (y_size);
            I r;

            for (r = 0; r < y_size; ++r)
                V->Set(r, this->Get(r, c));

            return V;
        }
        // In place operations
        // Transpose the matrix in place.

        virtual void TransposeInPlace()
        {
            I i, j;

            for (i = 0; i < ysize; ++i)
                for (j = i + 1; j < xsize; ++j)
                {
                    T tmp = data[j][i];
                    data[j][i] = data[i][j];
                    data[i][j] = tmp;
                }
        }
        // Add m to the matrix.

        virtual void AddInPlace(const Matrix<I, T>& m)
        {
            CHECK_EQ(m.GetXSize(), this->GetXSize());
            CHECK_EQ(m.GetYSize(), this->GetYSize());
            I i, j;

            for (i = 0; i < ysize; ++i)
                for (j = 0; j < xsize; ++j)
                    data[i][j] += m.Get(i, j);
        }

        // Sub m to the matrix.

        virtual void SubInPlace(const Matrix<I, T>& m)
        {
            CHECK_EQ(m.GetXSize(), this->GetXSize());
            CHECK_EQ(m.GetYSize(), this->GetYSize());
            I i, j;

            for (i = 0; i < ysize; ++i)
                for (j = 0; j < xsize; ++j)
                    data[i][j] -= m.Get(i, j);
        }
        // Multiply the current matrix by a scalar.
        // The matrix is updated in place.

        virtual void MultiplyInPlace(T val)
        {
            I i, j;

            for (i = 0; i < ysize; ++i)
                for (j = 0; j < xsize; ++j)
                    data[i][j] *= val;
        }

        // I/O
        bool Load(const std::string& filename)
        {
            this->Clear();
            std::ifstream ifs(filename.c_str());

            if (!ifs.is_open())
            {
                WARN("Could not open the file " << filename);
                return false;
            }

            return this->LoadFromStream(ifs);
        }

        bool LoadBinary(const std::string& filename)
        {
            this->Clear();
            std::ifstream ifs(filename.c_str(), std::ios::binary);

            if (!ifs.good())
            {
                WARN("Could not open the file " << filename);
                return false;
            }

            return this->LoadBinaryFromStream(ifs);
        }

        virtual bool Equals(const Matrix<I, T>& m) const
        {
            // Sizes must match
            if (this->GetXSize() != m.GetXSize() ||
                this->GetYSize() != m.GetYSize()) {
                return false;
            }

            // All elements must match
            for (I i = 0; i < ysize; ++i)
                for (I j = 0; j < xsize; ++j)
                    if (data[i][j] != m.Get(i, j))
                        return false;

            return true;
        }

        /** LU Decomposition
           @return     Structure to access L, U, vector of pivots piv and its sign.
           Use GetL and GetU to get the decomposition from the returned matrix.
         */
        const Matrix<I, T>* LUDecomposition(I* piv, int* pivsign) const
        {
            // Use a "left-looking", dot-product, Crout/Doolittle algorithm.
            Matrix<I, T>* lu = new Matrix<I, T > (*this);
            I m = lu->GetYSize();
            I n = lu->GetXSize();
            I i;

            for (i = 0; i < m; ++i)
            {
                piv[i] = i;
            }

            *pivsign = 1;
            T* LUcolj = new T[m];
            memset(LUcolj, 0, sizeof (T) * m);
            // Outer loop.
            I j, k;

            for (j = 0; j < n; ++j)
            {
                // Make a copy of the j-th column to localize references.
                for (i = 0; i < m; ++i)
                {
                    LUcolj[i] = lu->Get(i, j);
                }

                // Apply previous transformations.
                for (i = 0; i < m; ++i)
                {
                    T* LUrowi = lu->GetMutable(i);
                    // Most of the time is spent in the following dot product.
                    I kmax = std::min(i, j);
                    double s = 0.0;

                    for (k = 0; k < kmax; ++k)
                    {
                        s += LUrowi[k] * LUcolj[k];
                    }

                    LUrowi[j] = LUcolj[i] -= s;
                }

                // Find pivot and exchange if necessary.
                I p = j;

                for (i = j + 1; i < m; ++i)
                {
                    if (fabs(LUcolj[i]) > fabs(LUcolj[p]))
                    {
                        p = i;
                    }
                }

                if (p != j)
                {
                    for (k = 0; k < n; ++k)
                    {
                        double t = lu->Get(p, k);
                        lu->Set(p, k, lu->Get(j, k));
                        lu->Set(j, k, t);
                    }

                    k = piv[p];
                    piv[p] = piv[j];
                    piv[j] = k;
                    *pivsign = -*pivsign;
                }

                // Compute multipliers.
                if (j < m && lu->Get(j, j) != static_cast<T> (0.0))
                    for (i = j + 1; i < m; ++i)
                        lu->Set(i, j, lu->Get(i, j) / lu->Get(j, j));
            }

            delete[] LUcolj;
            lu->SetIsLU(true);
            return lu;
        }

        /** Return lower triangular factor
           @return     L
         */
        virtual const Matrix<I, T>* GetL() const
        {
            CHECK((this->IsLU()));
            Matrix<I, T>* lmatrix = new Matrix(this->GetYSize(), this->GetXSize());
            I i, j;

            for (i = 0; i < this->GetYSize(); ++i)
            {
                for (j = 0; j < this->GetXSize(); ++j)
                {
                    if (i > j)
                    {
                        lmatrix->Set(i, j, this->Get(i, j));
                    }

                    else if (i == j)
                    {
                        lmatrix->Set(i, j, static_cast<T> (1.0));
                    }

                    else
                    {
                        lmatrix->Set(i, j, static_cast<T> (0.0));
                    }
                }
            }

            return lmatrix;
        }

        /** Return upper triangular factor
            @return     U
         */
        virtual const Matrix<I, T>* GetU() const
        {
            CHECK((this->IsLU()));
            Matrix<I, T>* umatrix = new Matrix<I, T > (this->GetXSize(), this->GetXSize());
            I i, j;

            for (i = 0; i < this->GetXSize(); ++i)
            {
                for (j = 0; j < this->GetXSize(); ++j)
                {
                    if (i <= j)
                    {
                        umatrix->Set(i, j, this->Get(i, j));
                    }

                    else
                    {
                        umatrix->Set(i, j, static_cast<T> (0.0));
                    }
                }
            }

            return umatrix;
        }

        /** Get a submatrix.
           @param r    Array of row indices.
           @param i0   Initial column index
           @param i1   Final column index
           @return     A(r(:),j0:j1)
           Used by LU decomposition to compute the inverse
         */
        virtual Matrix<I, T>* SubMatrix(const I* r, I r_size,
                                     I j0, I j1) const
        {
            Matrix<I, T>* submatrix = new Matrix(r_size, j1 - j0 + 1);
            I i, j;

            for (i = 0; i < r_size; ++i)
                for (j = j0; j <= j1; ++j)
                    submatrix->Set(i, j - j0, this->Get(r[i], j));

            return submatrix;
        }

        // Compute the determinant of a matrix.

        const double Determinant() const
        {
            CHECK((this->GetXSize() == this->GetYSize()));
            I* piv = new I[this->GetYSize()];
            int pivsign = 0;
            const Math::Matrix<I, T>* lu = this->LUDecomposition(piv, &pivsign);
            double det = static_cast<double> (pivsign);
            I  j;

            for (j = 0; j < this->GetYSize(); ++j)
                det *= lu->Get(j, j);

            delete lu;
            delete[] piv;
            return det;
        }

        // determines if the matrix is singular and therefore not invertible.

        virtual const bool IsSingular() const
        {
            CHECK((this->GetXSize() == this->GetYSize()));

            if (!is_lu)
            {
                // Already lu, just check if the diagonal has a zero element.
                I i;

                for (i = 0; i < this->GetXSize(); ++i)
                {
                    if (this->Get(i, i) == 0)
                        return true;
                }
            }

            else
            {
                // Check the determinant.
                return (this->Determinant() == 0.0);
            }

            return false;
        }

        const Matrix<I, T>* SolveLU(const Matrix<I, T>& matrix,
                                 const I* piv, int pivsign) const
        {
            CHECK_WITH_MESSAGE((this->IsLU()),
                               "Can not apply SolveLU to a non LU decomposed matrix");

            if (this->IsSingular())
            {
                WARN("Can not process singular LU matrix");
                return NULL;
            }

            I m = this->GetYSize();
            I n = this->GetXSize();
            // Copy right hand side with pivoting
            I nx = matrix.GetXSize();
            Matrix<I, T>* submatrix = matrix.SubMatrix(piv, m, 0, nx - 1);
            // Solve L*Y = B(piv,:)
            I k, i, j;

            for (k = 0; k < n; ++k)
            {
                for (i = k + 1; i < n; ++i)
                {
                    for (j = 0; j < nx; ++j)
                    {
                        submatrix->Set(i, j,
                                       submatrix->Get(i, j) - submatrix->Get(k, j) *
                                       this->Get(i, k));
                    }
                }
            }

            // Solve U*X = Y;
            for (k = n - 1; ; k--)
            {
                for (j = 0; j < nx; ++j)
                {
                    submatrix->Set(k, j, submatrix->Get(k, j) / this->Get(k, k));
                }

                for (i = 0; i < k; ++i)
                {
                    for (j = 0; j < nx; ++j)
                    {
                        submatrix->Set(i, j,
                                       submatrix->Get(i, j) - submatrix->Get(k, j) *
                                       this->Get(i, k));
                    }
                }

                if (k == 0)
                    break; // needed because k is unsigned
            }

            return submatrix;
        }

        virtual const Matrix<I, T>* Solve(const Matrix<I, T>& matrix) const
        {
            CHECK((this->GetYSize() == this->GetXSize()));
            CHECK((matrix.GetYSize() == matrix.GetXSize()));
            I* piv = new I[matrix.GetYSize()];
            int pivsign = 0;
            const Matrix<I, T>* lu = LUDecomposition(piv, &pivsign);
            const Matrix<I, T>* lu_solved = lu->SolveLU(matrix, piv, pivsign);

            if (lu_solved == NULL)
            {
                WARN("Can not solve the matrix!");
            }

            delete lu;
            delete[] piv;
            return lu_solved;
        }

        // Computes the inverse of a matrix. Returns NULL if the matrix is singular.

        virtual const Matrix<I, T>* Inverse() const
        {
            CHECK_WITH_MESSAGE((this->GetYSize() == this->GetXSize()),
                               "Needed a square matrix to invert");
            const Matrix<I, T>* identity = IdentityMatrixFactory(this->GetYSize());
            const Matrix<I, T>* inverse = this->Solve(*identity);
            delete identity;
            return inverse;
        }

        virtual bool LoadFromStream(std::istream& is)
        {
            this->Clear();
            std::string line;
            I xsize_, ysize_;
            is >> ysize_;
            is >> xsize_;
            this->Init(ysize_, xsize_);
            getline(is, line); // read the remaining portion of the line
            I num_line = 0;
            I read_elements = 0;

            while (!is.eof())
            {
                getline(is, line);

                if (line.empty())
                    continue; // skip empty lines

                std::vector<std::string> tokens;
                StringUtils::SplitToVector(line, &tokens, " ", false);

                if (static_cast<I>(tokens.size()) != xsize)
                {
                    WARN("Can not process line: " << line << " expecting " <<
                         xsize << " elements. Found " << tokens.size());
                    continue;
                }

                T value = 0;
                for (I i = 0; i < xsize; ++i) {
                    if (!StringUtils::ReadElement(tokens[i], &value))
                    {
                        WARN("Can not process token: " << tokens[i] << " in line " << line);
                        continue;
                    }

                    // This is a valid element, add it to the matrix.
                    this->Set(num_line, i, value);
                    ++read_elements;
                }

                ++num_line;
            }

            // Returns true if all elements have been successfully read.
            return (read_elements == this->Size());
        }

        virtual bool LoadBinaryFromStream(std::istream& is)
        {
            this->Clear();
            I xsize_, ysize_;
            is.read((char*)&ysize_, sizeof(ysize_));
            is.read((char*)&xsize_, sizeof(xsize_));
            if (ysize_ == 0 || xsize_ == 0) {
                WARN("Can not load an empty matrix.");
                return false;
            }
            this->Init(ysize_, xsize_);

            // Tmp space to store a line.
            std::vector<T> row(xsize);
            for (I i = 0; i < ysize; ++i) {
                if (is.eof()) {
                    WARN("End of stream found, can not load the matrix.");
                    return false;
                }
                // read one line.
                is.read(reinterpret_cast<char*>(row.data()), sizeof(T) * xsize);
                this->SetRow(i, row);
            }
            return true;
        }

        // Save the matrix to the stream.
        virtual bool SaveToStream(std::ostream& os) const
        {
            os << ysize << " " << xsize << std::endl;

            for (I i = 0; i < ysize; ++i)
                for (I j = 0; j < xsize; ++j)
                    if (j != xsize - 1)
                        os << data[i][j] << ' ';

                    else
                        os << data[i][j] << std::endl;

            return true;
        }

        virtual std::string ToString() const
        {
            std::ostringstream os;
            this->SaveToStream(os);
            return os.str();
        }
}; // end Matrix

} // end Math
#endif // MATH_MATRIX_H_
