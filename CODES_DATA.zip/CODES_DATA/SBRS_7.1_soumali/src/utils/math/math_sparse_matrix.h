/*
 * math_sparse_matrix.h
 *
 *  Created on: May 19, 2009
 *      Author: michi
 */

#ifndef MATH_SPARSE_MATRIX_H_
#define MATH_SPARSE_MATRIX_H_

#include "utils/math/math_matrix.h"

namespace Math
{
// A standard sparse Matrix. Provides all basic functionalities
// plus the implementation of basic matrix operations like transposition,
// sum, product, etc.

template < typename I = DefaultMatrixIndex, typename T = double >
class SparseMatrix : public BaseMatrix<I, T>
{
    public:
        typedef std::map<I, T> Row;

    private:
        typedef std::map<I, Row> DataContainer;
        DataContainer data;

        I ysize;

    public:

        // An element of the matrix. Used to insert or read elements from it.

        struct Element
        {
            I i1;
            I i2;
            T value;
            bool valid;

            Element(I i1_, I i2_, T value_, bool valid_) :
                i1(i1_), i2(i2_), value(value_), valid(valid_)
            {
            }

            Element(bool valid_) : valid(valid_)
            {
            }

            Element() : valid(false)
            {
            }
        };
        typedef struct Element Element;

        // Allows iterating through a sparse matrix. Use like this:
        // SparseMatrix<I, T> M;
        // SparseMatrix<I, T>::Iterator iter(M);
        // while (iter.HasNext()) {
        //   SparseMatrix<I, T>::ElementElement e = iter.GetNext();
        //   Do something with e
        // }

        class Iterator
        {
            private:
                typename DataContainer::const_iterator iter;
                typename Row::const_iterator iter1;

                const SparseMatrix<I, T>* matrix;

            public:

                Iterator(const SparseMatrix<I, T>& matrix_)
                {
                    matrix = &matrix_;
                    iter = matrix->data.begin();
                    const Row* row = matrix->Get(iter->first);
                    iter1 = row->begin();
                }

                inline Element GetNext()
                {
                    if (HasNext())
                    {
                        Element e(iter->first, iter1->first, iter1->second, true);
                        MovePointerToNext();
                        return e;
                    }

                    return Element(false);
                }

                inline void Rewind()
                {
                    iter = matrix->data.begin();
                    const Row* row = matrix->Get(iter->first);
                    iter1 = row->begin();

                    while (this->HasNext() && iter1 == row->end())
                    {
                        ++iter;
                        row = matrix->Get(iter->first);
                        iter1 = row->begin();
                    }
                }

                inline bool HasNext() const
                {
                    return (iter != matrix->data.end());
                }
            private:

                void MovePointerToNext()
                {
                    if (!HasNext())
                        return;

                    const Row* row = matrix->Get(iter->first);

                    if (iter1 != row->end()) // not end of row, just move to the next
                        ++iter1;

                    while (HasNext() && iter1 == row->end())
                    {
                        // end of row, go to the next one
                        ++iter;

                        if (iter != matrix->data.end())
                        {
                            row = matrix->Get(iter->first);
                            iter1 = row->begin();
                        }
                    }
                }
        };
        friend class Iterator;

        class RowIterator
        {
            private:
                typename DataContainer::const_iterator iter;
                const SparseMatrix<I, T>* matrix;

            public:

                RowIterator(const SparseMatrix<I, T>& matrix_)
                {
                    matrix = &matrix_;
                    iter = matrix->data.begin();
                }

                inline const Row* GetNext()
                {
                    if (HasNext())
                    {
                        const Row* row = matrix->Get(iter->first);
                        ++iter;
                        return row;
                    }

                    return NULL;
                }

                inline void Rewind()
                {
                    iter = matrix->data.begin();
                }

                inline bool HasNext() const
                {
                    return (iter != matrix->data.end());
                }
        };
        friend class RowIterator;

        // Constructors.

        SparseMatrix() : ysize(0)
        {
        }

        SparseMatrix(const SparseMatrix<I, T>& matrix)
        {
            this->Copy(matrix);
        }

        virtual ~SparseMatrix()
        {
            this->Clear();
        }

        void Copy(const SparseMatrix<I, T>& matrix)
        {
            this->Clear();
            Iterator iter(matrix);

            while (iter.HasNext())
            {
                Element el = iter.GetNext();
                this->Set(el);
            }
        }

        virtual void Clear()
        {
            ysize = static_cast<I>(0);
        }

        virtual void Set(const Element& el)
        {
            CHECK(el.valid);
            data[el.i1][el.i2] = el.value;
        }

        // Note: the ysize is unknown and depends on the sparsity of the matrix
        virtual I Size() const
        {
            I size = static_cast<I>(0);

            for (typename DataContainer::const_iterator iter = data.begin();
                    iter != data.end(); ++iter)
            {
                size += static_cast<I> (iter->second.size());
            }

            return size;
        }

        inline I GetYSize() const
        {
            return ysize;
        }

        // Inlined for speed, remove the inline if inheritance is used with
        // this class.

        inline void Set(const I i1, const I i2, T val)
        {
            data[i1][i2] = val;
        }

        inline void Add(const I i1, const I i2, T val)
        {
            data[i1][i2] += val;
        }

        inline void Add(const Element& el)
        {
            CHECK(el.valid);
            data[el.i1][el.i2] += el.value;
        }

        inline T Get(const I i1, const I i2) const
        {
            // Unsafe but fast!
            typename DataContainer::const_iterator iter = data.find(i1);
            typename Row::const_iterator iter1 = iter->second.find(i2);
            return iter1->second;
        }

        inline bool Get(const I i1, const I i2, T* value) const
        {
            // Safe but slow!
            typename DataContainer::const_iterator iter = data.find(i1);

            if (iter == data.end())
                return false;

            typename Row::const_iterator iter1 = iter->second.find(i2);

            if (iter1 == iter->second.end())
                return false;

            *value = iter1->second;
            return true;
        }

        inline const Row* Get(const I i1) const
        {
            typename DataContainer::const_iterator iter = data.find(i1);

            if (iter == data.end())
                return NULL;

            return &(iter->second);
        }
        // end Inlined

        virtual void AddInPlace(const SparseMatrix<I, T>& matrix)
        {
            Iterator iter(matrix);

            while (iter.HasNext())
            {
                Element el = iter.GetNext();
                this->Add(el);
            }
        }

        virtual void MultiplyInPlace(const T val)
        {
            for (typename DataContainer::const_iterator iter = data.begin();
                    iter != data.end(); ++iter)
            {
                const Row& row = iter->second;

                for (typename Row::const_iterator iter1 = row.begin();
                        iter1 != row.end(); ++iter1)
                {
                    this->Set(iter->first, iter1->first, val * iter1->second);
                }
            }
        }

        virtual T GetMaxRowSum() const {
            T max_sum = std::numeric_limits<T>::min();
            for (typename DataContainer::const_iterator iter = data.begin();
                 iter != data.end(); ++iter) {
                const Row& row = iter->second;
                T sum = 0;
                for (typename Row::const_iterator iter1 = row.begin();
                     iter1 != row.end(); ++iter1) {
                    sum += iter1->first;
                }
                if (sum > max_sum)
                    max_sum = sum;
            }
            return max_sum;
        }

        virtual bool Load(const std::string& filename)
        {
            this->Clear();
            std::ifstream ifs(filename.c_str());

            if (!ifs.good()) {
                WARN("Could not open the file " << filename);
                return false;
            }

            return this->LoadFromStream(ifs);
        }

        virtual bool LoadBinary(const std::string& filename)
        {
            this->Clear();
            std::ifstream ifs(filename.c_str(), std::ios::binary);

            if (!ifs.good()) {
                WARN("Could not open the file " << filename);
                return false;
            }

            return this->LoadBinaryFromStream(ifs);
        }

        // Replaced by functions in math_matrix_operations.h
        /* // Multiply this by matrix_
        virtual SparseMatrix<I, T>* Multiply(const SparseMatrix<I, T>& matrix_) const {
            // Result matrix
            SparseMatrix<I, T>* rmatrix = new SparseMatrix<I, T>();

            // Transpose matrix to index it by row.
            SparseMatrix<I, T>* matrix1 = matrix_.Transpose();
            for (typename DataContainer::const_iterator iter = data.begin();
                     iter != data.end(); ++iter) {
                    const Row& row = iter->second;
                    for (typename Row::const_iterator iter1 = row.begin();
                             iter1 != row.end(); ++iter1) {
                            const Row* row1 = matrix1->Get(iter1->first);
                            if (row1 != NULL) {
                                    rmatrix->Set(iter->first, iter1->first,
                                                             DotProduct(row, *row1));
                            }
                    }
            }

            delete matrix1;
            return rmatrix;
        }
        virtual SparseMatrix<I, T>* Multiply(const T& val) const {
            SparseMatrix<I, T>* m = new SparseMatrix<I, T>();

            for (typename DataContainer::const_iterator iter = data.begin();
                     iter != data.end(); ++iter) {
                    const Row& row = iter->second;
                    for (typename Row::const_iterator iter1 = row.begin();
                             iter1 != row.end(); ++iter1) {
                            m->Set(iter->first, iter1->first, val * iter1->second);
                    }
            }

            return m;
        }
        // Basic Matrix operations.
        virtual SparseMatrix<I, T>* Add(const SparseMatrix<I, T>& matrix_) const {
            SparseMatrix<I, T>* m = new SparseMatrix<I, T>(*this);

            Iterator iter(matrix_);
            while(iter.HasNext()) {
                    Element el = iter.GetNext();
                    m->Add(el);
            }

            return m;
        }
        // Basic Matrix operations.
        virtual SparseMatrix<I, T>* Transpose() const {
            SparseMatrix<I, T>* m = new SparseMatrix<I, T>();

            for (typename DataContainer::const_iterator iter = data.begin();
                     iter != data.end(); ++iter) {
                    const Row& row = iter->second;
                    for (typename Row::const_iterator iter1 = row.begin();
                             iter1 != row.end(); ++iter1) {
                            m->Set(iter1->first, iter->first, iter1->second);
                    }
            }

            return m;
        }
        // Multiply this by vector_
        virtual SparseVector<I, T>* Multiply(const SparseVector<I, T>& svector) const {
            // Result matrix
            SparseVector<I, T>* rvector = new SparseVector<I, T>();

            for (typename DataContainer::const_iterator iter = data.begin();
                     iter != data.end(); ++iter) {
                    const Row& row = iter->second;
                    for (typename Row::const_iterator iter1 = row.begin();
                             iter1 != row.end(); ++iter1) {
                            T el_value;
                            if (svector.Get(iter1->first, &el_value))
                                    rvector->Add(iter->first, el_value);
                    }
            }

            return rvector;
        } */

        // Save the matrix to the stream.

        virtual bool SaveToStream(std::ostream& os) const
        {
            for (typename DataContainer::const_iterator iter = data.begin();
                    iter != data.end(); ++iter)
            {
                os << iter->first;
                const Row& row = iter->second;

                for (typename Row::const_iterator iter1 = row.begin();
                        iter1 != row.end(); ++iter1)
                {
                    os << '\t' << iter1->first << ':' << iter1->second;
                }

                os << '\n';
            }

            return true;
        }

        virtual bool LoadFromStream(std::istream& is)
        {
            this->Clear();
            std::string line;

            I index = 0;
            while (!is.eof()) {
                is >> index;
                getline(is, line);
                std::map<I, T> pairs;
                StringUtils::ReadPairs<I, T>(line, &pairs, " ", ":");
                for (typename std::map<I, T>::const_iterator iter = pairs.begin();
                     iter != pairs.end(); ++iter) {
                    this->Set(index, iter->first, iter->second);
                }
            }

            return (this->Size() > 0);
        }

        virtual bool LoadBinaryFromStream(std::istream& is) {
            this->Clear();

            I xindex = 0, yindex = 0;
            T value = 0;
            while (!is.eof()) {
                is.read((char*)&yindex, sizeof(yindex));
                is.read((char*)&xindex, sizeof(xindex));
                is.read((char*)&value, sizeof(value));
                this->Set(xindex, yindex, value);
            }

            return (this->Size() > 0);
        }

        virtual std::string ToString() const
        {
            std::ostringstream os;
            this->SaveToStream(os);
            return os.str();
        }
}; // end SparseMatrix
} // end Math

#endif /* MATH_SPARSE_MATRIX_H_ */
