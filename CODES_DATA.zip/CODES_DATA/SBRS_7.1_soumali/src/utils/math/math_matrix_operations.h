/*
 * math_matrix_operations.h
 *
 *  Created on: May 21, 2009
 *      Author: michi
 */

#ifndef MATH_MATRIX_OPERATIONS_H_
#define MATH_MATRIX_OPERATIONS_H_

#include "utils/math/math_sparse_vector.h"
#include "utils/math/math_vector_operations.h"
#include "utils/math/math_sparse_matrix.h"
#include "utils/math/math_symmetric_matrix.h"

namespace Math
{

template <typename I, typename T>
class MatrixOperations
{
    public:
        // Transpose a matrix.
        // e.g. matrix^T. Returns the result in a new matrix.

        static Matrix<I, T>*
        Transpose (const Matrix<I, T>& matrix)
        {
            Matrix<I, T>* nmatrix = new Matrix<T > (matrix.GetYSize (), matrix.GetXSize ());
            I i, j;

            for (i = 0; i < matrix.GetYSize (); ++i)
                for (j = 0; j < matrix.GetXSize (); ++j)
                    nmatrix->Set (j, i, matrix.Get (i, j));

            return nmatrix;
        }

        // Multiplies two matrices.
        // e.g. m1*m2. Returns the result in a new matrix.

        static Matrix<I, T>*
        Multiply (const Matrix<I, T>& m1, const Matrix<I, T>& m2)
        {
            CHECK_WITH_MESSAGE ((m1.GetXSize () == m2.GetYSize ()),
                                "Can not multiply matrices with incompatible sizes" <<
                                m1.GetYSize () << "x" << m1.GetXSize () << " vs. " <<
                                m2.GetYSize () << "x" << m2.GetXSize ());
            Matrix<I, T>* m3 = new Matrix<T > (m1.GetYSize (), m2.GetXSize ());
            I i, j, k;

            for (i = 0; i < m1.GetYSize (); ++i)
                for (j = 0; j < m2.GetXSize (); ++j)
                    for (k = 0; k < m1.GetYSize (); ++k)
                        m3->Add (i, j, m1.Get (i, k) * m2.Get (k, j));

            return m3;
        }

        // Multiplies a matrix by a vector.
        // e.g. m*v. Returns the result in a new matrix.

        static Vector<T>*
        Multiply (const Matrix<I, T>& m, const Vector<T>& v)
        {
            CHECK_EQ_WITH_MESSAGE (m.GetXSize (), v.Size (),
                                   "Can not multiply the matrix with a vector with incompatible size");
            Vector<T>* v2 = new Vector<T > (m.GetXSize ());
            I i, j;

            for (i = 0; i < m.GetYSize (); ++i)
                for (j = 0; j < m.GetXSize (); ++j)
                    v2->Add (i, m.Get (i, j) * v.Get (j));

            return v2;
        }

        // Multiplies a matrix by a vector. Avoids allocating a new vector if the
        // provided v2 is already of the right size

        static void
        Multiply (const Matrix<I, T>& m, const Vector<T>& v, Vector<T>* v2)
        {
            CHECK (v2 != NULL);
            CHECK_EQ_WITH_MESSAGE (m.GetXSize (), static_cast<I>(v.Size ()),
                                   "Can not multiply the matrix with a vector with incompatible size");

            // Prepare the vector for the computation
            if (v2->Size () != m.GetYSize ())
                v2->Init (m.GetYSize());

            else
                v2->SetAll (static_cast<T> (0));

            // All is cached for maximum speed.
            I i, j;
            I ysize = m.GetYSize ();
            I xsize = m.GetXSize ();

            //            for (i = 0; i < ysize; ++i)
            //                for (j = 0; j < xsize; ++j)
            //                    v2->Add (i, m.Get (i, j) * v.Get (j));
            for (i = 0; i < ysize; ++i)
            {
                // cached for maximum speed
                const T* m_row = m.Get(i);
                const T* v_col = v.GetData();

                for (j = 0; j < xsize; ++j)
                {
                    v2->Add (i, m_row[j] * v_col[j]);
                }
            }
        }

        // Multiply by a scalar. Returns the result in a new matrix.

        static Matrix<I, T>*
        Multiply (const Matrix<I, T>& m, const T& val)
        {
            Matrix<I, T>* m1 = new Matrix<T > (m.GetXSize (), m.GetYSize ());
            I i, j;

            for (i = 0; i < m.GetYSize (); ++i)
                for (j = 0; j < m.GetXSize (); ++j)
                    m1->Set (i, j, val * m.Get (i, j));

            return m1;
        }

        // Add two matrices: m1+m2. Returns the result in a new matrix.

        static Matrix<I, T>*
        Add (const Matrix<I, T>& m1, const Matrix<I, T>& m2)
        {
            CHECK_WITH_MESSAGE ((m1.GetXSize () == m2.GetXSize ()),
                                "Can not add matrices with different sizes");
            CHECK_WITH_MESSAGE ((m1.GetYSize () == m2.GetYSize ()),
                                "Can not add matrices with different sizes");
            Matrix<I, T>* m3 = new Matrix<T > (m1.GetYSize (), m1.GetXSize ());
            I i, j;

            for (i = 0; i < m1.GetYSize (); ++i)
                for (j = 0; j < m1.GetXSize (); ++j)
                    m3->Add (i, j, m1.Get (i, j) + m2.Get (i, j));

            return m3;
        }
        // Subtracts two matrices: m1-m2. Returns the result in a new matrix.

        static Matrix<I, T>*
        Sub (const Matrix<I, T>& m1, const Matrix<I, T>& m2)
        {
            CHECK_WITH_MESSAGE ((m1.GetXSize () == m2.GetXSize ()),
                                "Can not add matrices with different sizes");
            CHECK_WITH_MESSAGE ((m1.GetYSize () == m2.GetYSize ()),
                                "Can not add matrices with different sizes");
            Matrix<I, T>* m3 = new Matrix<T > (m1.GetYSize (), m1.GetXSize ());
            I i, j;

            for (i = 0; i < m1.GetYSize (); ++i)
                for (j = 0; j < m1.GetXSize (); ++j)
                    m3->Add (i, j, m1.Get (i, j) - m2.Get (i, j));

            return m3;
        }
}; // end MatrixOperations

template <typename I, typename T>
class SparseMatrixOperations
{
    public:
        // Transpose a sparse matrix.

        static SparseMatrix<I, T>*
        Transpose (const SparseMatrix<I, T>& matrix)
        {
            SparseMatrix<I, T>* nmatrix = new SparseMatrix<I, T > ();
            typename SparseMatrix<I, T>::Iterator iter (matrix);

            while (iter.HasNext ())
            {
                typename SparseMatrix<I, T>::Element el = iter.GetNext ();
                nmatrix->Set (el.i2, el.i1, el.value);
            }

            return nmatrix;
        }

        // Add two sparse matrices.

        static SparseMatrix<I, T>*
        Add (
            const SparseMatrix<I, T>& m1, const SparseMatrix<I, T>& m2)
        {
            SparseMatrix<I, T>* m3 = new SparseMatrix<I, T > (m1);
            typename SparseMatrix<I, T>::Iterator iter (m2);

            while (iter.HasNext ())
                m3->Add (iter.GetNext ());

            return m3;
        }

        // Subtract two sparse matrices.

        static SparseMatrix<I, T>*
        Sub (
            const SparseMatrix<I, T>& m1, const SparseMatrix<I, T>& m2)
        {
            SparseMatrix<I, T>* m3 = new SparseMatrix<I, T > (m1);
            typename SparseMatrix<I, T>::Iterator iter (m2);

            while (iter.HasNext ())
                m3->Sub (iter.GetNext ());

            return m3;
        }

        // Multiply a sparse matrix by a scalar.

        static SparseMatrix<I, T>*
        Multiply (const SparseMatrix<I, T>& m, const T& val)
        {
            SparseMatrix<I, T>* m1 = new SparseMatrix<I, T > ();
            typename SparseMatrix<I, T>::Iterator iter (m);

            while (iter.HasNext ())
            {
                typename SparseMatrix<I, T>::Element el = iter.GetNext ();
                el.value *= val;
                m1->Add (el);
            }

            return m1;
        }

        // Multiply two sparse matrices.

        static SparseMatrix<I, T>*
        Multiply (
            const SparseMatrix<I, T>& m1, const SparseMatrix<I, T>& m2)
        {
            // Result matrix
            SparseMatrix<I, T>* rmatrix = new SparseMatrix<I, T > ();
            // Transpose matrix to index it by row.
            SparseMatrix<I, T>* m2transpose = Transpose (m2);
            typename SparseMatrix<I, T>::RowIterator iter (m1);

            while (iter.HasNext ())
            {
                const typename SparseMatrix<I, T>::Row* row = iter.GetNext ();

                for (typename SparseMatrix<I, T>::Row::const_iterator iter1 = row->begin ();
                        iter1 != row->end (); ++iter1)
                {
                    const typename SparseMatrix<I, T>::Row* row1 = m2transpose->Get (iter1->first);

                    if (row1 != NULL)
                    {
                        T val = SparseMatrix<I, T>::DotProduct (*row, *row1);

                        if (val != static_cast<T> (0.0))
                            rmatrix->Set (iter->first, iter1->first, val);
                    }
                }
            }

            delete m2transpose;
            return rmatrix;
        }

        // Multiply two sparse matrices by a sparse vector.

        static SparseVector<I, T>*
        Multiply (
            const SparseMatrix<I, T>& m1, const SparseVector<I, T>& svector)
        {
            // Result matrix
            SparseVector<I, T>* rvector = new SparseVector<I, T > ();
            typename SparseMatrix<I, T>::RowIterator iter (m1);

            while (iter.HasNext ())
            {
                const typename SparseMatrix<I, T>::Row* row = iter.GetNext ();

                for (typename SparseMatrix<I, T>::Row::const_iterator iter1 = row->begin ();
                        iter1 != row->end (); ++iter1)
                {
                    T el_value;

                    if (svector.Get (iter1->first, &el_value))
                        rvector->Add (iter->first, el_value);
                }
            }

            return rvector;
        }

        // Multiply a dense matrix by a sparse vector, returns a sparse vector.

        static SparseVector<I, T>*
        MultiplyToSparse (
            const Matrix<I, T>& m1, const SparseVector<I, T>& svector)
        {
            // Result vector
            SparseVector<I, T>* rvector = new SparseVector<I, T > ();
            // TODO(michi): optimize this.
            I i;

            for (i = 0; i < m1.GetYSize (); ++i)
            {
                const T* x1 = m1.Get (i);
                T value = SparseVector<I, T>::DotProduct (x1, svector);

                if (value != static_cast<T> (0.0))
                    rvector->Set (i, value);
            }

            return rvector;
        }

        // Multiply a dense matrix by a sparse vector, returns a dense vector.

        static Vector<T>*
        MultiplyToDense (
            const Matrix<I, T>& m1, const SparseVector<I, T>& svector)
        {
            // Result vector
            Vector<T>* rvector = new Vector<T > (m1.GetYSize ());
            // TODO(michi): optimize this.
            I i;

            for (i = 0; i < m1.GetYSize (); ++i)
            {
                const T* x1 = m1.Get (i);
                T value = Math::SparseVectorOperations<I, T>::DotProduct (
                              x1, m1.GetXSize (), svector);
                rvector->Set (i, value);
            }

            return rvector;
        }

        // Multiplies a sparse matrix by a dense vector.
        // Since matrix is sparse, when object is not found it is considered as 0.
        // !!!! Dangerous !!!! because it's not sure that Dense-Matrix
        // deriving from Sparse-Matrix has a compatible size with the Vector. Correct dimensions of
        // m, v and v2 must be guaranteed from outside. Especially v2 must be initialized.

        static void
        Multiply (const SparseMatrix<I, T>& m, const Vector<T>& v, Vector<T>* v2)
        {
            CHECK (v2->Size() != 0);
            CHECK_EQ (m.GetYSize(), static_cast<I>(v2->Size()));
            v2->SetAll (static_cast<T> (0));
            // All is cached for maximum speed.
            I i = static_cast<I>(0);
            I ysize = v2->Size();

            for (i = 0; i < ysize; ++i)
            {
                const T* v_col = v.GetData();
                const typename SparseMatrix<I, T>::Row* m_row = m.Get(i);
                T value = static_cast<T>(0);
                // Version 1: fast
                typename SparseMatrix<I, T>::Row::const_iterator iter;

                for (iter = m_row->begin(); iter != m_row->end(); ++iter)
                {
                    value += (iter->second * v_col[iter->first]);
                }

                // Version 2: slow
                /*for (j = 0; j < xsize; ++j)
                {
                	typename SparseMatrix<I, T>::Row::const_iterator iter = m_row->find(j);
                	if(iter != m_row->end())
                		value += (iter->second * v_col[j]);
                }*/
                v2->Set(i, value);
            }
        }


}; // end SparseMatrixOperations

template <typename I, typename T>
class SymmetricMatrixOperations
{
    public:

        // Multiplies a matrix by a vector. Avoids allocating a new vector if the
        // provided v2 is already of the right size
        static void
        Multiply (const SymmetricMatrix<I, T>& m, const Vector<T>& v, Vector<T>* v2)
        {
            CHECK (v2 != NULL);
            CHECK_EQ_WITH_MESSAGE (m.GetYSize (), static_cast<I>(v.Size ()),
                                   "Can not multiply the matrix with a vector with incompatible size");

            // Prepare the vector for the computation
            if (v2->Size () != m.GetYSize ())
                v2->Init (m.GetYSize());

            else
                v2->SetAll (static_cast<T> (0));

            // All is cached for maximum speed.
            I i, j;
            I ysize = m.GetYSize ();

            for (i = 0; i < ysize; ++i)
            {
                // cached for maximum speed
                const T* v_col = v.GetData();

                for (j = 0; j < ysize; ++j)
                {
                    v2->Add (i, m.Get(i, j) * v_col[j]);
                }
            }
        }
}; // end SymmetricMatrixOperations

} // end Math

#endif /* MATH_MATRIX_OPERATIONS_H_ */
