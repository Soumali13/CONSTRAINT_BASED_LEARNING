/*
 * math_vector_operations.h
 *
 *  Created on: May 21, 2009
 *      Author: michi
 */

#ifndef MATH_VECTOR_OPERATIONS_H_
#define MATH_VECTOR_OPERATIONS_H_

#include "utils/math/math_sparse_vector.h"
#include "utils/math/math_sparse_matrix.h"

namespace Math
{

template <typename T>
class VectorOperations {
    public:
        static Vector<T>*
        Add (const Vector<T>& vec1, Vector<T>& vec2) {
            CHECK_EQ(vec1.Size(), vec2.Size ());
            Vector<T>* res = new Vector<T>(vec1.Size ());
            for (VectorIndex i = 0; i < vec1.Size (); ++i)
                res->Set (i, vec1.Get(i) + vec2.Get(i));

            return res;
        }

        static Vector<T>*
        Sub (const Vector<T>& vec1, Vector<T>& vec2)
        {
            CHECK ((vec1.Size () == vec2.Size ()));
            Vector<T>* res = new Vector<T > (vec1.Size ());
            VectorIndex i;

            for (i = 0; i < vec1.Size (); ++i)
                res->Set (i, vec1.Get (i) - vec2.Get (i));

            return res;
        }

        static Vector<T>*
        Multiply (const Vector<T>& vec, const T& val)
        {
            Vector<T>* res = new Vector<T > (vec.Size ());
            VectorIndex i;

            for (i = 0; i < vec.Size (); ++i)
                res->Set (i, val * vec.Get (i));

            return res;
        }

        // Dot product between two vectors.

        static T
        DotProduct (const T* x1, const T* x2, VectorIndex size)
        {
            T value = static_cast<T> (0.0);
            VectorIndex i;

            for (i = 0; i < size; ++i)
                value += x1[i] * x2[i];

            return value;
        }
        // Dot product between two vectors.

        static T
        DotProduct (const Vector<T>& vec1, const Vector<T>& vec2)
        {
            CHECK_WITH_MESSAGE ((vec1.Size () == vec2.Size ()),
                                "Can not perform dot product on vectors of different sizes");
            T value = static_cast<T> (0.0);
            VectorIndex i;

            for (i = 0; i < vec1.Size (); ++i)
                value += vec1.Get (i) * vec2.Get (i);

            return value;
        }
}; // end VectorOperations

template <typename I, typename T>
class SparseVectorOperations
{
    public:

        /**
         * Add/Sub among sparse and dense vectors.
         */
        static SparseVector<I, T>*
        Add (const SparseVector<I, T>& vec1,
             const SparseVector<I, T>& vec2)
        {
            SparseVector<I, T>* svector = new SparseVector<I, T > (vec1);
            svector->AddInPlace (vec2);
            return svector;
        }
        // Returns vec1-vec2

        static SparseVector<I, T>*
        Sub (const SparseVector<I, T>& vec1,
             const SparseVector<I, T>& vec2)
        {
            SparseVector<I, T>* svector = new SparseVector<I, T > (vec1);
            svector->SubInPlace (vec2);
            return svector;
        }

        // Returns vec1+vec2

        static SparseVector<I, T>*
        Add (const SparseVector<I, T>& vec1,
             const Vector<T>& vec2)
        {
            SparseVector<I, T>* svector = new SparseVector<I, T > (vec1);
            svector->AddInPlace (vec2);
            return svector;
        }

        // Returns vec1-vec2
        static SparseVector<I, T>*
        Sub (const SparseVector<I, T>& vec1,
             const Vector<T>& vec2)
        {
            SparseVector<I, T>* svector = new SparseVector<I, T > (vec1);
            svector->SubInPlace (vec2);
            return svector;
        }
        // Returns vec1+vec2
        // No new dimensions are added, only the dimensions of vec1 are
        // added to the returned vector.

        static SparseVector<I, T>*
        AddOverVec1Dimentions (const SparseVector<I, T>& vec1,
                               const Vector<T>& vec2)
        {
            SparseVector<I, T>* svector = new SparseVector<I, T > (vec1);
            VectorIndex i;

            for (i = 0; i < vec2.Size (); ++i)
                if (vec1.Has (i))
                    svector->Add (i, vec2.Get (i));

            return svector;
        }

        // Returns vec1-vec2
        // No new dimensions are added, only the dimensions of vec1 are
        // added to the returned vector.

        static SparseVector<I, T>*
        SubOverVec1Dimentions (const SparseVector<I, T>& vec1,
                               const Vector<T>& vec2)
        {
            SparseVector<I, T>* svector = new SparseVector<I, T > (vec1);
            VectorIndex i;

            for (i = 0; i < vec2.Size (); ++i)
                if (vec1.Has (i))
                    svector->Sub (i, vec2.Get (i));

            return svector;
        }

        /**
         * Dot Products implementations among different types of sparse vectors.
         */
        // Dot product between two sparse matrix rows.

        static T
        DotProduct (const typename SparseMatrix<I, T>::Row& x1,
                    const typename SparseMatrix<I, T>::Row& x2)
        {
            T value = static_cast<T> (0);
            typename SparseMatrix<I, T>::Row::const_iterator iter1 = x1.begin ();

            for (; iter1 != x1.end (); ++iter1)
            {
                typename SparseMatrix<I, T>::Row::const_iterator iter2 =
                    x2.find (iter1->first);

                if (iter2 != x2.end ())
                    value += iter1->second * iter2->second;
            }

            return value;
        }

        // Dot product between a fixed and a sparse matrix row.

        static T
        DotProduct (const T* x1, I x1size, const typename SparseMatrix<I, T>::Row& x2)
        {
            T value = static_cast<T> (0.0);
            typename SparseMatrix<I, T>::Row::const_iterator iter1 = x2.begin ();

            for (; iter1 != x2.end (); ++iter1)
                if (iter1->first < x1size)
                    value += iter1->second * x1[iter1->first];

            return value;
        }

        // Dot product between a fixed and a sparse vector.

        static T
        DotProduct (const T* x1, I x1size, const SparseVector<I, T>& x2)
        {
            T value = static_cast<T> (0.0);
            typename SparseVector<I, T>::Iterator iter (x2);

            while (iter.HasNext ())
            {
                typename SparseVector<I, T>::Element el = iter.GetNext ();

                if (el.i < x1size)
                    value += el.value * x1[el.i];
            }

            return value;
        }
        // Dot product between two sparse vectors.

        static T
        DotProduct (
            const SparseVector<I, T>& x1,
            const SparseVector<I, T>& x2)
        {
            T value = static_cast<T> (0);
            typename SparseVector<I, T>::Iterator iter (x1);

            while (iter.HasNext ())
            {
                typename SparseVector<I, T>::Element el1 = iter.GetNext ();
                typename SparseVector<I, T>::Element el2 = x2.Get (el1.i);

                if (el2.valid)
                    value += el1.value * el2.value;
            }

            return value;
        }

        // Dot product between a sparse and a dense vector.

        static T
        DotProduct (
            const SparseVector<I, T>& x1,
            const Vector<T>& x2)
        {
            T value = static_cast<T> (0);
            typename SparseVector<I, T>::Iterator iter (x1);

            while (iter.HasNext ())
            {
                typename SparseVector<I, T>::Element el1 = iter.GetNext ();

                if (el1.i < x2.Size ())
                    value += el1.value * x2.Get (el1.i);
            }

            return value;
        }
}; // end SparseVectorOperations
} // end Math
#endif /* MATH_VECTOR_OPERATIONS_H_ */
