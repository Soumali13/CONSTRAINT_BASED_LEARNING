/*
 * containers.h
 *
 *  Created on: 25/feb/2015
 *      Author: michi
 */

#ifndef UTILS_CONTAINERS_H
#define UTILS_CONTAINERS_H

#include <queue>
#include <vector>

namespace std {
template<typename T, typename Container, typename Compare>
class IterablePriorityQueue : public std::priority_queue<T, Container, Compare> {
public:
    typedef typename Container::iterator iterator;
    typedef typename Container::const_iterator const_iterator;
    inline iterator begin() { return this->c.begin(); }
    inline iterator end() { return this->c.end(); }
    inline const_iterator begin() const { return this->c.begin(); }
    inline const_iterator end() const { return this->c.end(); }
};

template<typename T, typename Compare>
class PrereservedIterablePriorityQueue : public IterablePriorityQueue<T, std::vector<T>, Compare> {
public:
    inline PrereservedIterablePriorityQueue(int reserved_size) {
        this->c.reserve(reserved_size);
    }
};

template<typename T, typename Compare>
class PrereservedPriorityQueue : public std::priority_queue<T, std::vector<T>, Compare> {
public:
    inline PrereservedPriorityQueue(int reserved_size) {
        this->c.reserve(reserved_size);
    }
};
}  // end std

#endif /* UTILS_CONTAINERS_H */
