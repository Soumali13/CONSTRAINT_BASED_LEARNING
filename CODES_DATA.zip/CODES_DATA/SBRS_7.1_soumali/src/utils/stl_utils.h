/*
 * stl_utils.h
 *
 *  Created on: 13/giu/2011
 *      Author: claudio
 */

#ifndef STL_UTILS_H
#define STL_UTILS_H

#include <map>
#include "utils/general.h"


namespace std {

template<typename V>
void DeallocVectorOfPointers(V* vec)
{
    for (typename V::iterator i = vec->begin(); i != vec->end(); ++i)
        if (*i != NULL)
        {
            delete *i;
            *i = NULL;
        }
}

template<typename M>
void DeallocMapOfPointers(M* map_)
{
    for (typename M::iterator i = map_->begin(); i != map_->end(); ++i)
        if (i->second != NULL)
        {
            delete i->second;
            i->second = NULL;
        }
}

// Handy one line container of pairs O(n) lookup. With one single copy of the value.
template <typename Container, typename K, typename V>
inline bool Find(const Container& c,
                 const K& key,
                 const V& default_value,
                 V* value) {
    typename Container::const_iterator iter = c.begin();
    for (; iter != c.end(); ++iter) {
        if (iter->first == key) {
            *value = iter->second;
            return true;
        }
    }
    return false;
}

// Handy one line container of pairs O(n) lookup. With no copy of the value.
template <typename Container, typename K, typename V>
inline const V* Find(const Container & c, const K& key) {
    typename Container::const_iterator iter = c.begin();
    for (; iter != c.end(); ++iter) {
        if (iter->first == key) {
            return &(iter->second);
        }
    }
    return NULL;
}

// Handy one line map O(log n) lookup. Return by pointer to avoid any
// copy of the value.
template <typename K, typename V>
inline const V* Find(const std::map<K, V>& m, const K& key) {
    typename std::map<K, V>::const_iterator iter = m.find(key);
    return (iter == m.end() ? NULL : &iter->second);
}

// Handy one line map O(log n) lookup. Return by reference to possibly avoid to
// copy the value.
// NOTE: Until when the output reference is used, the map and default_value
// should not be destroyed.
template <typename K, typename V>
inline const V& Find(const std::map<K, V>& m,
                     const K& key,
                     const V& default_value) {
    typename std::map<K, V>::const_iterator iter = m.find(key);
    return (iter == m.end() ? default_value : iter->second);
}

// Handy one line map O(log n) lookup. Return by reference to possibly avoid to
// copy the value.
// NOTE: Until when the output reference is used, the map and default_value
// should not be destroyed.
template <typename Container, typename K, typename V>
inline const V& FindOrDie(const Container& m, const K& key) {
    typename Container::const_iterator iter = m.find(key);
    CHECK(iter != m.end());
    return iter->second;
}

// Handy one line map lookup. With one single copy of the value.
template <typename K, typename V>
inline bool Has(const std::map<K, V>& m, const K& key) {
    typename std::map<K, V>::const_iterator iter = m.find(key);
    return (iter != m.end());
}

// Handy one line map lookup. With one single copy of the value.
template <typename S>
inline bool Has(const S& m, const typename S::key_type& key) {
    return (m.find(key) != m.end());
}

// Handy one line map O(log n) lookup. With one single copy of the value.
// Specialization for maps of the above container.
template <typename S>
inline bool Find(const S& m,
                 const typename S::key_type& key,
                 const typename S::value_type& default_value,
                 typename S::value_type* value) {
    typename S::const_iterator iter = m.find(key);
    if (iter == m.end()) {
        *value = default_value;
        return false;
    }
    *value = iter->second;
    return true;
}

}  // end namespace std
#endif  /* STL_UTILS_H */
