/*
 * learn.cpp
 *
 *  Created on: 01/gen/2015
 *      Author: michi
 */

/* Usage example:
./sbr_train \
  --training_data_file=train --training_examples_file=train_examples \
  --predicates_file=predicates --rules_file=rules \
  --validation_data_file=test --validation_examples_file=test_examples \
  --max_iterations=200 \
  --iteration_start_constraints=20 \
  --lambda_labeled_values=1 \
  --lambda_regularization_values=1 \
  --lambda_constraint_values=0 \
  --learning_rate=1 \
  --output_dir=out \
  --input_dir=/Users/michi/src/Systems/SBRS-1.1.2/data_examples/CoRA \
  --learning_type=RGD --function_type=KERNEL_MACHINE
*/

#include <string>
#include <sstream>

#include "classifier/classifier.h"
#include "train/options.h"
#include "train/train_runner_helper.h"
#include "utils/file_utils.h"  // for ToFileOrDie
#include "utils/gflags/gflags/gflags.h"
#include "utils/gtl_utils.h"  // for ScopedPtr
#include "utils/system.h"  // for Cmdline


// Output Files.
DECLARE_string(output_dir);

// Test
DEFINE_bool(run_collective_classification_after_train, false,
        "Execute collective classification on the best classifier at the end of the "
        "training stage, reusing the same rules used in training. "
        "Requires transductive mode to be on.");

DECLARE_bool(transductive);

// Logging
DECLARE_string(logtofile);

namespace google {
extern void ShowUsageWithFlags(const char* argv0);
}  // end google namespace

using namespace Regularization;

int Run() {
    if (FLAGS_run_collective_classification_after_train) {
        CHECK_WITH_MESSAGE(FLAGS_transductive,
                           "--transductive must be specified if performing collective classification");
    }
    TrainRunnerHelper::Data data;
    TrainRunnerHelper::LoadData(&data);
    std::string output_summary;

    TrainOptions best_options;
    ScopedPtr<BaseClassifier> best_classifier(
            TrainRunnerHelper::RunTrain(data, &output_summary, &best_options));

    /*****************************************************************************
     * Collective Classification.
     ****************************************************************************/
    if (FLAGS_run_collective_classification_after_train) {
        TrainRunnerHelper::RunCollectiveClassificationAfterTrain(
                data, best_options, best_classifier.Get(), &output_summary);
    }

    /*****************************************************************************
     * Constraint Verification
     ****************************************************************************/
    TrainRunnerHelper::RunConstraintVerification(data, best_options, best_classifier.Get());

    /*****************************************************************************
     * Dump and Clean up
     ****************************************************************************/
    const std::string output_base_dir = data.options.GetOutputDir();
    StringUtils::ToFileOrDie(
            output_summary, output_base_dir + "/model_output_summary.dat");
    return 0;
}

/**
 * Main: parse cmdline arguments and call the right run function
 **/
int main(int argc, char** argv)
{
    /* StringUtils::ParseTree parse = StringUtils::GetParseTree("[[ NOT [A(x,y)] ] AND [[B(a,f,g)] => [C(y)]]]");
    parse.Print();
    exit(1); */

    const std::string cmdline = SystemUtils::Cmdline(argc, argv);

    // parse command line
    google::ParseCommandLineFlags(&argc, &argv, true);
    const std::string logtofile = FLAGS_logtofile;
    FLAGS_logtofile = "";  // to avoid writing logs to a non-existing dir.
    FileUtils::MakePathOrDie(FLAGS_output_dir);
    FLAGS_logtofile = (logtofile.empty() ? FLAGS_output_dir + "/log.txt" : logtofile);
    // Logging has already been initialized at this point. Reset it to logging to the new file.
    Logging::ResetLogStreams();
    VMESSAGE(1, "Running " << cmdline);

    // check parameters
    if (argc != 1) {  // everything into flags.
        google::ShowUsageWithFlags(argv[0]);
        for (int i = 1; i < argc; ++i) {
            WARN("Unknown cmdline argument " << argv[i]);
        }
        return -1;
    }

    return Run();
}
