#! /bin/bash
# Script to replicate the CNN_CC_O results.

SCRIPT_DIR=../SBRS_7.1_soumali/scripts/process_results
BIN=../SBRS_7.1_soumali/Train/sbr_train
if [ -f $BIN ]; then
    echo "$BIN exists."
else
    pushd ../SBRS_7.1_soumali/Train
    make clean
    make all
    popd
fi

$BIN --training_data_file=data_train.txt --training_examples_file=train_examples.txt --test_examples_file=test_examples.txt --predicates_file=predicates.txt --rules_file=rules_weak_luka.txt --max_iterations=300 --lambda_regularization_values=1 --lambda_constraint_values=1 --lambda_labeled_values=1 --learning_rate=0.1 --lambda_predicate_dependent_files=predicates_lambda_all.txt --output_dir=./CNN_CC_O/outputs --input_dir=./CNN_CC_O/inputs  --learning_type=RGD --transductive --run_collective_classification_after_train --map_function_constraints_affect_supervised_entries --squashing_function_type=LINEAR_SATURATED  --predicate_dependent_regularizers=true && \
cat ./CNN_CC_O/outputs/cc/ll1-lr1-lc1/results/test_results.dat | $SCRIPT_DIR/test.pl --considered_classes=airplane,automobile,bird,cat,deer,dog,frog,horse,ship,truck
